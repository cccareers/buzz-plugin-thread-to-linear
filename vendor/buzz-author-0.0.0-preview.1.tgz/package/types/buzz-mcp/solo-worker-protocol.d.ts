import type { BuzzEvent, Template } from "./client";
export declare const SOLO_WORKER_VERSION = 1;
/** Seconds a request may be admitted for, and how far ahead of the
 * reader's clock its `issued_at` may be. */
export declare const ADMISSION_WINDOW = 120;
export declare const FUTURE_SKEW = 30;
/** Longest a readiness answer stays usable, in seconds. */
export declare const READINESS_TTL = 30;
export declare const TEXT_MAX = 16000;
export declare const TITLE_MAX = 120;
export declare const PAGE_MAX = 50;
/** The owner's Buzz keeps its latest grant acknowledgement among its newest
 * this-many events in the control channel, posting it again as needed, so a
 * controller finds it with one read. */
export declare const ACK_HORIZON = 50;
export declare const ACTIONS: readonly ["readiness", "create", "send", "read", "stop", "archive", "list"];
export type Action = (typeof ACTIONS)[number];
/** Actions with an effect: each needs a current custody epoch. */
export declare const MUTATIONS: readonly Action[];
export declare const PHASES: readonly ["accepted", "preparing", "ready", "running", "stop_pending", "settled", "refused", "uncertain", "receipt_expired"];
export type Phase = (typeof PHASES)[number];
export declare const REASONS: readonly ["authorization_required", "approval_required", "grant_changed", "revoked", "readiness_required", "expired", "conflict", "capacity", "unsupported", "stop_required", "not_found", "outcome_unavailable"];
export declare const WORKER_STATES: readonly ["preparing", "idle", "running", "stopping", "stopped", "archived", "unknown"];
export declare const ARCHIVE_SCOPES: readonly ["complete", "local_only", "watch_removal_pending"];
export type Grant = Readonly<{
    id: string;
    revision: number;
}>;
/** Where a request goes and under which grant. Every record repeats it. */
export type Route = Readonly<{
    owner: string;
    controller: string;
    stream: string;
    community: string;
    device: string;
    grant: Grant;
}>;
type Json = Readonly<Record<string, unknown>>;
export type Intent = Route & Readonly<{
    v: 1;
    type: "request";
    action: Action;
    nonce: string;
    issued_at: number;
    admit_before: number;
    custody_epoch?: string;
    args: Json;
}>;
export type Response = Route & Readonly<{
    v: 1;
    type: "response";
    request: string;
    action: Action;
    revision: number;
    phase: Phase;
    reason?: (typeof REASONS)[number];
    observed_at: number;
    receipt_retained_until?: number;
    result?: Json;
}>;
export type GrantAck = Route & Readonly<{
    v: 1;
    type: "grant_ack";
    workers: readonly string[];
    operations: readonly Action[];
    state: "active" | "revoked";
    issued_at: number;
}>;
type Kind = "request" | "response" | "grant_ack";
/** The one encoding every record is hashed and sent in: RFC 8785 limited to
 * strings, booleans, non-negative safe integers, arrays and objects. Keys are
 * sorted by UTF-16 code units, with no whitespace. */
export declare function canonical(value: unknown): string;
/** Parses text that must already be canonical, so one record has one
 * spelling: reordered keys, spaces or duplicate keys are refused. */
export declare function parseCanonical(text: string): unknown;
/** A request's logical id: the hash of its whole canonical intent, so the same
 * id can never stand for different arguments, epochs or deadlines. */
export declare function intentId(intent: Intent): Promise<string>;
/** Throws what is wrong with `args` for `action`, as `checkIntent` would. */
export declare const checkArgs: (action: Action, args: unknown) => void;
/** Returns `value` as a request intent, or throws what is wrong with it. */
export declare function checkIntent(value: unknown): Intent;
/** Whether a reader whose clock says `now` (seconds) may admit `intent` as a
 * new request. A request already on record is reconciled, not re-judged. */
export declare const admissible: (intent: Intent, now: number) => boolean;
/** Returns `value` as a response, or throws what is wrong with it. */
export declare function checkResponse(value: unknown): Response;
/** Returns `value` as a grant acknowledgement, or throws what is wrong with it. */
export declare function checkGrantAck(value: unknown): GrantAck;
/** The tag that marks a kind 9 message as a protocol record rather than
 * something a person typed. */
export declare const controlTag: (kind: Kind | "relay") => readonly ["control", "solo_worker", string, "relay" | Kind];
/** The message carrying `record` in its control channel. A response also
 * names the request messages it answers (`answers`), including any repeat of
 * the request, since the agent looks for answers by message. */
export declare function recordTemplate(record: Intent | Response | GrantAck, answers?: readonly string[]): Template;
/** The record of kind `kind` that a signed `event` carries, checked against
 * its signer and channel; undefined when the event is no such record. */
export declare function readRecord(event: BuzzEvent, kind: "request"): Intent | undefined;
export declare function readRecord(event: BuzzEvent, kind: "response"): Response | undefined;
export declare function readRecord(event: BuzzEvent, kind: "grant_ack"): GrantAck | undefined;
/** Whether `response` answers request `id` with `intent`'s exact route. The
 * messages a read returns must come from the Solo it asked about, written by
 * its worker or relayed there by the owner. */
export declare function answers(response: Response, intent: Intent, id: string): boolean;
/** The owner's latest word on one request: the highest revision. Two
 * different responses at that revision cannot both be true: `conflict`. */
export declare function latest(responses: readonly Response[]): Response | "conflict" | undefined;
export {};
