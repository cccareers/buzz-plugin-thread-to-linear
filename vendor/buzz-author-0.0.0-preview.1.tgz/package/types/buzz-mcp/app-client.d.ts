import type { BuzzClient, Memories } from "./client";
import type { AgentHandle } from "../features/agents/service";
import type { HostProcess, HostProcessOptions, ProcessProtection } from "../features/host/service";
type Spawn = (id: string, options?: HostProcessOptions) => Promise<HostProcess>;
/** The largest file a tool reads: the community's upload limit. */
export declare const READ_LIMIT: number;
export declare function appClient(agent: AgentHandle, options: Readonly<{
    /** The file at `path`, absolute, `~/…` or relative to the agent's working
     * directory. */
    read(path: string): Promise<Uint8Array>;
    relayAuthor?: string | undefined;
    signingAuthority?: string | undefined;
    memories(slug?: string): Promise<Memories>;
    /** Forget a read that may have started before a successful memory write. */
    remembered?(): void;
    /** Reject operations after the owning turn or community has ended. */
    check?(): void;
    signal?: AbortSignal;
    protectionContext?(): Promise<unknown>;
    /** Retain a file-backed native snapshot until the exact tool check settles. */
    captureProtectionContext?(): Promise<{
        value: unknown;
        release(): void;
    }>;
    /** The runtime reviews each tool call itself before Buzz dispatches it. */
    nativeToolGate?: boolean;
}>): BuzzClient;
/** Reads a file with the plugin's declared `read` process (`base64 -i`),
 * which passes binary files through intact, or another that prints base64
 * given the path and `args`. */
export declare function readFile(spawn: Spawn, cwd: string, path: string, signal?: AbortSignal, protection?: ProcessProtection, process?: string, args?: string[]): Promise<Uint8Array<ArrayBuffer>>;
export {};
