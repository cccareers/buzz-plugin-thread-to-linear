import type { ComposerTool, ContributionReader } from "../../features/conversation/contracts";
/** The bundled renderer follows the same activation lifetime as its picker. */
export declare function useGifDraftPreview(tools: ContributionReader<ComposerTool> | undefined): typeof gifDraftPreview | undefined;
/** The GIF that `markdown` attaches when it is exactly one image with a safe
 * URL, as the picker inserts it. The Markdown stays the sent source. Picked
 * assets need no `.gif` suffix, so only the thumbnail depends on the preview
 * rules; `source` is absent when it cannot be shown. */
export declare function draftGif(markdown: string, media: (url: string) => string | undefined): {
    source: string | undefined;
    title: string;
} | undefined;
/** Presentation only: the editor retains the exact Markdown for undo and sending. */
export declare function gifDraftPreview(url: string | undefined, title: string | null | undefined, media: (url: string) => string | undefined): import("react").JSX.Element | undefined;
