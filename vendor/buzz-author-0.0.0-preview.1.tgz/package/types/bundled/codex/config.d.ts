export type Config = {
    model: string;
    effort: string;
    instructions: string;
    workspace: string;
    scope: "thread" | "channel";
};
export type Model = {
    model: string;
    displayName: string;
    description: string;
    isDefault: boolean;
    defaultReasoningEffort: string;
    supportedReasoningEfforts: {
        reasoningEffort: string;
        description: string;
    }[];
};
/** Buzz owns model preferences; an unset choice follows Codex's recommendation. */
export declare function resolveModel(selected: string, models: readonly Model[]): string | undefined;
export declare const defaults: Config;
export declare function config(raw: unknown): Config;
export declare const effortName: (effort: string) => string;
export declare const absoluteWorkspace: (path: string) => boolean;
/** An absolute path, or one under the home directory written `~/…`, which the
 * process host expands. */
export declare const validWorkspace: (path: string) => boolean;
