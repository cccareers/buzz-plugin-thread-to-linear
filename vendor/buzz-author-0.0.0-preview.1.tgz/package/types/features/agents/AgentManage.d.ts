import { type ReactNode } from "react";
import type { Agent, Agents } from "./service";
/** Whether the agent shown here is also in another of the owner's
 * communities that it isn't leaving, so it can be removed from this one
 * alone, or again after a Remove that didn't finish. */
export declare const inSeveral: (agents: Agents, agent: Agent) => boolean;
/** One field list for every surface explaining shared settings. */
export declare const sharedAgentSettings = "Name, type and settings, including instructions, model and workspace, are shared across communities.";
/** What adding the same agent to another community shares and what it keeps
 * there, as every place that adds one says it. */
export declare const sameAgent: (many?: boolean) => "Name, type and settings, including instructions, model and workspace, are shared across communities. A change to them applies in every community. Its picture and what it pays attention to are its own in each. Memory is kept per community, so anything it saved here before comes back, and so do its conversations here." | "Name, type and settings, including instructions, model and workspace, are shared across communities. A change to them applies in every community. Their pictures and what they pay attention to are their own in each. Memory is kept per community, so anything they saved here before comes back, and so do their conversations here.";
/** Delete, after a confirmation that says what it does. One that cannot
 * finish keeps the dialog open with what is left; the agent stays listed.
 * A community Delete cannot reach can then be given up on. */
export declare function AgentDelete({ agents, agent, onRemoved, trigger, }: {
    agents: Agents;
    agent: Agent;
    onRemoved(): void;
    trigger?: (open: () => void) => ReactNode;
}): import("react").JSX.Element;
/** Takes the agent out of the community shown, after a confirmation, and
 * keeps it in its others. Offer it only while it is in another: see
 * `inSeveral`. */
export declare function AgentRemoveHere({ agents, agent, onRemoved, trigger, }: {
    agents: Agents;
    agent: Agent;
    onRemoved(): void;
    trigger: (open: () => void) => ReactNode;
}): import("react").JSX.Element;
/** Checks again, for an imported agent, that it is not archived in its
 * community, which import could not confirm. */
export declare function AgentArchiveRetry({ agents, agent, }: {
    agents: Pick<Agents, "unarchive">;
    agent: Agent;
}): import("react").JSX.Element | null;
