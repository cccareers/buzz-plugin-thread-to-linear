/** Recognize the old editor's generated artwork, never render arbitrary SVG. */
export declare function legacyEmojiPicture(picture: string): {
    emoji: string;
    color: string;
} | undefined;
/** Convert before native takes custody; its upload still owns persistence. */
export declare function importedEmojiPicture(picture: string | undefined): Promise<{
    source: string;
    png: string;
} | undefined>;
