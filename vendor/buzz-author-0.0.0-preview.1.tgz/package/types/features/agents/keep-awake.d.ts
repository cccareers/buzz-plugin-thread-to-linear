/** Off; Always ("on") while the app runs; or While agents work ("auto"): while
 * agents work and for `after` minutes once the last turn ends. */
export type KeepAwake = Readonly<{
    mode: "off" | "on" | "auto";
    after: number;
}>;
export declare const keepAwakeDelays: readonly [30, 60, 120, 240, 480, 720];
export declare function keepAwakePreference(): KeepAwake;
export declare function subscribeKeepAwake(listener: () => void): () => void;
export declare function useKeepAwakePreference(): Readonly<{
    mode: "off" | "on" | "auto";
    after: number;
}>;
/** Applies `value` at once; the error says when it could not be saved. */
export declare function setKeepAwakePreference(value: KeepAwake): string | null;
/** Why this Mac is not kept awake as chosen, or null when it is. */
export declare function useKeepAwakeApplyError(): string | null;
/** Asks the host again to apply the current choice. */
export declare function retryKeepAwake(): void;
/** Holds the native keep-awake assertion as the preference and agent work
 * ask. Choosing the setting or starting the app starts an Automatic wait as a
 * finished turn does. */
export declare function bindKeepAwake(agents: Readonly<{
    isWorking(): boolean;
    subscribeWorking(listener: () => void): () => void;
}>, hold: (hold: boolean) => Promise<void>, preference?: Readonly<{
    read(): KeepAwake;
    subscribe(listener: () => void): () => void;
}>): () => void;
