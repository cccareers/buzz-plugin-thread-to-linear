import type { RelayEvent } from "../relay/events";
import type { RelayWriter } from "../relay/transport";
import type { AgentConfigStore, Subject } from "./agent-config";
import { artifactTemplate, type Expected, type Refusal, type SnapshotRead } from "./agent-config-artifacts";
export type WriteDeps = Readonly<{
    read: SnapshotRead;
    writer: RelayWriter;
    store: AgentConfigStore;
    maxEventBytes: number;
    signal: AbortSignal;
    /** Whether the community's connection is live now. */
    online(): boolean;
}>;
/** One artifact a save revises. */
export type WriteSide = Readonly<{
    subject: Subject;
    expected: Expected;
    title: string;
}>;
export type Saved = 
/** Accepted and still the current head. */
Readonly<{
    status: "saved";
    head: RelayEvent;
}>
/** Changed elsewhere first, before or after this send: `head` is current
 * and installed, and the edit stays a draft. */
 | Readonly<{
    status: "conflict" | "superseded";
    head?: RelayEvent;
}>
/** Accepted, but no current head could be read back. */
 | Readonly<{
    status: "accepted-unavailable";
}>
/** Nothing was sent, or the relay definitely refused it. */
 | Readonly<{
    status: "refused";
    refusal: Refusal | "offline";
    message: string;
}>
/** Sent, with no answer: it may or may not have been saved. */
 | Readonly<{
    status: "unknown";
    message: string;
}>;
/** The head's JSON object, or none when it has no readable one. */
export declare function headFields(head: RelayEvent | undefined): Readonly<Record<string, unknown>>;
/** `fields` over the head's JSON object, so an edit keeps the fields this
 * client doesn't know (NIP-AP "Editing"). */
export declare const edited: (head: RelayEvent | undefined, fields: Readonly<Record<string, unknown>>) => string;
type Template = ReturnType<typeof artifactTemplate>;
export declare function createConfigWriter(deps: WriteDeps): {
    refresh: (side: WriteSide) => Promise<import("nostr-tools").VerifiedEvent | undefined>;
    /** Saves `fields` over the opened head as its next revision, keeping its
     * unknown fields and client tags. */
    save: (side: WriteSide, fields: Readonly<Record<string, unknown>>, base: string | null, extra?: readonly (readonly string[])[]) => Promise<Saved>;
    /** Saves a History revert or restore built on head `base`. */
    revise: (side: WriteSide, template: Template, base: string) => Promise<Saved>;
};
export type ConfigWriter = ReturnType<typeof createConfigWriter>;
export {};
