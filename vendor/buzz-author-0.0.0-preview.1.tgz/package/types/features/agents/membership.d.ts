/** The key of an agent's membership in a community: its pubkey in its home
 * community, `pubkey@host` elsewhere, with the host percent-encoded so the key
 * is also safe as a file name. */
export type AgentKey = string;
/** A membership key: a pubkey, alone or with an encoded host. */
export declare const AGENT_KEY: RegExp;
/** `origin`'s key for agent `pubkey`, whose home community is `home`. Both
 * origins are `https://host[:port]`. */
export declare function agentKey(pubkey: string, origin: string, home: string): string;
/** The agent identity a membership key belongs to. */
export declare const pubkeyOf: (key: AgentKey) => string;
