import type { Context } from "@deepseek-ai/cordis";
import type { HostProcess, HostProcessOptions } from "../host/service";
import type { JsonValue } from "../navigation/targets";
import { type AgentKey } from "./membership";
import type { AgentStore } from "./store";
export type AgentExecutionBinding = Readonly<{
    provider: string;
    config?: JsonValue;
}>;
export type AgentExecutionSession = Readonly<{
    key: string;
    intent: "new" | "existing";
    /** Aborting any open for this session ends its shared execution lifetime. */
    signal?: AbortSignal;
}>;
export type AgentExecutionTarget = Readonly<{
    workspace: string;
    spawn(program: string, options?: HostProcessOptions): Promise<HostProcess>;
    readFile(path: string, options?: Readonly<{
        cwd?: string;
    }>): Promise<Uint8Array>;
    resolveDirectory(path: string): Promise<string>;
    /** Shares pending cleanup and retries failed cleanup. */
    dispose(): Promise<void>;
}>;
export type AgentExecutionProvider = Readonly<{
    id: string;
    harnesses: readonly string[];
    connect(binding: AgentExecutionBinding, session: Readonly<{
        agent: AgentKey;
        key: string;
        intent: "new" | "existing";
        signal: AbortSignal;
    }>): Promise<AgentExecutionTarget>;
}>;
export type AgentExecution = AgentExecutionTarget & Readonly<{
    signal: AbortSignal;
}>;
export declare function createAgentExecutions(root: Context, storage: AgentStore): {
    read: (agent: AgentKey) => AgentExecutionBinding | undefined;
    inspect: (agent: AgentKey) => Promise<Readonly<{
        provider: string;
        config?: JsonValue;
    }> | undefined>;
    register(ctx: Context, provider: AgentExecutionProvider): void;
    bind(ctx: Context, agent: AgentKey, harness: string, input: Readonly<{
        id: string;
        config?: JsonValue;
    }>): Promise<void>;
    check(agent: AgentKey, harness: string): Promise<void>;
    open(ctx: Context, agent: AgentKey, harness: string, session: AgentExecutionSession): Promise<AgentExecution | undefined>;
};
