type Record = Readonly<{
    id: string;
    agent: string;
    receivedAt: number;
    kind: string;
    plaintext: string;
}>;
export type ActivityRecord = Record & Readonly<{
    envelopeId: string;
}>;
/** Filter individual batch children, never relabel a mixed envelope as one channel.
 * Raw session retention is unchanged; child JSON is a display projection. */
export declare function activityRecords(records: readonly Record[], agent: string, channelId?: string): ActivityRecord[];
export {};
