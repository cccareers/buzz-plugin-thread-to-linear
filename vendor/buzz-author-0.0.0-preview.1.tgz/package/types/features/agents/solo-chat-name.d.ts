import type { RelayData } from "../relay/service";
import type { RelayEvent } from "../relay/events";
/**
 * Names the owner's Solo chat with an agent harness's own title, once. Only a
 * chat that still has its original first-message name is renamed. The first
 * tagged harness on that message names it, regardless of retry wording. A chat
 * renamed by anyone, including by this, is never touched again. The owner's
 * session renames it, as the owner would.
 */
export declare function nameSoloChat(relay: RelayData | undefined, owner: string, agent: string, event: RelayEvent, title: string): Promise<void>;
