import type { AgentConfigStore } from "./agent-config";
import type { ConfigChannels } from "./config-channels";
import type { ConfigWriter, WriteSide } from "./config-writes";
/** What a team's first save sends: its name and instructions, with the
 * members its members are then added from. */
export type TeamSent = Readonly<{
    name: string;
    instructions: string;
    members: readonly string[];
}>;
type Template = Parameters<ConfigWriter["revise"]>[1];
export type TeamEdit = Readonly<{
    id: string;
    name: string;
    instructions: string;
    /** The owner's agents the team should have. */
    members: readonly string[];
    /** What the editor opened: its head and its members. Absent for a new
     * team, whose id was made before this call. */
    base?: Readonly<{
        head: string | null;
        members: readonly string[];
    }>;
    /** Import: an existing team's name and instructions are kept. */
    adopt?: boolean;
    /** With `adopt`, a move's first try: an existing team that differs in
     * name, instructions or members is a conflict, and nothing is written. */
    fresh?: boolean;
    /** With `fresh`, what an earlier try of this move sent in its first save.
     * It is sent again, so a team there with its name and instructions and
     * only some of its members is that try's partial copy: resumed, not a
     * conflict. */
    resume?: TeamSent;
    /** Awaited with what is sent just before a Create or Import's first save,
     * so the caller can durably record that this device may be creating the
     * team. */
    saving?: (sent: TeamSent) => Promise<void>;
    /** Awaited once a `fresh` change knows the team there is this device's,
     * before any member changes, so the caller can durably record it. */
    owned?: () => Promise<void>;
}>;
/** What the change did. `ok` only when the readback shows all of it. */
export type TeamResult = Readonly<{
    ok: boolean;
    added: readonly string[];
    removed: readonly string[];
    /** Member changes never attempted. */
    skipped: readonly string[];
    /** The member whose change stopped it. */
    failed?: string;
    /** Why it stopped, or what the readback shows instead. */
    error?: string;
    /** The last step was sent with no answer: it may have happened. */
    uncertain?: boolean;
    /** This change created the team: its first name and instructions saved. */
    created?: true;
    /** A `fresh` change found a different team there and wrote nothing. */
    conflict?: true;
    /** The first save was definitely refused: nothing was created. */
    refused?: true;
}>;
/** The result a failed team change was thrown with, if any. */
export declare const teamResultOf: (error: unknown) => Readonly<{
    ok: boolean;
    added: readonly string[];
    removed: readonly string[];
    /** Member changes never attempted. */
    skipped: readonly string[];
    /** The member whose change stopped it. */
    failed?: string;
    /** Why it stopped, or what the readback shows instead. */
    error?: string;
    /** The last step was sent with no answer: it may have happened. */
    uncertain?: boolean;
    /** This change created the team: its first name and instructions saved. */
    created?: true;
    /** A `fresh` change found a different team there and wrote nothing. */
    conflict?: true;
    /** The first save was definitely refused: nothing was created. */
    refused?: true;
}> | undefined;
export type TeamDeps = Readonly<{
    channels: Pick<ConfigChannels, "find" | "ensure" | "archive" | "archived" | "owns" | "addMember" | "removeMember">;
    writer: ConfigWriter;
    store: AgentConfigStore;
    owner: string;
    community: string;
    online(): boolean;
    signal: AbortSignal;
}>;
/** A strong find saw no config channel for the team. */
export declare class NoTeamChannel extends Error {
    constructor();
}
export declare function teamOps(deps: TeamDeps): {
    side: (id: string, channel: string, name: string) => Promise<Readonly<{
        subject: import("./agent-config").Subject;
        expected: import("./agent-config-artifacts").Expected;
        title: string;
    }>>;
    change: (edit: TeamEdit) => Promise<Readonly<{
        ok: boolean;
        added: readonly string[];
        removed: readonly string[];
        /** Member changes never attempted. */
        skipped: readonly string[];
        /** The member whose change stopped it. */
        failed?: string;
        /** Why it stopped, or what the readback shows instead. */
        error?: string;
        /** The last step was sent with no answer: it may have happened. */
        uncertain?: boolean;
        /** This change created the team: its first name and instructions saved. */
        created?: true;
        /** A `fresh` change found a different team there and wrote nothing. */
        conflict?: true;
        /** The first save was definitely refused: nothing was created. */
        refused?: true;
    }>>;
    /** Saves a History revert or restore of the team's name and
     * instructions, on the head its `prev` names. */
    revise: (id: string, write: WriteSide, template: Template, prev: string) => Promise<import("./config-writes").Saved>;
    /** Deletes the team by archiving its config channel, once, then reads
     * the archive back (NIP-AP "Deleting a team"). */
    archive: (id: string) => Promise<string>;
};
export type TeamOps = ReturnType<typeof teamOps>;
export {};
