import type { DecisionQuestion, DecisionRequest, DecisionResult, Decisions } from "../decisions/service";
import type { RelayEvent } from "../relay/events";
import { type EventWatch } from "./attention";
export type ClassifierAnswer = Readonly<{
    probability: number;
    threshold: number;
    pass: boolean;
}>;
/** What a classified watch's turn is told about its classifier. */
export type ClassifierOutcome = 
/** No decision provider is set up, so it did not run. */
Readonly<{
    outcome: "not-run";
    reason: string;
}>
/** It ran and failed, so the event passed unchecked. */
 | Readonly<{
    outcome: "failed";
    reason: string;
}>
/** The backend answered and at least one answer passed. */
 | Readonly<{
    outcome: "passed";
    model: string;
    answers: Readonly<Record<string, ClassifierAnswer>>;
    /** The pass rule: any question that says yes. */
    policy: string;
}>;
/** Facts about the event's surroundings. Names are unverified display text. */
export type ClassifierContext = Readonly<{
    channel: {
        name: string | null;
    };
    thread: {
        is_reply: boolean;
        parent: {
            author: {
                role: "owner" | "other" | "self";
                name: string | null;
            };
            content: string;
        } | null;
    };
    mentions: {
        agent: boolean;
        owner: boolean;
        others: number;
    };
}>;
export type ClassifierInput = Readonly<{
    classifier: NonNullable<EventWatch["classifier"]>;
    /** The agent's community, which a provider may bill. */
    community?: string;
}> & (Readonly<{
    source: {
        provider: string;
        text: string;
    };
}> | Readonly<{
    event: RelayEvent;
    author: {
        role: "owner" | "other";
        name: string | null;
    };
    context?: ClassifierContext;
}>);
/** One yes/no question per named question. Its text carries the question,
 * the guidance, when to answer yes and no, and the boundaries. */
export declare function classifierQuestions(classifier: ClassifierInput["classifier"]): Record<string, DecisionQuestion>;
/** The state the backend judges, as JSON text. The Interest is not sent; the
 * questions carry the criteria, as in Janet. */
export declare function classifierState(input: ClassifierInput): string;
export declare const classifierRequest: (input: ClassifierInput) => DecisionRequest;
/** The outcome when no classifier can run. */
export declare const notRun: () => Readonly<{
    outcome: "not-run";
    reason: string;
}>;
/** Runs the classifier. Any failure lets the event pass, as in Janet. Also
 * returns which provider was asked. */
export declare function classify(decisions: Decisions, input: ClassifierInput): Promise<{
    pass: boolean;
    result: ClassifierOutcome;
    backend?: DecisionResult["backend"];
}>;
export declare function mentionFacts(tags: readonly (readonly string[])[], agent: string, owner: string): ClassifierContext["mentions"];
export declare const excerpt: (s: string) => string;
