import type { ChannelQueries } from "../relay/contracts";
import type { ChannelChoice } from "./attention";
import type { Agents, Models, SessionPlace, SessionState } from "./service";
/** The selected community's agents and the registered types. */
export declare function useAgents(agents: Agents): {
    snapshot: Readonly<{
        status: "unavailable" | "loading" | "ready" | "error";
        classifier: import("./attention-objects").ClassifierAvailability;
        agents: readonly import("./service").Agent[];
        running: readonly import("./service").Agent[];
        interrupted: readonly import("./service").Agent[];
        teams: readonly import("./store").Team[];
        syncsTeams?: boolean;
        error?: string;
    }>;
    types: readonly Readonly<Omit<import("./service").AgentType<unknown>, "voice"> & {
        voice?(seat: import("./service").AgentVoicePipe): Promise<import("./service").AgentVoiceConnection>;
    } & {
        key: string;
        pluginId: string;
        revision: string;
    }>[];
};
/** Agents' snapshot, or undefined without it. */
export declare function useAgentsSnapshot(agents: Agents | undefined): Readonly<{
    status: "unavailable" | "loading" | "ready" | "error";
    classifier: import("./attention-objects").ClassifierAvailability;
    agents: readonly import("./service").Agent[];
    running: readonly import("./service").Agent[];
    interrupted: readonly import("./service").Agent[];
    teams: readonly import("./store").Team[];
    syncsTeams?: boolean;
    error?: string;
}> | undefined;
/** The owner's teams on this device, or none without Agents. */
export declare const useTeams: (agents: Agents | undefined) => readonly Readonly<{
    id: string;
    name: string;
    instructions: string;
    members: readonly string[];
    revision?: string;
}>[];
/** The agent at `pubkey`, with its type when that is registered. A saved
 * agent whose type plugin is disabled or reloading is still an agent. */
export declare function useAgent(agents: Agents | undefined, pubkey: string): {
    agent: Readonly<{
        key: import("./membership").AgentKey;
        pubkey: string;
        name: string;
        picture?: string;
        type: string;
        owner: string;
        relay: string;
        place: import("./service").AgentPlace;
        unfinished?: true;
        archiveUnchecked?: true;
        deleting?: true;
        protection?: Readonly<{
            provider: string;
            policy: unknown;
        }>;
        protectionRevision?: number;
        executionBinding?: Readonly<{
            provider: string;
            config?: import("../navigation/targets").JsonValue;
        }>;
        attention: Readonly<Record<string, Readonly<{
            slug: string;
            value: import("./attention").AttentionValue;
            modifiedAt: number;
        }>>>;
        skipped: Readonly<Record<string, Readonly<{
            slug: string;
            value: unknown;
            modifiedAt: number;
            problem: string;
        }>>>;
        timers: Readonly<Record<string, Readonly<{
            armedAt: number;
            nextDue: number;
            used: number;
        }>>>;
        sourceRuns?: Readonly<Record<string, string>>;
        attentionHistory?: import("./store").AgentRecord["attentionHistory"];
        attentionEnabled: boolean;
        config: unknown;
        configBase?: import("./community-config").ConfigBase;
        configProblem?: string;
    }>;
    type: Readonly<Omit<import("./service").AgentType<unknown>, "voice"> & {
        voice?(seat: import("./service").AgentVoicePipe): Promise<import("./service").AgentVoiceConnection>;
    } & {
        key: string;
        pluginId: string;
        revision: string;
    }> | undefined;
} | undefined;
/** The state of the targeted harness sessions. Any compaction blocks a send
 * to those targets; ordinary active turns keep accepting steering. */
export declare function useSessionState(agents: Agents | undefined, pubkeys: readonly string[], place: SessionPlace): SessionState;
/** The app's Agents, for surfaces such as the composer that plugins do not own. */
export declare const AgentsContext: import("react").Context<Agents | undefined>;
export declare const MentionModelsContext: import("react").Context<((pubkeys: readonly string[]) => Promise<readonly MentionModelChoice[]>) | undefined>;
export type MentionModelChoice = Models & Readonly<{
    pubkey: string;
    name: string;
    loading?: boolean;
    failed?: boolean;
    /** Its type offers immediate controls for sessions of this scope. */
    session?: "thread" | "channel";
}>;
/** Model catalogs and session actions for the viewer's mentioned agents.
 * A single model still validates saved picks even when no control is needed. */
export declare function useMentionModels(pubkeys: readonly string[], retry?: number): readonly MentionModelChoice[];
/** Channels a watch can be scoped to, by name, from the viewer's joined roster. */
export declare function useChannelChoices(queries: ChannelQueries | undefined): readonly ChannelChoice[];
