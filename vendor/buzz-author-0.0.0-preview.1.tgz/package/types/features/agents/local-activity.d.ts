export declare const REPLY_CORRELATION_MS = 120000;
export type LocalWorkState = "waiting" | "working" | "done" | "error" | "superseded" | "stopped";
/** `stopped`: the owner's Stop ended the turn, as its harness reports it. */
export type WorkOutcome = Readonly<{
    ok: boolean;
    error?: string;
    stopped?: true;
}>;
/** A harness step: its own tool name and, when known, what it acts on. */
export type WorkStep = Readonly<{
    tool: string;
    target?: string;
}>;
export type LocalWork = Readonly<{
    scope: string;
    agent: string;
    channelId: string;
    messageId: string;
    threadRootId: string;
    /** The request is in this thread; absent means channel-level work. */
    thread?: true;
    /** The request is in a relay-verified Solo chat, not a DM or channel. */
    soloChat?: true;
    /** The Solo chat's existing display name when this work started. */
    conversationName?: string;
    state: LocalWorkState;
    startedAt: number;
    /** This run's messages still awaiting publication acknowledgement. */
    publishing?: number;
    /** Recent messages this run published here; their relay echoes are not separate alerts. */
    replyMessages?: readonly Readonly<{
        id: string;
        acknowledgedAt: number;
    }>[];
    /** Recent publication IDs retained with this work entry for transcript navigation,
     * independently of notification echo expiry. Capped at 512 per entry. */
    publishedMessageIds?: readonly string[];
    error?: string;
    /** Latest live step, as the harness named it; display only. */
    step?: WorkStep;
    /** The owner hid this error here; the outcome remains as evidence. */
    dismissed?: true;
    /** Its harness can stop the turn it is in. */
    stoppable?: true;
    /** It can be asked again once it fails. */
    retryable?: true;
}>;
export type LocalAgentSource = {
    work(): readonly LocalWork[];
    subscribeWork(listener: () => void): () => void;
    /** Hides one already-seen error on this device; never changes its outcome. */
    dismissError?(work: Pick<LocalWork, "scope" | "agent" | "messageId">): void;
    /** Stops the turn this unsettled request is in, then shows it stopped. */
    interrupt?(work: Pick<LocalWork, "scope" | "agent" | "messageId">): Promise<void>;
    /** Asks again for this failed request, which begins it again; throws when
     * it can't be. */
    retry?(work: Pick<LocalWork, "scope" | "agent" | "messageId">): void;
};
/** App-owned local facts. No relay publication, inference, polling or process control. */
export declare function createLocalAgentActivity(): {
    reader: LocalAgentSource;
    begin(input: Omit<LocalWork, "state" | "startedAt" | "publishing" | "replyMessages" | "publishedMessageIds" | "error" | "dismissed" | "stoppable" | "retryable">, retry?: () => void): {
        channelId: string;
        started: () => void;
        confirmSolo: (conversationName?: string) => void;
        sending: () => () => void;
        reply: (messageId: string) => void;
        supersede: () => void;
        /** Latest live step reported by the plugin; display only. */
        step: (tool: string, target?: string) => void;
        finish: (result: WorkOutcome) => void;
        /** The harness's way to stop this request's turn, offered as Stop. */
        interruptible: (stop: () => Promise<void>) => void;
        remove: () => void;
    };
    clear(scope?: string, agent?: string): void;
};
export type LocalAgentActivity = ReturnType<typeof createLocalAgentActivity>;
/** One aggregation for all local channel/thread/message status presentations. */
/** Received, or handed over but not yet on a first step: shown as breathing "Starting". */
export declare function breathing(row: Pick<LocalWork, "state" | "step"> | undefined): boolean;
export declare function localActivity(snapshot: {
    local?: readonly LocalWork[];
} | undefined, channelId: string, threadRootId?: string): Map<string, Readonly<{
    scope: string;
    agent: string;
    channelId: string;
    messageId: string;
    threadRootId: string;
    /** The request is in this thread; absent means channel-level work. */
    thread?: true;
    /** The request is in a relay-verified Solo chat, not a DM or channel. */
    soloChat?: true;
    /** The Solo chat's existing display name when this work started. */
    conversationName?: string;
    state: LocalWorkState;
    startedAt: number;
    /** This run's messages still awaiting publication acknowledgement. */
    publishing?: number;
    /** Recent messages this run published here; their relay echoes are not separate alerts. */
    replyMessages?: readonly Readonly<{
        id: string;
        acknowledgedAt: number;
    }>[];
    /** Recent publication IDs retained with this work entry for transcript navigation,
     * independently of notification echo expiry. Capped at 512 per entry. */
    publishedMessageIds?: readonly string[];
    error?: string;
    /** Latest live step, as the harness named it; display only. */
    step?: WorkStep;
    /** The owner hid this error here; the outcome remains as evidence. */
    dismissed?: true;
    /** Its harness can stop the turn it is in. */
    stoppable?: true;
    /** It can be asked again once it fails. */
    retryable?: true;
}>>;
export declare function localWorkLabel(row: Pick<LocalWork, "state" | "error" | "step">): string;
export declare function stepText(step: WorkStep): string;
