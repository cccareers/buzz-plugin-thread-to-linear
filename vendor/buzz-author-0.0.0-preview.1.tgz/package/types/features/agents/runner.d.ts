import type { Agent, AgentAttention, AgentVoicePipe, AgentType, AgentHandle, AgentCreationInput, AgentReadout, AgentUpdateInput, TeamReadout, TeamUpdateInput, AgentHandoff, RegisteredAgentType, Trigger } from "./service";
import type { LocalAgentActivity } from "./local-activity";
import { type RelayEvent } from "../relay/events";
import { type PluginTrigger } from "../agent-harness/plugin-wake";
import type { LiveBatch } from "../relay/incoming";
import type { RelaySession } from "../relay/session";
import type { ChannelSummary } from "../relay/contracts";
import { type AttentionObject, type TimerState } from "./attention";
import { type ClassifierAvailability } from "./attention-objects";
import { type ClassifierContext } from "./classifier";
import type { Decisions } from "../decisions/service";
import { type AgentEventTemplate, type AgentsNative } from "./native";
import type { AgentKey } from "./membership";
import { type AgentRecord, type TimerProgress } from "./store";
import type { Start } from "./agent-start";
import { type Checkpoint } from "./catch-up";
import type { Interrupted } from "./interrupted";
import type { DeviceSettings } from "../../shared/device-settings";
/** The longest run deadline an agent type may ask for. */
export declare const TIMEOUT_LIMIT_MS: number;
/** The session's live connection: `since` is when it last connected, and is
 * absent while it is down; `epoch` counts its connects; `start` is when its
 * listener started, from which live events, replay included, are heard. */
export type Connection = {
    epoch: number;
    start: number;
    since?: number | undefined;
};
/** An agent's community while it is live: one object for as long as its
 * session lasts. */
export type LiveCommunity = {
    readonly session: Pick<RelaySession, "read" | "readRemote" | "live" | "attendPending">;
    /** Aborts when the session is replaced, so no work outlives it. */
    readonly controller: AbortController;
    readonly connection: Connection;
};
/** An agent's membership in a community, which has a runner of its own. */
export type RunnerMember = Readonly<{
    key: AgentKey;
    pubkey: string;
    relay: string;
    type: string;
    protectionRevision?: number | undefined;
    /** The partition its community's activity is kept under. */
    scope: string;
}>;
/** What the runner needs of its host. Each agent it names is a membership,
 * by its key. */
export type RunnerHost = {
    /** Session controls refresh when this copy gains or loses native custody. */
    ownershipChanged?(): void;
    /** The agent, while its community is live to run it in. */
    ready(key: AgentKey): Agent | undefined;
    /** A running agent, in any community. */
    agent(key: AgentKey): Agent | undefined;
    /** Whether the agent is in the event's channel, or undefined while its
     * roster is only the one saved on disk and the relay has not confirmed it. */
    member(agent: Agent, event: Pick<RelayEvent, "tags">): boolean | undefined;
    /** Whether the agent may read the event's channel: it is in it, or the
     * channel is public; undefined as for `member`. Only a member may be
     * delivered to. */
    reads(agent: Agent, event: Pick<RelayEvent, "tags">): boolean | undefined;
    /** Whether the event's channel is a DM between the agent and one other. */
    dm(agent: Agent, event: RelayEvent): boolean;
    /** Whether the event came as it would have with no watch keeping channels
     * live or looking them up; one heard `live`, or read by catch-up. */
    unattended(agent: Agent, event: RelayEvent, live: boolean): boolean;
    /** While the owner is still starting this chat, settles once it can take
     * the agent's events; undefined otherwise. */
    starting?(agent: Agent, channelId: string): Promise<void> | undefined;
    /** Its community, while live. */
    community(agent: Agent): LiveCommunity | undefined;
    /** Arms saved composer follow-ups behind these exact interrupted requests. */
    resumeFollowUps?(agent: Agent, turns: Readonly<Record<string, string>>): void;
    abandonFollowUps?(agent: Agent, turns: Readonly<Record<string, string>>): void;
    /** Every saved record, whose watches' catch-up progress is kept. */
    records(): readonly AgentRecord[];
    /** Catch-up progress, as saved. */
    checkpoints: {
        read(): Readonly<Record<string, Checkpoint>>;
        /** Throws when storage refuses it. */
        write(checkpoints: Readonly<Record<string, Checkpoint>>): void;
    };
    /** Mention turns working when the page went away, as saved. */
    interrupted: {
        read(): Interrupted;
        /** Saves the agent's turns. Throws when storage refuses it. */
        write(key: AgentKey, turns: Readonly<Record<string, string>>): void;
        /** This copy began or stopped holding an agent with saved turns. */
        changed(): void;
    };
    /** The partition its community's activity is kept under, while live. */
    scope(agent: Agent): string | undefined;
    /** Whether a plugin that shows Attention is on; Attention runs only then. */
    attentionShown(): boolean;
    /** Whether plugins have finished starting. */
    pluginsSettled(): boolean;
    /** Its record as its attention handle reads it; throws once it is gone. */
    record(key: AgentKey): AgentRecord;
    /** Changes its record after the changes sent before it, from the newest
     * saved record; settles with the saved record once it is saved, and
     * rejects when `apply` throws or the save fails. */
    change(key: AgentKey, apply: (record: AgentRecord) => AgentRecord | Promise<AgentRecord>): Promise<AgentRecord>;
    /** Whether a change other than timer progress is waiting or saving. Its
     * timers wait for it, since it may rearm, restart or remove one. */
    changing(key: AgentKey): boolean;
    /** Its timers' run state, with progress still being saved. */
    timers(key: AgentKey): Readonly<Record<string, TimerState>>;
    /** Saves a timer pass's progress. Its timers see it at once, and it stays
     * in memory even if the save fails, so a timer does not run again at once. */
    progress(key: AgentKey, progress: TimerProgress): void;
    /** The team sections of its prompt; empty without a team. */
    team(key: AgentKey): string;
    /** What its next run starts with, from this device's storage only. */
    start(agent: Agent): Start<unknown> | Promise<Start<unknown>>;
    protection?(agent: Agent): AgentHandle["protection"];
    agentTypes(): ReturnType<NonNullable<AgentHandle["agentTypes"]>>;
    createAgent(agent: Agent, input: AgentCreationInput): Promise<Readonly<{
        requestId: string;
        saved: false;
    }>>;
    updateAgent(agent: Agent, input: AgentUpdateInput): Promise<Readonly<{
        requestId: string;
        saved: false;
    }>>;
    readAgents(agent: Agent, target?: string): Promise<AgentReadout | readonly AgentReadout[]>;
    readTeams(agent: Agent, target?: string): Promise<TeamReadout | readonly TeamReadout[]>;
    updateTeam(agent: Agent, input: TeamUpdateInput): Promise<Readonly<{
        requestId: string;
        saved: false;
    }>>;
    /** This device's plugins as the agent's handle offers them. */
    plugins?(agent: Agent): AgentHandle["plugins"];
    /** Wakes the agent in another of its conversations, as its own handoff. */
    handoff(agent: Agent, handoff: AgentHandoff): void;
    /** The owner's channel templates as the agent's handle offers them. */
    templates(agent: Agent): ReturnType<AgentHandle["templates"]>;
    /** The owner's thread tabs as the agent's handle offers them. */
    tabs(agent: Agent): ReturnType<AgentHandle["tabs"]>;
    /** Buzz settings on this device, where there are any. */
    settings?(): DeviceSettings | undefined;
    /** Whether watch classifiers can run here. */
    classifier(): ClassifierAvailability;
    /** The decisions service that runs classifiers, where there is one. */
    decisions(): Decisions | undefined;
    /** The event's surroundings for the classifier. */
    context(agent: Agent, event: RelayEvent): Promise<ClassifierContext>;
    /** A person's name as the agent's community shows it. */
    displayName(agent: Agent, pubkey: string): string | null;
    /** Signs, reads and claims as each agent; absent where agents cannot run. */
    custody: Pick<AgentsNative, "claim" | "release" | "publish" | "query" | "effectiveEdit" | "searchProfiles" | "upload" | "media" | "gitAuth" | "remember"> | undefined;
    /** This device's view of each agent's work. */
    activity: LocalAgentActivity;
    /** The event's channel as the agent's community lists it now. */
    channel(agent: Agent, event: Pick<RelayEvent, "tags">): ChannelSummary | undefined;
    /** Whether a mention in `channel` continues the agent's owner's Solo chat,
     * so its turn answers, and shows typing, at channel top level. */
    soloChat(agent: Agent, channel: string, signal: AbortSignal): Promise<boolean>;
    /** The agent wrote this memory through its handle. */
    remembered(key: AgentKey, slug: string, body: string | null): void;
    woke?(key: AgentKey, object: AttentionObject, events?: readonly RelayEvent[]): void;
    /** A run of the agent ended, with everything it handed to `workingUntil`. */
    finished(key: AgentKey): void;
    /** A harness's title for the conversation a mention started; may name a Solo chat. */
    named(agent: Agent, event: RelayEvent, title: string): void;
};
export declare class AgentRunners {
    private readonly host;
    /** Whether each event catch-up read may address its agent, as `unattended`
     * said when it was read: one waiting for room keeps what it arrived as. */
    private readonly readAddressable;
    private readonly sourceJobs;
    private readonly failedSources;
    /** A terminal producer retains its registration until every queued turn settles. */
    completeSource(key: AgentKey, object: AttentionObject): Promise<void>;
    private readonly runners;
    /** Holds newly joined memberships while their global provider/policy changes. */
    private readonly transitions;
    /** Each agent's last claim or release, which its next waits for. */
    private readonly custody;
    /** Agents whose community was live at the last resume. */
    private connected;
    /** Catch-up progress of each watch stream, as saved. */
    private checkpoints;
    /** By agent, its catch-up running or last run. */
    private passes;
    /** By community, for its connect, when each channel's route was first seen
     * live since it last was not. A route that comes back covers only what is
     * sent after that, not what it missed while down. */
    private liveSince;
    /** Streams seen off (their watch disabled or the agent's attention off)
     * since the host started. One turned on starts from then, so it wakes
     * nothing from the time it was off; across a restart, its saved
     * checkpoint, moved while it was off, does the same. */
    private quiet;
    /** When each stream started in this copy: turned on, added, or shown. A
     * route its watch's channel then gets replays a few minutes from before
     * that, which must not wake it. */
    private started;
    /** Whether startup is over for Attention: plugins have finished starting,
     * or Attention has been shown, since this copy started. */
    private settled;
    /** Whether Attention is still waiting for startup, so neither its checkpoints
     * nor the live events it would hear can be decided yet. */
    private starting;
    /** Whether live events are held until startup ends. */
    private heldForStartup;
    /** Mention turns working now, which closing or reloading the app would
     * stop, and those the app left working last time until they are given
     * again or forgotten, as saved. */
    private turns;
    /** The turns the app left working last time, by agent, until the owner
     * forgets them, or resumes them and each agent's are read again. */
    private left;
    /** The turns the app left working last time, as this page started: only
     * Resume gives them again, never a replay or live delivery. */
    private readonly stopped;
    /** The agents whose `left` the owner chose to resume. */
    private resuming;
    private workingNow;
    private readonly workingListeners;
    constructor(host: RunnerHost);
    /** Whether any agent has a job in a lane or a turn still working. */
    isWorking(): boolean;
    subscribeWorking(listener: () => void): () => undefined;
    private noteWorking;
    /** Agents with turns the app left working last time, until the owner
     * resumes or forgets them. */
    interrupted(): ReadonlySet<string>;
    /** Gives each of `keys` again the turns it was left working on, once
     * its community is connected. */
    resumeInterrupted(keys: readonly AgentKey[]): void;
    /** Forgets the turns the app left `keys` working on last time. */
    dismissInterrupted(keys: readonly AgentKey[]): void;
    /** Keeps one runner for each saved agent: a deleted one's is retired, and a
     * replaced type aborts its run. Hiding Attention voids the watch work it
     * queued, even if it is shown again before that work would run. */
    reconcile(identities: readonly RunnerMember[], types: ReadonlyMap<string, RegisteredAgentType>): void;
    /** Resumes runners whose queue paused while their community was not live,
     * and claims or releases each agent as its community goes live or not, so
     * another host takes over without waiting for an event or tick. `ready` is
     * the agents whose community is live now. */
    resume(ready: ReadonlySet<string>): void;
    /** Wakes each runner, which starts any timer that is due. */
    tick(): void;
    /** Wakes the agent's runner, as when the changes its timers wait for are
     * saved: one due meanwhile starts now, not at the next tick. */
    wake(key: AgentKey): void;
    /** Queues a plugin's wake in the agent's mention lane. Throws when this
     * copy does not run the agent, or the lane is full. */
    wakeIn(key: AgentKey, trigger: PluginTrigger): void;
    wakeSource(key: AgentKey, trigger: Extract<Trigger, {
        type: "source";
    }>, object: AttentionObject, sourceCurrent: () => boolean): void;
    /** Whether this copy runs the agent: its type can run it, and no other
     * copy of the app holds it. */
    runs(key: AgentKey): boolean;
    /** Leaves `text` for the agent's next turn in this conversation, while this copy
     * runs it. */
    note(key: AgentKey, channelId: string, text: string, root?: string): boolean;
    private assertProtected;
    /** Resolve voice exactly as a text launch; the owning plugin retains its handle. */
    openVoice(seat: AgentVoicePipe, voice: NonNullable<AgentType["voice"]>, pluginId?: string): Promise<Readonly<{
        input(samples: number[]): void;
        close(): void | Promise<void>;
    }>>;
    /** The agent's handle outside any run, while this copy runs it with a
     * type of `pluginId` when specified, not changing it, and its community is live. Each
     * call through the handle checks that again, so a kept handle stops
     * working while it no longer holds, and for good once the agent's type
     * or its plugin is replaced. `run` adds what only the agent itself gets,
     * such as device settings, for a connection that acts as the agent. */
    handle(key: AgentKey, pluginId?: string, run?: boolean): Readonly<{
        key: AgentKey;
        protection?: import("../agent-protection/service").AgentProtection | undefined;
        pubkey: string;
        relay: string;
        name: string;
        owner: string;
        agentTypes?(): readonly Readonly<{
            key: string;
            title: string;
        }>[];
        createAgent?(input: AgentCreationInput): Promise<Readonly<{
            requestId: string;
            saved: false;
        }>>;
        updateAgent?(input: AgentUpdateInput): Promise<Readonly<{
            requestId: string;
            saved: false;
        }>>;
        readAgents?(agent?: string): Promise<AgentReadout | readonly AgentReadout[]>;
        readTeams?(team?: string): Promise<TeamReadout | readonly TeamReadout[]>;
        updateTeam?(input: TeamUpdateInput): Promise<Readonly<{
            requestId: string;
            saved: false;
        }>>;
        plugins?: import("../../plugins/requests").AgentPlugins | undefined;
        handoff?(handoff: AgentHandoff): void;
        publish(event: AgentEventTemplate, check?: () => void): Promise<RelayEvent>;
        query(filters: readonly object[]): Promise<RelayEvent[]>;
        effectiveEdit(id: string, channel: string): Promise<RelayEvent>;
        searchProfiles(query: string, limit: number): Promise<RelayEvent[] | undefined>;
        upload(data: string, mime: string): Promise<import("./native").AgentUpload>;
        media(url: string): Promise<import("./native").AgentMedia>;
        gitAuth(owner: string, repo: string): Promise<import("./native").GitAuth>;
        remember(slug: string, body: string | null, after: number): Promise<RelayEvent>;
        templates(): readonly Readonly<{
            name: string;
            canvas: string;
            agents: readonly string[];
        }>[];
        tabs(): ReturnType<typeof import("../../bundled/channels/useChannelTabState").channelTabs> | undefined;
        settings?: DeviceSettings;
        notes?(channelId: string, root?: string): readonly string[];
        restoreNotes?(channelId: string, notes: readonly string[], root?: string): void;
        attention: AgentAttention;
    }> | undefined;
    /** Whether another copy of the app runs an agent this one could. */
    yielded(key: AgentKey): boolean;
    /** Whether a change of type holds the agent's runner now. */
    transitioning(key: AgentKey): boolean;
    /** Session mutations require a current, successful native custody check. */
    control<T>(key: AgentKey, change: () => Promise<T>): Promise<T>;
    /** Runs `change` while a change of type holds the agent's idle runners, in
     * every community it is in, as its type is theirs: no turn starts
     * meanwhile, and their queues resume after. Refused while a turn is
     * working, and unless this copy of the app holds the agent. */
    retype<T>(key: AgentKey, name: string, change: () => Promise<T>): Promise<T>;
    /** Retires every runner, as when the host stops. */
    clear(): void;
    private runner;
    private retire;
    /** The runner's event watches for the agent's current attention. */
    private watches;
    /** Gives a community's live events, and replayed ones from `since` on, to
     * the agents in it. */
    dispatch(batch: LiveBatch, heard: (agent: Agent) => boolean, since: number): void;
    /** The agent's watches whose streams started after a replayed `event`.
     * Asked as it is admitted: an attention change starts its streams in the
     * same call that saves it, before anything is admitted again. */
    private before;
    private hasSeen;
    /** An agent never hears itself. */
    private isOwn;
    private markSeen;
    /** Whether the agent can take `mentions` more mentions and an attention
     * job for each of `interests`, `classified` events of them first through
     * the classifier, without dropping any. Every attention job is admitted
     * here, and one being classified keeps the room it was admitted to. */
    private fits;
    /** Attention jobs waiting for the Interest's lane. */
    private waitingIn;
    /** Whether the agent has room for every job `triggers` make. One that
     * makes more jobs than an idle agent takes goes when it is idle, and loses
     * the excess as live delivery would. */
    private takes;
    /** Delivers backlogged events, oldest first, while the agent has room for
     * every job each makes; the rest wait for a later tick. Each is matched
     * against the agent's attention as it is when it is delivered. */
    private admit;
    /** Gives the agent `event` once, however many times it arrives. */
    private hear;
    /** Saves `event` as heard by each of the agent's streams it is in and has
     * not passed yet, so catch-up after a restart does not give it again. */
    private heardLive;
    /** Adds `event` to what the stream heard past its checkpoint, unless it is
     * not past it; returns whether it did. */
    private heardIn;
    /** Sets a stream's checkpoint, keeping what it heard live past it as well
     * as what the checkpoint itself lists as heard. */
    private setCheckpoint;
    /** Keeps each agent's catch-up going: on start, and after each connect, its
     * event watches read the events they missed from their saved checkpoints,
     * up to the connect. From then on live events cover a stream whose channel
     * is live, of kinds live hears, so while the connection stays up a `tick`
     * moves its checkpoint to now; a quit or a drop leaves the checkpoint where
     * the next catch-up starts. Any other stream, and one whose checkpoint is
     * still before the connect or before its route came back, is read again,
     * up to a little before now. */
    catchUp(tick: boolean): void;
    /** Once the owner chose to resume them, gives the agent again the mention
     * turns the app left it working on, when its community is connected: each
     * read again from the relay, as only its id was saved. Each stays saved
     * until its new turn ends, so closing the app again first loses none; one
     * the relay no longer has, or that was given meanwhile, is forgotten. A
     * failed read leaves them for the next try. */
    private resumeTurns;
    /** Saves the mention `id` as working, in `channel` or "" without one. */
    private mark;
    private unmark;
    /** Saves `key`'s turns only: another program may run the others. */
    private saveTurns;
    /** Reads each stream's missed events through `upper`, or its own `upper`
     * when that is a function, a window at a time,
     * and delivers them oldest first, in batches, saving its checkpoint after
     * each. A stream with an `overlap` keeps that many seconds below its
     * window open for its next read. A watch's streams are read one after
     * another; once all of them are read, its live events that waited go on. */
    private readMissed;
    /** Gives the agent the first of `events` it has room for, once the rosters
     * their watches need are confirmed: a checkpoint saved past an event never
     * drops or evicts it. One that makes more jobs than the agent has room for
     * goes to its watches a few at a time. Each watch they match gets one
     * job with all of its events, oldest first, so a long absence does not
     * cost a turn per message. One from before the listener started wakes only
     * watches, so a mention from before the app listened is not answered late.
     * A later one live would have heard, mentions too; catch-up may read it
     * before replay does, which then skips it as seen. Returns how many events
     * were taken, or 0 when an edit since ends the pass: the next one reads them
     * again. */
    private caughtUp;
    /** Delivers the longest run of `events`, oldest first, whose jobs the agent
     * has room for now; returns how many it took, or 0 for none. With no room
     * for all of the first one's, what room there is goes to some of them. */
    private batch;
    /** Gives a missed event that makes more jobs than the agent has room for
     * to as many of its watches as there is room for now; later tries give it
     * to the rest, and only then is it taken, so its checkpoint never passes a
     * watch that did not get it. It is seen from the first, so a replay does
     * not give it again. */
    private fanOut;
    /** Queues catch-up's mentions, and one job per watch with its events. */
    private give;
    /** Whether a catch-up event read for one watch is also one `trigger`'s
     * watch missed: it is past that watch's stream's checkpoint, so a watch
     * added or widened since wakes for nothing older. */
    private missed;
    /** Saves the checkpoints of watches that still exist. Unsaved, catch-up
     * starts from the last saved one again, which `seen` dedupes until a
     * restart, and each stream's saved `heard` after one. */
    private saveCheckpoints;
    /** Matches the held events of a community's agents again, as its rosters
     * change: one now confirmed wakes the watches it matches, or none. They go
     * back through the backlog, ahead of what came after them: a confirmed
     * roster can release more than the agent has room for at once, and each is
     * already seen, so one dropped here would never come again. */
    releaseHeld(heard: (agent: Agent) => boolean): void;
    private deliver;
    private submit;
    /** Keeps a live event of a watch catching up until it has, as Janet stages
     * them. Past Janet's bounds the watch stops waiting: what it kept goes on
     * now, out of order, rather than be lost. */
    private wait;
    /** Sets the watches catching up; the live events of any others that
     * waited go on, oldest first, as the agent has room. */
    private setCatching;
    /** Voids the agent's queued and waiting watch work. */
    private dropWatchWork;
    /** Runs a matched watch's classifier, then queues the event if it passes.
     * The classifier runs after the watch's selectors and filter, and before the
     * event takes a queue slot, as in Janet. Without a key, or when it fails,
     * the event passes and its turn is told why. Results queue in the order the
     * events arrived, whichever call finishes first. A catch-up's events are
     * each classified, and the ones that pass queue together. */
    private classified;
    /** The classifier's outcome for one event, or undefined when it does not
     * pass or should no longer be acted on. */
    private classify;
    /** What `event` wakes now, and whether other matching watches still wait
     * for its channel's roster to be confirmed. Mentions wake an agent only in
     * what the owner's app hears for the owner: an event it has only because
     * watches keep its channel live, or looked the channel up, is not
     * `addressable`, and only watches hear it. */
    private heard;
    /** The job as it should run now, or undefined when it should not run: a
     * watch's event is matched again against the agent's current attention, so
     * one turned off, disabled, removed, replaced or changed since it was
     * queued wakes nothing, even if it now matches again. */
    private current;
    /** Whether `job`, already started, should still run: the rule `current()`
     * applies to a queued job, asked again for work a type queued itself. */
    private stillCurrent;
    private dueTimer;
    /** Queues `job`, or drops it when the lane is full; returns whether queued. */
    private enqueue;
    /** Drops the queued mentions. `forget` forgets the resumed ones saved as
     * working too; otherwise they stay saved for the copy that runs the agent. */
    private dropMentions;
    private showWork;
    private drain;
    /** The job a free lane starts next, taken from its queue; its `job` is
     * undefined when the one taken is no longer current. */
    private next;
    /** Runs `job` in `lane`, holding the lane until it may take another. */
    private start;
    /** The agent as `run` holds it. */
    private handleFor;
    /** Counts a run as working until it and everything it handed to
     * `workingUntil` have settled, however long that takes. A
     * mention run is shown typing in its thread meanwhile, from its first
     * `workingUntil`: a runtime that ignores the mention never shows it. Its
     * activity stays on this device. */
    private working;
    private claimed;
    private claim;
    /** Runs `step` once the agent's earlier claims and releases settle.
     * Custody holds the agent, which its runners in each community share, so
     * one never lets go while another's claim is answered but not yet known. */
    private custodied;
    /** The notice lists an agent's saved turns only while this copy holds it,
     * so a change in holding lists it again. */
    private heldChanged;
    /** Claims exclusively for a provider migration. Unlike turn execution,
     * uncertainty is unsafe here because changing native type is destructive. */
    private claimForRetype;
    private release;
    private rootInChannel;
    /** The agent's attention as its handle offers it, until `lifetime` ends.
     * Reads the saved record each call, so it is current however long the run
     * lasts. */
    private attention;
    private require;
    private publish;
}
