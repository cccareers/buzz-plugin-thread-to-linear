import type { Agent } from "./service";
import type { EventData, ReadFilter } from "../relay/events";
import type { AgentStore } from "./store";
import { type AgentKey } from "./membership";
export declare const CATCH_UP_KEY = "buzz.agents.catch-up.v1";
/** Events in one read, as Janet's catch-up pages are. */
export declare const CATCH_UP_PAGE = 16;
/** The most pages one window reads, and its most bytes, as Janet bounds a
 * named channel's window. Past either, the oldest missed events are skipped. */
export declare const CATCH_UP_PAGES = 256;
export declare const CATCH_UP_BYTES: number;
/** Every event of the stream created at or before `through` was delivered
 * or skipped. While a window (`through`, `upper`] is being delivered, `after`
 * is the last event delivered of it, in delivery order: oldest first, ties by
 * id. A restart goes on after it, up to `upper`. A window read with an
 * overlap has no `after`: it lists what it delivered as heard, and keeps
 * `through` as far behind as the relay can still store an event late, so a
 * later read finds one at any place in that order. `heard` are later ones
 * already heard live or delivered, which catch-up skips too. `read`, when
 * later than `through`, is how far the stream was last read: one read again
 * with an overlap keeps `through` behind it. `hidden` marks one moved while
 * no plugin showed Attention: once one does, even after a restart, it starts
 * from then. */
export type Checkpoint = Readonly<{
    through: number;
    upper?: number;
    read?: number;
    after?: Readonly<{
        created_at: number;
        id: string;
    }>;
    heard?: readonly Readonly<{
        created_at: number;
        id: string;
    }>[];
    hidden?: true;
}>;
/** Events each stream keeps as heard past its checkpoint. A tick moves the
 * checkpoint past them every few seconds while the app listens; past this,
 * `heardOf` moves it past the oldest. */
export declare const HEARD_LIMIT = 256;
/** The most heard events a stream keeps while it cannot move past them, as
 * when its reads fail while live goes on, or while a window read with an
 * overlap is given: twice the most one window reads. Past it, the oldest go
 * anyway. */
export declare const HEARD_MOST: number;
/** Seconds a stream that live does not cover reads again below the top of
 * its last read: as far as live resumes behind a drop. The relay accepts an
 * event whose time is up to its drift behind when it stores it, and the
 * clocks can disagree by a little more, so a later read must still reach it. */
export declare const POLL_OVERLAP: number;
export type Checkpoints = Readonly<Record<string, Checkpoint>>;
/** One watch's history in one channel, or in every channel it may read. */
export type Stream = Readonly<{
    key: string;
    slug: string;
    channel?: string;
    /** The watch's kinds; a watch of every kind reads those live hears, as a
     * relay read must name its kinds. */
    kinds: readonly number[];
    since: number;
    enabled: boolean;
}>;
type Position = Pick<EventData, "id" | "created_at">;
/** Delivery order: oldest first, ties by id. */
export declare const oldestFirst: (a: Position, b: Position) => number;
/** Whether `event` is of the stream's kinds and of its channel. */
export declare const inStream: (stream: Pick<Stream, "kinds" | "channel">, event: Pick<EventData, "kind" | "tags">) => boolean;
/** The key of a membership's watch's stream in one channel, or in every
 * channel. */
export declare const streamKey: (agent: AgentKey, slug: string, channel?: string) => string;
/** Whether `event` of a stream is past its checkpoint: not delivered or
 * skipped yet. */
export declare const undelivered: (checkpoint: Checkpoint, event: Position) => boolean;
/** `checkpoint` with `heard` as what it heard past it: each once, oldest
 * first. Past `HEARD_LIMIT` of them the oldest go, and `through` moves up to
 * the newest of those, so none is given again after a restart; but never
 * past what was read, nor into the second of a window's last delivered
 * event, so no event left to read is passed over. Those it cannot move past
 * stay, up to `HEARD_MOST`: a later read or tick moves past them. */
export declare function heardOf(checkpoint: Checkpoint, heard: readonly Position[]): Checkpoint;
/** Each agent membership's catch-up progress has its own key, so programs
 * that run different agents and share this storage never write over each
 * other's progress. */
export declare const CATCH_UP_PREFIX = "buzz.agents.catch-up.v1:";
export declare const catchUpKey: (agent: AgentKey) => string;
/** Every agent's progress: its own key's, or else the old shared value's. */
export declare function readCheckpoints(storage: AgentStore): Checkpoints;
/** Saves the progress of each agent whose progress changed since `saved`,
 * this program's last save or read, in its own key, and removes the key of
 * an agent with none left. An agent this program did not move is never
 * written, so it keeps what the program that runs it saved, even when this
 * program's copy of it is older. Settles once every write is saved. */
export declare function writeCheckpoints(storage: AgentStore, checkpoints: Checkpoints, saved: Checkpoints): Promise<void>;
/** Moves progress from the old value that held every agent's into one key
 * per agent, then removes it, as `splitLegacyRecords` does records. A key
 * is only added where none is saved: a program that starts from the old
 * value after another moved it, and ran its agents on, keeps their newer
 * progress. */
export declare function splitLegacyCheckpoints(storage: AgentStore): Promise<void>;
/** The agent's streams: one for each channel of each event watch, enabled or
 * not. */
export declare function streamsOf(agent: Pick<Agent, "key" | "attention">): Readonly<{
    key: string;
    slug: string;
    channel?: string;
    /** The watch's kinds; a watch of every kind reads those live hears, as a
     * relay read must name its kinds. */
    kinds: readonly number[];
    since: number;
    enabled: boolean;
}>[];
/** A stream's missed events to deliver, oldest first, and the checkpoint
 * that says what of its window is already done. */
export type Window<Event extends Position> = Readonly<{
    events: readonly Event[];
    /** The window's upper bound. */
    upper: number;
    /** Delivered or skipped so far; saved before any event is delivered. */
    checkpoint: Checkpoint;
    /** Older missed events were skipped: the window passed its bounds. */
    skipped: boolean;
    /** Every event read of the window, delivered now or before. */
    read: readonly Position[];
}>;
/** Reads the stream's missed events through `upper`, or undefined when there
 * are none to read. A window read only in part before goes on after the last
 * event it delivered, up to its own upper bound, which may be older than
 * `upper`. Pages are read newest first; past `CATCH_UP_PAGES` pages or
 * `CATCH_UP_BYTES` bytes the read stops, and the oldest second it reached is
 * skipped with everything older, so no event of a second is left half
 * delivered. Tags are not sent: the relay applies most tag filters after its
 * page limit, so a page could come back empty with older matches left. */
export declare function readWindow<Event extends Position>(stream: Stream, saved: Checkpoint | undefined, upper: number, read: (filter: ReadFilter) => Promise<readonly Event[]>): Promise<Window<Event> | undefined>;
/** The checkpoint once `last`, the newest event delivered of the window, and
 * every one before it are; or, with no `last`, once all of it is. */
export declare function delivered(window: number, last?: Position): Checkpoint;
/** The checkpoint once `given`, the window's events delivered so far, oldest
 * first, are. One with an `overlap` saves no cursor: it lists them as heard,
 * with what it `heard` before, and moves `through` only to where the relay
 * can no longer store an event late, so a read after an interruption still
 * finds one stored late anywhere among them. */
export declare function admitted(window: Window<Position>, given: readonly Position[], heard?: readonly Position[], overlap?: number): Checkpoint;
/** The checkpoint once all of `window` is delivered, keeping its last
 * `overlap` seconds open so the next read finds an event the relay stores
 * late with an older time. Every event read of them, and every one already
 * `heard`, stays heard, so none is given twice. Past `HEARD_LIMIT` of them,
 * the overlap shrinks to keep the newest. */
export declare function finished(window: Window<Position>, heard?: readonly Position[], overlap?: number): Checkpoint;
export {};
