import type { AttentionSource } from "./attention-sources";
/** Saved identities belong to their bundled owners, including legacy aliases. */
export declare const bundledAttention: {
    readonly providers: readonly [{
        readonly plugin: "buzz.agents";
        readonly id: "command";
        readonly provider: "attention/command";
    }, {
        readonly plugin: "buzz.github";
        readonly id: "github-pr";
        readonly provider: "attention/github-pr";
    }];
};
type Sources = {
    addAttentionSource(source: AttentionSource): void;
};
/** Attention owns when the producer runs and where output goes. The process
 * host kills descendants on cancellation; no owner credentials are passed as arguments. */
export declare function registerAttention(ctx: {
    agents: Sources;
}, ids?: readonly "command"[]): void;
export {};
