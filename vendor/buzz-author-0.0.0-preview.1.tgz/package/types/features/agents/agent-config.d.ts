import type { RelayEvent } from "../relay/events";
import { type AgentStore } from "./store";
import { type ArtifactType } from "./agent-config-artifacts";
export declare const CONFIG_STORAGE_KEY = "buzz.agents.config.v1";
export type ArtifactState = "present" | "invalid" | "deleted" | "unavailable";
export type Subject = Readonly<{
    owner: string;
    community: string;
    /** The agent pubkey, or the team id, whose config channel this is. */
    subject: string;
    channel: string;
    type: ArtifactType;
}>;
type Entry = {
    state: ArtifactState;
    head?: RelayEvent;
    problem?: string;
    generation: number;
    sequence: number;
    syncedAt?: number;
};
/** What a writer saw before its first await. */
export type Captured = Readonly<{
    generation: number;
    sequence: number;
}>;
/** A strong read's answer for one artifact. `failed` covers partial,
 * inaccessible and errored reads: it changes nothing. */
export type ReadResult = Readonly<{
    kind: "head";
    event: RelayEvent;
    problem?: string;
}> | Readonly<{
    kind: "empty";
}> | Readonly<{
    kind: "failed";
}>;
/** `reread`: the caller schedules a fresh strong read. */
export type Applied = "applied" | "unchanged" | "reread";
export declare class AgentConfigStore {
    private readonly storage;
    private stored;
    private readonly listeners;
    constructor(storage?: AgentStore);
    state(subject: Subject): Readonly<Entry>;
    /** Called after any entry changes, live, read or written alike, so starts
     * and running agents re-resolve from the confirmed copy. */
    subscribe(listener: () => void): () => undefined;
    hadVersion: (subject: Subject) => boolean;
    /** The channel `subject` (its `channel` ignored) was last bound in. */
    boundChannel: (subject: Subject) => string | undefined;
    markBound(subject: Subject): void;
    /** Taken by every writer before its first await. */
    capture(subject: Subject): Captured;
    /** A strong read issued at `captured`. Installed only while nothing changed
     * since; otherwise a differing answer is dropped and a fresh read requested. */
    applyRead(subject: Subject, captured: Captured, result: ReadResult): Applied;
    /** A live revision from the binding taken at `generation`. It advances only
     * a successor of the head current now; anything else asks for a read rather
     * than deciding by order of arrival. A retired binding changes nothing. */
    applyLive(subject: Subject, generation: number, event: RelayEvent, problem?: string): Applied;
    /** A live NIP-29 redaction from the binding taken at `generation`.
     * Redacting the head retires it; a retired binding changes nothing. */
    applyRedaction(subject: Subject, generation: number, target: string): Applied;
    /** Community switch, channel reselection, archive, sign-out or loss of
     * access: every in-flight writer's capture becomes stale. */
    rebind(subject: Subject): void;
    /** Set when a head lookup returned a blocking head before any install
     * (migration `blocked`), so local text stops being a launch source. */
    markHadVersion(subject: Subject): void;
    /** Instructions for a start from the synced copy. Pure over storage. */
    instructions(subject: Subject): Readonly<{
        ok: true;
        text: string;
    }> | Readonly<{
        ok: false;
        state: ArtifactState;
        problem?: string;
    }>;
    private fromRead;
    private write;
    private put;
    private save;
    private load;
}
/** One synced setting: free text or one of a fixed set. */
export type SettingRule = "string" | readonly string[];
export type SettingsSchema = Readonly<Record<string, SettingRule>>;
/** Strictly checks a settings object against a plugin's allowlist: unknown
 * keys, wrong types and out-of-set values are errors, never defaulted. */
export declare function settingsProblem(schema: SettingsSchema, value: unknown): string | undefined;
/** The allowlisted fields of a plugin's config, for publishing. */
export declare const pickSettings: (schema: SettingsSchema, config: object) => Record<string, string>;
/** A config with its synced fields taken only from accepted `settings`: a
 * field they leave out gets the plugin's default, never this device's value.
 * Everything outside the schema stays this device's. */
export declare const withSynced: <C extends object>(schema: SettingsSchema, defaults: C, config: C, settings: Readonly<Record<string, string>>) => C;
/** A `buzz.agent.settings` body for a plugin: `{version: 1, agentType,
 * settings}`. Another agent type, or a value the plugin can't honour, is
 * invalid for start; one naming no type is the agent's (NIP-AP). */
export declare function syncedSettings(content: string, agentType: string, schema: SettingsSchema): Readonly<{
    settings: Record<string, string>;
}> | Readonly<{
    problem: string;
}>;
/** The error a launch shows instead of running a synced setting its runtime
 * doesn't offer on a default (NIP-AP `buzz.agent.settings`). */
export declare const unsupportedSynced: (name: string, value: string, by: string) => string;
/** The error a launch shows when it can't tell whether its runtime offers a
 * synced setting, which it never runs unchecked (NIP-AP). */
export declare const unverifiedSynced: (name: string, value: string, by: string) => string;
export {};
