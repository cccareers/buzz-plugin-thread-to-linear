import type { AgentStore } from "./store";
/** Copies each old key into memory at once, so reads that follow see it;
 * the promise settles once the copies are saved and their sources removed. */
export declare function migrateAgentStorage(storage: AgentStore): Promise<void>;
