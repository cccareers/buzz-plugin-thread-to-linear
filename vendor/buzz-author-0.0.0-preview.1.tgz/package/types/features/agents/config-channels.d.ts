import { type MemberResult } from "../channel-members/administration";
import type { RelaySession } from "../relay/session";
import { type SnapshotRead } from "./agent-config-artifacts";
export type ConfigFamily = "agent-config" | "team-config";
/** What the relay's NIP-11 document lets config use, or why it can't. */
export type ConfigSupport = Readonly<{
    supported: true;
    maxEventBytes: number;
}> | Readonly<{
    supported: false;
    reason: string;
}>;
/** NIP-AP "Relay support": NIP-CL system channels and labels (`nip-cl`) and
 * NIP-AR artifacts (`nip-ar` with its `artifacts` descriptor), each as its own
 * spec advertises it. The writer also keeps every signed event within the
 * relay's advertised frame limit. */
export declare function configSupport(info: unknown): ConfigSupport;
/** The subject label of an agent's or team's config channel. */
export declare const agentSubject: (pubkey: string) => string;
export declare const teamSubject: (team: string) => Promise<string>;
/** UUIDv5(RFC 4122 URL namespace, "https://buzz.block.xyz/ns/team-import/v1"). */
export declare const BUZZ_TEAM_IMPORT_NS = "e73a27cc-feca-5161-82dd-620356b374a9";
/** The deterministic team id for an imported old Buzz team or a migrated
 * local team (plan §6.3): every device and every rerun computes the same id,
 * so concurrent imports converge on one config channel. */
export declare function importedTeamId(input: Readonly<{
    owner: string;
    community: string;
    source: "old-buzz-team" | "local-team";
    sourceId: string;
}>): Promise<string>;
export type ConfigChannel = Readonly<{
    id: string;
    archived: boolean;
    members?: readonly string[] | undefined;
}>;
export type { MemberResult };
export declare function createConfigChannels(session: RelaySession, owner: string, relay: Readonly<{
    read: SnapshotRead;
    relayAuthor: string;
}>): {
    find: (family: ConfigFamily, subject: string, signal?: AbortSignal) => Promise<ConfigChannel | undefined>;
    teams: (signal?: AbortSignal) => Promise<(Readonly<{
        id: string;
        archived: boolean;
        members?: readonly string[] | undefined;
    }> & {
        label: string;
    })[]>;
    /** Whether `pubkey`'s newest profile carries this owner's NIP-OA proof. */
    owns: (pubkey: string, signal?: AbortSignal) => Promise<boolean>;
    ensure: (family: ConfigFamily, subject: string, name: string, signal?: AbortSignal) => Promise<ConfigChannel>;
    archive: (channel: string, signal?: AbortSignal) => Promise<void>;
    /** Whether the relay's strong, relay-signed metadata shows the channel
     * archived. Anything but exactly one such answer throws; cached metadata
     * never stands in for it. */
    archived(channel: string, signal?: AbortSignal): Promise<boolean>;
    /** Adds `pubkey` as a member of a system config channel it isn't in.
     * Only an agent whose newest profile carries one NIP-OA `auth` tag signed
     * by this owner is added; a local row is no proof of ownership. */
    addMember(channel: string, pubkey: string, signal?: AbortSignal): Promise<MemberResult>;
    /** Removes `pubkey` with whatever role a fresh roster read verifies. */
    removeMember: (channel: string, pubkey: string) => Promise<Readonly<{
        status: "confirmed" | "failed" | "uncertain";
        error?: string;
    }>>;
};
export type ConfigChannels = ReturnType<typeof createConfigChannels>;
