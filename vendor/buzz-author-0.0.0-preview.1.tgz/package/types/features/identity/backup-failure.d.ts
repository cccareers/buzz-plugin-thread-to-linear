/**
 * Why "Backing up your key…" did not complete: the copy the failed page shows
 * and whether Try again can help. Native code names its own kinds and retries
 * them all on its next wake; `unavailable`, `interrupted`, `timeout` and
 * `unknown` are the renderer's. A `cause` is what Settings shows before saying
 * a later Builderlab sign-in tries again: every retryable kind's, and
 * `signed_out`'s, which a new sign-in clears though first run's Try again,
 * sending the same credential, cannot. No message carries a service or IPC
 * answer. A leaf module: vite.config.ts validates the development seed
 * against it through Node's native loader.
 */
export declare const BACKUP_FAILURES: {
    readonly unavailable: {
        readonly message: "Key backup isn’t configured for this build. You can continue without a backup.";
        readonly retryable: false;
    };
    readonly busy: {
        readonly cause: "Another backup of this key is in progress.";
        readonly message: `Another backup of this key is in progress. ${string}`;
        readonly retryable: true;
    };
    readonly interrupted: {
        readonly cause: "The backup was interrupted.";
        readonly message: `The backup was interrupted. ${string}`;
        readonly retryable: true;
    };
    readonly timeout: {
        readonly cause: "Builderlab is taking too long to confirm your backup.";
        readonly message: `Builderlab is taking too long to confirm your backup. ${string}`;
        readonly retryable: true;
    };
    readonly signed_out: {
        readonly cause: "Your Builderlab sign-in is no longer valid, so your key wasn’t backed up.";
        readonly message: "Your Builderlab sign-in is no longer valid, so your key wasn’t backed up.";
        readonly retryable: false;
    };
    readonly not_offered: {
        readonly message: "Builderlab doesn’t offer key backup for this account yet.";
        readonly retryable: false;
    };
    readonly not_linked: {
        readonly message: "This key isn’t linked to your Builderlab account yet, so it can’t be backed up.";
        readonly retryable: false;
    };
    readonly other_key_linked: {
        readonly message: "Your Builderlab account is linked to a different key, so this one can’t be backed up.";
        readonly retryable: false;
    };
    readonly invalid_service: {
        readonly message: "Buzz couldn’t verify Builderlab’s backup service, so your key wasn’t sent.";
        readonly retryable: false;
    };
    readonly refused: {
        readonly message: "Builderlab refused this backup.";
        readonly retryable: false;
    };
    readonly unreachable: {
        readonly cause: "Couldn’t reach Builderlab to back up your key.";
        readonly message: `Couldn’t reach Builderlab to back up your key. ${string}`;
        readonly retryable: true;
    };
    readonly unconfirmed: {
        readonly cause: "Builderlab couldn’t confirm your backup.";
        readonly message: `Builderlab couldn’t confirm your backup. ${string}`;
        readonly retryable: true;
    };
    readonly storage: {
        readonly cause: "Buzz couldn’t save backup progress on this device.";
        readonly message: `Buzz couldn’t save backup progress on this device. ${string}`;
        readonly retryable: true;
    };
    readonly unknown: {
        readonly message: "Your key wasn’t backed up.";
        readonly retryable: false;
    };
};
export type BackupFailureKind = keyof typeof BACKUP_FAILURES;
export declare const isBackupFailureKind: (value: unknown) => value is BackupFailureKind;
