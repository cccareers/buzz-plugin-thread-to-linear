/** How well a label matches typed text, best first. Ranks are whole numbers,
 * so callers can order them and add fractional tie-breaks. */
export declare const MatchRank: {
    readonly exact: 0;
    readonly prefix: 1;
    /** The text starts a later word. */
    readonly wordStart: 2;
    readonly substring: 3;
    /** Each letter continues a run that began at a word start ("tlp" in
     * "team-launch-planning"). */
    readonly wordRuns: 4;
    /** The letters appear in order. */
    readonly inOrder: 5;
};
export type MatchRank = (typeof MatchRank)[keyof typeof MatchRank];
/** How well a label matches typed text (`MatchRank`), or undefined for no
 * match. `positions` are the matched code points of the label, for
 * underlining. */
export declare function matchName(label: string, needle: string): {
    rank: MatchRank;
    positions: number[];
} | undefined;
export declare const matchRank: (label: string, needle: string) => MatchRank | undefined;
