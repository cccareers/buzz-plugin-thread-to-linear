/**
 * The one rule for matching a typed name to a person or agent name. Mentions,
 * New message recipients, the message search author picker and the
 * add-member search use it, so the same text finds the same people. The
 * normative statement and portable fixtures live in the mention rules
 * (src/bundled/mentions/README.md, section 3).
 */
/** A name or query without accents and case. Keeps spaces at the ends. */
export declare const foldName: (text: string) => string;
/**
 * Whether `name` is longer than `query` and continues it with a new word, as
 * `Jose Luis` and `Jose-Luis` continue `jose` but `Josefa` does not. Such a
 * name keeps Space from selecting a shorter exact name.
 */
export declare function extendsName(name: string, query: string): boolean;
/**
 * The one item whose name is exactly `query`, for Space to complete. There is
 * none when two items have that name or any item has a longer name that
 * continues it (`Avery` waits while `Avery Chen` exists). Only items that
 * `canComplete` allows can be chosen, but every item's `longer` names (by
 * default its names) can block one.
 */
export declare function exactName<T>(items: readonly T[], names: (item: T) => readonly string[], query: string, canComplete?: (item: T) => boolean, longer?: (item: T) => readonly string[]): T | undefined;
/**
 * Where `matchPerson` can begin a match in `name`: the folded, trimmed name
 * itself and each later word start, each cut to its first 32 code points. A
 * query matches only where one of these starts with the query's first 32 code
 * points, so a sorted list of them finds matches by search. A name with more
 * than 16 starts is not `complete`: callers must match it directly.
 */
export declare function nameStarts(name: string): {
    starts: string[];
    complete: boolean;
};
/** A query cut to the length of `nameStarts` entries. */
export declare const startKey: (needle: string) => string;
export type PersonMatch = {
    /** 0 equal, 1 name starts with the query, 2 a word equals it, 3 a word starts with it. */
    tier: 0 | 1 | 2 | 3;
    /** Code point indexes of `name` that matched, for underlining. */
    positions: number[];
};
/** The normalized form for comparing and ordering names. Reads the folded
 * names cache, since mentions normalize every name on each keystroke; a
 * query adds one entry per keystroke, within the same bound. */
export declare const normalizeName: (text: string) => string;
/** The tier of `matchPerson`, given `[...normalizeName(query)]`. */
export declare const matchTier: (name: string, foldedQuery: readonly string[]) => 0 | 1 | 2 | 3 | undefined;
/** How `name` matches `query`, or undefined. An empty query matches at tier 0. */
export declare function matchPerson(name: string, query: string): PersonMatch | undefined;
