import { Service, type Context } from "@deepseek-ai/cordis";
import type { ComponentType } from "react";
import { type Contribution } from "../../plugins/contributions";
/** A decorative layer above the shell's own background and below all of its
 * content. The plugin owns what it paints there; the host owns placement. */
export type Backdrop = Readonly<{
    id: string;
    component: ComponentType;
}>;
export type RegisteredBackdrop = Contribution<Backdrop>;
export type Backdrops = Readonly<{
    snapshot(): readonly RegisteredBackdrop[];
    subscribe(listener: () => void): () => void;
    register(backdrop: Backdrop): void;
}>;
declare module "@deepseek-ai/cordis" {
    interface Context {
        /** Read with `ctx.reflect.get("backdrops")` for old-host compatibility. */
        backdrops?: Backdrops;
    }
}
export declare class BackdropsService extends Service implements Backdrops {
    private readonly contributions;
    constructor(ctx: Context);
    snapshot: () => readonly Readonly<Readonly<{
        id: string;
        component: ComponentType;
    }> & {
        key: string;
        pluginId: string;
        revision: string;
    }>[];
    subscribe: (listener: () => void) => () => void;
    register(backdrop: Backdrop): void;
}
