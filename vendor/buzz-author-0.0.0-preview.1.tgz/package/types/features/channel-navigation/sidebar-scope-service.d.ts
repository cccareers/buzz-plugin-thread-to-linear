import { Service, type Context } from "@deepseek-ai/cordis";
import type { ComponentType } from "react";
import { type Contribution } from "../../plugins/contributions";
/** While registered, the sidebar shows only Solo: the All/Solo/Team tabs and
 * page destinations give way to `banner`, and the saved tab returns after.
 * Search and links still open any conversation. */
export type SidebarRestriction = Readonly<{
    id: string;
    scope: "solo";
    banner: ComponentType;
}>;
export type RegisteredSidebarRestriction = Contribution<SidebarRestriction>;
export type SidebarScope = Readonly<{
    snapshot(): readonly RegisteredSidebarRestriction[];
    subscribe(listener: () => void): () => void;
    /** Returns a remover; disabling the plugin removes it too. */
    restrict(restriction: SidebarRestriction): () => void;
}>;
declare module "@deepseek-ai/cordis" {
    interface Context {
        sidebarScope: SidebarScope;
    }
}
export declare class SidebarScopeService extends Service implements SidebarScope {
    private readonly restrictions;
    constructor(ctx: Context);
    snapshot: () => readonly Readonly<Readonly<{
        id: string;
        scope: "solo";
        banner: ComponentType;
    }> & {
        key: string;
        pluginId: string;
        revision: string;
    }>[];
    subscribe: (listener: () => void) => () => void;
    restrict(restriction: SidebarRestriction): () => void;
}
