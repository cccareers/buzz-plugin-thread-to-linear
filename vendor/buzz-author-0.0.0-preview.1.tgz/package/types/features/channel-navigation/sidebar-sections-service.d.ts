import { Service, type Context } from "@deepseek-ai/cordis";
import type { ReactElement, ReactNode } from "react";
import type { OpenTarget } from "../navigation/targets";
import { type Contribution } from "../../plugins/contributions.ts";
export type SidebarSectionRow = Readonly<{
    id: string;
    label: string;
    icon?: ReactNode;
    badge?: string;
    count?: number;
    status?: string;
}>;
export type SidebarSectionAction = Readonly<{
    id: string;
    label: string;
    icon: ReactElement;
    onSelect: () => void | Promise<void>;
}>;
export type SidebarSectionContribution = Readonly<{
    version: 1;
    id: string;
    title: string;
    icon: ReactNode;
    rows: Readonly<{
        snapshot: () => readonly SidebarSectionRow[];
        subscribe: (listener: () => void) => () => void;
    }>;
    select: (row: SidebarSectionRow) => OpenTarget;
    actions?: readonly SidebarSectionAction[];
}>;
export type RegisteredSidebarSection = Contribution<SidebarSectionContribution>;
export type SidebarSections = Readonly<{
    version: 1;
    snapshot: () => readonly RegisteredSidebarSection[];
    subscribe: (listener: () => void) => () => void;
    register: (section: SidebarSectionContribution) => void;
}>;
declare module "@deepseek-ai/cordis" {
    interface Context {
        /** Read with `ctx.reflect.get("sidebarSections")` for old-host compatibility. */
        sidebarSections?: SidebarSections;
    }
}
export declare class SidebarSectionsService extends Service implements SidebarSections {
    private readonly contributions;
    readonly version: 1;
    constructor(ctx: Context);
    snapshot: () => readonly Readonly<Readonly<{
        version: 1;
        id: string;
        title: string;
        icon: ReactNode;
        rows: Readonly<{
            snapshot: () => readonly SidebarSectionRow[];
            subscribe: (listener: () => void) => () => void;
        }>;
        select: (row: SidebarSectionRow) => OpenTarget;
        actions?: readonly SidebarSectionAction[];
    }> & {
        key: string;
        pluginId: string;
        revision: string;
    }>[];
    subscribe: (listener: () => void) => () => void;
    register(section: SidebarSectionContribution): void;
}
