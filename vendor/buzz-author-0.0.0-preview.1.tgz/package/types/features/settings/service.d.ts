import { Service, type Context } from "@deepseek-ai/cordis";
import type { ComponentType } from "react";
import type { PageNavigation } from "../navigation/service";
import type { ChatCircleIcon } from "../../shared/design-system/icons";
import { type Contribution } from "../../plugins/contributions";
export type SettingsCard = {
    id: string;
    title: string;
    /** Optional design-system icon for this card's Settings destination. */
    icon?: typeof ChatCircleIcon;
    component: ComponentType<{
        active(): boolean;
        /** The current Settings visit; route data is presentation only. */
        navigation?: PageNavigation | undefined;
        community?: {
            id: string;
            name: string;
        };
    }>;
    /** Account status/link inside Identity; the plugin retains its session owner. */
    identityRow?: ComponentType<{
        active(): boolean;
    }>;
    /** Show this card under a labelled account-level group instead of the selected community. */
    group?: string;
    /** Separate permission-gated controls from ordinary settings for the selected community. */
    section?: "administration";
    /** Also offer this community card in Personal space, where no community is selected. */
    personal?: boolean;
    /** Reactive verified authorization for permission-gated navigation. */
    visibility?: {
        snapshot(): boolean | "pending" | "error";
        subscribe(listener: () => void): () => void;
        ensure(): () => void;
    };
};
export type SettingsCards = {
    snapshot(): readonly Contribution<SettingsCard>[];
    subscribe(listener: () => void): () => void;
    register(card: SettingsCard): void;
    retainVisibility(): () => void;
    visibility(key: string): boolean | "pending" | "error";
    /** Active registration, independent of cached authorization visibility. */
    has(key: string): boolean;
};
declare module "@deepseek-ai/cordis" {
    interface Context {
        settingsCards: SettingsCards;
    }
}
export declare class SettingsCardsService extends Service implements SettingsCards {
    private readonly entries;
    private readonly listeners;
    private visible;
    constructor(ctx: Context);
    private publish;
    snapshot: () => readonly Readonly<SettingsCard & {
        key: string;
        pluginId: string;
        revision: string;
    }>[];
    has: (key: string) => boolean;
    visibility: (key: string) => "error" | "pending" | boolean;
    subscribe: (listener: () => void) => () => boolean;
    retainVisibility(): () => void;
    register(card: SettingsCard): void;
}
