/** A community is a secure origin, never a credential-bearing URL or an API path. */
export declare function relayOrigin(input: string): string;
/**
 * A community address as a person types it: a bare host is assumed to be a
 * secure relay. Saved IDs never take this path, so an alias stays a non-URL.
 */
export declare function enteredRelayOrigin(input: string): string;
/** A short deployment ID is not a URL and must never acquire a session by itself. */
export declare function isCommunityAlias(value: string): boolean;
/** Optional deployment aliases preserve existing saved IDs without shipping a community list. */
export declare function parseCommunityAliases(raw?: string): Readonly<Record<string, string>>;
export declare function communityDestination(value: string, aliases?: Readonly<Record<string, string>>): {
    id: string;
    url: string;
    name: string;
};
/** The account service's spelling of a destination: `wss://host[:port]` with a
 * lowercase host, no default port and no trailing slash. Aliases resolve to
 * their origin first, so a device-local ID never leaves the device. */
export declare function relayAddress(value: string): string;
