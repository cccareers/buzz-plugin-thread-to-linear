/** One piece of a left community's device state that could not be cleared. */
export type PurgeFailure = {
    store: string;
    error: unknown;
};
/** Forgets what this device keeps for one community and viewer: view intent
 * (selected channel, drafts, scroll and sidebar state), channel heads, the
 * read-state journal, the outbox and smaller preference stores. Every store is
 * partitioned by `origin:viewer`, so nothing here can touch another community.
 * Each store is cleared independently: an unavailable one does not keep the
 * others, and the caller has already dropped the membership. Every failure is
 * logged and returned, named by store, so the caller can say some saved data
 * remains. */
export declare function purgeCommunityDeviceState(origin: string, viewer: string): Promise<PurgeFailure[]>;
