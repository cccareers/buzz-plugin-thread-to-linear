import type { Membership } from "./service";
export declare const COMMUNITY_NAME_MAX_LENGTH = 100;
/** NIP-11 names are presentation, never a relay identity or permission. */
export declare function publishedCommunityName(value: unknown): string | undefined;
export declare const communityDefaultName: (community: Pick<Membership, "name" | "publishedName">) => string;
export declare const communityName: (community: Pick<Membership, "name" | "publishedName" | "localName">) => string;
/** Consequential notices retain the captured name and exact destination. */
export declare function communityActionLabel(community: Membership): string;
export declare function localCommunityNameKey(id: string, viewer: string): string;
export declare function readLocalCommunityName(id: string, viewer: string, fallback?: string): string | undefined;
/** Required persistence: a rejected write leaves the current projection untouched. */
export declare function saveLocalCommunityName(id: string, viewer: string, value: string): string | undefined;
