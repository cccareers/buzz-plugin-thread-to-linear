export type KeyBinding = Readonly<{
    key: string;
    /** Command on Apple platforms, Control elsewhere. Other modifiers match exactly. */
    mod?: boolean;
    /** Control beside Command on Apple platforms. Elsewhere Control is `mod`, so this never matches. */
    ctrl?: boolean;
    shift?: boolean;
    alt?: boolean;
}>;
export type Shortcut = Readonly<{
    id: string;
    title: string;
    binding: KeyBinding | readonly KeyBinding[];
    run: () => void | Promise<void>;
    /** Read current state; false makes this registration ineligible. */
    when?: () => boolean;
    allowInEditable?: boolean;
    allowInModal?: boolean;
    /** Also run when the topmost modal is its own navigation visit (Settings, Members). */
    allowInVisit?: boolean;
    /** Held keys are consumed but run only once unless opted in. */
    repeat?: boolean;
    /** Lower values appear first within this owner's Settings category; defaults to zero. */
    order?: number;
}>;
/** What the registries hold: aliases are always a frozen array, never a bare binding. */
export type NormalizedShortcut = Shortcut & Readonly<{
    binding: readonly KeyBinding[];
    order: number;
}>;
export declare function normalizeShortcut(shortcut: Shortcut): NormalizedShortcut;
/** Shape check shared by registration and stored user overrides. */
export declare function isKeyBinding(value: unknown): value is KeyBinding;
/** Same chord under the dispatcher's rules: case-insensitive key, exact modifiers. */
export declare function sameBinding(a: KeyBinding, b: KeyBinding): boolean;
/** Nonempty list of well-formed bindings: the shape stored overrides must take. */
export declare function isBindingList(value: unknown): value is readonly KeyBinding[];
/** Callers pass the registered alias array or a stored override; nothing is wrapped here. */
export declare function matches(bindings: readonly KeyBinding[], event: KeyboardEvent, apple: boolean): boolean;
export declare function inEditable(event: KeyboardEvent): boolean;
