import type { EventData } from "../relay/events";
export declare const huddleDescription: (parent: string) => string;
export declare function huddleParent(description: string | undefined): string | undefined;
export declare const isHuddleRoom: (description: string | undefined) => boolean;
export declare function huddleRoom(event: Pick<EventData, "content">): string | undefined;
/** Relay-signed participation is display evidence, never permission to join. */
export declare function huddleLifecycle(events: readonly EventData[], room: string, parent: string, authority?: string): {
    startedAt: number | undefined;
    endedAt: number | undefined;
    participants: string[];
};
