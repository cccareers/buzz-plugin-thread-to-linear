import type { Contribution } from "../../plugins/contributions";
import type { ContributionReader, InlineContent, InlineRange, InlineRenderer } from "./contracts";
type Match = InlineRange & {
    renderer: Contribution<InlineRenderer>;
};
/** First registered renderer wins overlapping ranges; malformed/throwing matchers are skipped. */
export declare function inlineMatches(content: InlineContent, renderers: readonly Contribution<InlineRenderer>[]): Match[];
export declare function InlineText({ registry, content, media, }: {
    registry: ContributionReader<InlineRenderer>;
    content: InlineContent;
    media(url: string): string | undefined;
}): import("react").JSX.Element;
export {};
