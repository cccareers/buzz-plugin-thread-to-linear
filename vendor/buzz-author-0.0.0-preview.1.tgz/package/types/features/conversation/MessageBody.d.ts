import { type ReactNode } from "react";
import type { ChannelMessage } from "../relay/contracts";
import type { ContributionReader, MessageRenderer } from "./contracts";
/** The renderer for `message`: the first active match. Throwing matchers are skipped. */
export declare function useMessageRenderer(registry: ContributionReader<MessageRenderer> | undefined, message: ChannelMessage): Readonly<Readonly<{
    id: string;
    title: string;
    matches(message: ChannelMessage): boolean;
    ownsAttachment?(message: ChannelMessage, attachment: ChannelMessage["attachments"][number]): boolean;
    component: import("react").ComponentType<import("./contracts").TargetOpener & {
        message: ChannelMessage;
    }>;
}> & {
    key: string;
    pluginId: string;
    revision: string;
}> | undefined;
/** First active match wins; a broken optional renderer leaves the host fallback. */
export declare function MessageBody({ registry, message, children, onFailedChange, }: {
    registry: ContributionReader<MessageRenderer>;
    message: ChannelMessage;
    children: ReactNode;
    /** Reports a renderer's failure while its fallback is mounted. */
    onFailedChange?: (renderer: MessageRenderer, failed: boolean) => void;
}): import("react").JSX.Element;
/** Draws an already selected renderer, so its caller can rely on the same choice. */
export declare function MessageCard({ registry, renderer, message, children, onFailedChange, }: {
    registry: ContributionReader<MessageRenderer>;
    renderer: ReturnType<typeof useMessageRenderer>;
    message: ChannelMessage;
    children: ReactNode;
    /**
     * Called with true when the fallback replaces `renderer`, and with false when
     * that failed card unmounts: its next mount starts healthy.
     */
    onFailedChange?: ((renderer: MessageRenderer, failed: boolean) => void) | undefined;
}): string | number | bigint | boolean | import("react").JSX.Element | Iterable<ReactNode> | Promise<string | number | bigint | boolean | Iterable<ReactNode> | import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>> | import("react").ReactPortal | null | undefined> | null | undefined;
