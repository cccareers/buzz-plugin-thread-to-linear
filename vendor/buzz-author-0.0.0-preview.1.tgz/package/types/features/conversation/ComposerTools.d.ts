import { type ReactNode } from "react";
import type { ComposerTool, ComposerToolProps, ContributionReader, TargetOpener } from "./contracts";
type HostToolProps = Omit<ComposerToolProps, keyof TargetOpener>;
export declare function ComposerTools({ registry, renderLeading, ...props }: HostToolProps & {
    registry: ContributionReader<ComposerTool>;
    /** Host layout for tools ordered before the default group; preserves DOM order. */
    renderLeading?: (tools: ReactNode) => ReactNode;
}): import("react").JSX.Element[] | import("react").JSX.Element;
export {};
