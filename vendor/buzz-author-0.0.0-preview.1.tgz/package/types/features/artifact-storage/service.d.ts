import { Service, type Context } from "@deepseek-ai/cordis";
import type { ArtifactCollection, ArtifactCollectionDefinition, HostArtifactCollection } from "./types";
export type ArtifactStorage = {
    /** Captures the current identity and relay. Close the handle on scope changes. */
    open(definition: ArtifactCollectionDefinition): ArtifactCollection;
};
export type OpenArtifactCollection = Readonly<{
    viewer: string;
    relay: string;
    owner: string;
    definition: ArtifactCollectionDefinition;
    collection: HostArtifactCollection;
    signal: AbortSignal;
}>;
declare module "@deepseek-ai/cordis" {
    interface Context {
        artifactStorage: ArtifactStorage;
    }
}
export declare class ArtifactStorageService extends Service implements ArtifactStorage {
    private stores;
    private opened;
    constructor(ctx: Context);
    /** Host-only attachment point for the shared sync service. */
    onOpen(listener: (entry: OpenArtifactCollection) => void): () => void;
    open(definition: ArtifactCollectionDefinition): ArtifactCollection;
}
