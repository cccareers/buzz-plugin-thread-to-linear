import type { EventTemplate } from "nostr-tools";
import type { RelayEvent } from "../relay/events.ts";
export declare const editableMemberRoles: readonly ["admin", "member", "guest"];
export type EditableMemberRole = (typeof editableMemberRoles)[number];
export type MemberRole = EditableMemberRole | "owner" | "bot" | "unknown";
export type MemberChange = Readonly<{
    pubkey: string;
    /** `none` is reserved for system setup; `absent` is an explicit role addition. */
    expectedRole: MemberRole | "none" | "absent";
    role: EditableMemberRole | "remove";
}>;
export type MemberAuthority = Readonly<{
    roles: Readonly<Record<string, MemberRole>>;
    canManage: boolean;
    canRemove: boolean;
    canRemoveOwnedAgent: boolean;
    /** A NIP-CL system channel, where administration may also add members. */
    system: boolean;
}>;
/** Inputs have already passed the session reader's signature verification. */
export declare function memberAuthority(events: readonly RelayEvent[], channelId: string, viewer: string, relayAuthor: string): MemberAuthority;
export declare function canManageMember(state: MemberAuthority, viewer: string, key: string): boolean;
/** Ownership permits removal only; it never grants role-edit authority. */
export declare function canRemoveMember(state: MemberAuthority, viewer: string, key: string, owner?: string): boolean;
export declare function authorizeMemberChange(state: MemberAuthority, viewer: string, change: MemberChange, owner?: string): void;
/**
 * The relay stores an ordinary role as `bot` for a key with a recorded agent
 * owner, even when the request says `member`. Both are the same ordinary
 * permission level, so either one confirms a requested `member`. Other roles
 * must match exactly.
 */
export declare function memberChangeConfirmed(state: MemberAuthority, change: MemberChange): boolean;
export declare function memberAdministrationTemplate(channelId: string, change: MemberChange): EventTemplate;
/** Purpose-bound broker admission; relay remains the authoritative ACL boundary. */
export declare function validateMemberAdministrationTemplate(event: EventTemplate, viewer: string): void;
