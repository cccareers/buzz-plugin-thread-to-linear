import type { RelayReader } from "../relay/reader";
import type { RelayWriter } from "../relay/transport";
import { type RelayEvent } from "../relay/events";
import { type MemberAuthority, type MemberChange, type MemberRole } from "./administration-protocol";
export type MemberAdministrationState = Readonly<{
    status: "idle" | "loading" | "ready" | "error";
    authority: MemberAuthority;
    operation?: Readonly<{
        change: MemberChange;
        status: "pending" | "uncertain" | "confirmed" | "failed";
    }>;
    error?: string | undefined;
}>;
/** Session-owned intent survives dialog closure, never replays privileged writes. */
export declare function createMemberAdministration({ reader, writer, viewer, relayAuthor, canAccess, acceptDiscovery, }: {
    reader?: RelayReader | undefined;
    writer?: RelayWriter | undefined;
    viewer: string;
    relayAuthor: string;
    canAccess(id: string): boolean;
    acceptDiscovery(events: readonly RelayEvent[]): void;
}): {
    capability: Readonly<{
        available: boolean;
        snapshot: (id: string) => Readonly<{
            status: "idle" | "loading" | "ready" | "error";
            authority: MemberAuthority;
            operation?: Readonly<{
                change: MemberChange;
                status: "pending" | "uncertain" | "confirmed" | "failed";
            }>;
            error?: string | undefined;
        }>;
        subscribe(listener: () => void): () => void;
        refresh(id: string): Promise<void>;
        /** `active` is checked synchronously right before publishing; false publishes nothing. */
        run(id: string, intent: MemberChange, caller?: AbortSignal, active?: () => boolean): Promise<void>;
    }>;
    clear: () => void;
    dispose(): void;
};
type MemberAdministration = ReturnType<typeof createMemberAdministration>["capability"];
/** A member change's outcome. `uncertain`: published, but readback could not
 * confirm it; it is not sent again. */
export type MemberResult = Readonly<{
    status: "confirmed" | "failed" | "uncertain";
    error?: string;
}>;
/** One member change through `admin`, decided from a fresh roster read:
 * `decide` gets the key's verified role and returns the change, or nothing
 * when the roster already shows the result. `unavailable` is the error when
 * the roster can't be read and says no more. */
export declare function administerMember(admin: Pick<MemberAdministration, "refresh" | "snapshot" | "run">, channel: string, pubkey: string, decide: (role: MemberRole | undefined) => Omit<MemberChange, "pubkey"> | undefined, unavailable?: string): Promise<MemberResult>;
export {};
