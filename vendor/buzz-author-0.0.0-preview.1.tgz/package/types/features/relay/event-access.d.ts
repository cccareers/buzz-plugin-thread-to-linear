import type { EventData } from "./events";
/** Visibility, not a second membership model. Reference-only auxiliaries need
 * retained target evidence; never guess that an orphan belongs to a public entity.
 * Resolve the whole batch before filtering, independently of arrival order. */
export declare function eventVisibility(canAccess: (channelId: string) => boolean, find: (id: string) => EventData | undefined): (event: EventData) => boolean;
/** Reads each channel's access once: for a visibility used in one synchronous
 * pass, where access cannot change. */
export declare function accessOnce(canAccess: (channelId: string) => boolean): (channelId: string) => boolean;
