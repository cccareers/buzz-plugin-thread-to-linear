import { type LiveCallbacks, type LiveSubscription } from "./live";
/** A generation owns its stream, parser, retry and heartbeat. Interest changes
 * use the same host owner so they cannot interrupt pending publications. */
export declare function subscribeBrokerTraffic(endpoint: string, callbacks: LiveCallbacks): LiveSubscription;
