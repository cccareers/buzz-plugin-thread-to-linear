import { type RelayEvent } from "./events";
import { type SidebarAssignmentIntent, type SidebarGroups, type SidebarSortMode, type SidebarFilterMode } from "./sidebar-preferences";
import type { ReadTransport } from "./transport";
export declare function nativeSidebar(transport: ReadTransport): {
    decodeSidebarPreferences: (events: readonly RelayEvent[], signal: AbortSignal) => Promise<import("./sidebar-preferences").SidebarPreferences>;
    readMainAgent(signal: AbortSignal): Promise<string | null | undefined>;
    writeMainAgent(agent: string | null, signal: AbortSignal): Promise<void>;
    clearMainAgent(expected: string, signal: AbortSignal): Promise<string | undefined>;
    removeSidebarSection(sectionId: string, signal: AbortSignal): Promise<SidebarGroups>;
    renameSidebarSection(intent: {
        sectionId: string;
        name: string;
    }, signal: AbortSignal): Promise<SidebarGroups>;
    writeSidebarSectionOrder(sectionIds: readonly string[], signal: AbortSignal): Promise<SidebarGroups>;
    writeSidebarAssignment(intent: SidebarAssignmentIntent, signal: AbortSignal): Promise<SidebarGroups>;
    writeSidebarStar(intent: {
        channelId: string;
        starred: boolean;
    }, signal: AbortSignal): Promise<readonly string[]>;
    writeSidebarMute(intent: {
        channelId: string;
        muted: boolean;
    }, signal: AbortSignal): Promise<readonly string[]>;
    writeSidebarSort(group: string, mode: SidebarSortMode, sectionIds: readonly string[], signal: AbortSignal): Promise<Readonly<Record<string, SidebarSortMode>>>;
    writeSidebarFilter(group: string, mode: SidebarFilterMode, sectionIds: readonly string[], signal: AbortSignal, activeWindowSeconds?: number | null): Promise<{
        filters: Readonly<Record<string, SidebarFilterMode>>;
        activeWindowSeconds: Readonly<Record<string, number>>;
    }>;
};
