export type CustomEmoji = Readonly<{
    shortcode: string;
    url: string;
}>;
export declare const EMOJI_SET = "buzz:custom-emoji";
export declare const EMOJI_SET_KIND = 30030;
/** Reaction text stays small, while a valid custom token gets its two delimiters. */
export declare function validReactionContent(value: string): boolean;
export declare function normalizeShortcode(value: string): string | undefined;
/** Desktop's file-first naming: drop the extension and collapse invalid runs to `_`. */
export declare function suggestShortcode(filename: string): string | undefined;
/** Broker admission for a member's own set: one coordinate, canonical unique entries. */
export declare function validEmojiSetTemplate(event: unknown, now?: number): boolean;
/** Original URLs belong in events; display URLs are resolved by session.media. */
export declare function emojiTags(event: {
    readonly tags: readonly (readonly string[])[];
}): readonly CustomEmoji[];
/** Share token boundaries with the renderer: never substitute inside HTTP(S) links. */
export declare const messageParts: (content: string) => string[];
export declare const linkPart: (part: string) => boolean;
export declare function emojiMatches(content: string, entries: readonly CustomEmoji[]): Generator<{
    emoji: Readonly<{
        shortcode: string;
        url: string;
    }>;
    start: number;
    end: number;
}, void, unknown>;
/** The community palette from each member's latest set: the newest entry per
 * shortcode, with the lower URL breaking a tie. */
export declare function communityEmoji(sets: Iterable<{
    readonly tags: readonly (readonly string[])[];
    readonly created_at: number;
}>): CustomEmoji[];
/** NIP-30 tags for the palette shortcodes `content` uses outside links. */
export declare function contentEmojiTags(content: string, entries: readonly CustomEmoji[]): string[][];
export declare function referencedEmoji(content: string): string[];
