import { type VerifiedProfileFilter, type VerifiedProfileSink } from "./verified-profile.ts";
import { type ObserverFrame } from "../agents/observer.ts";
import type { EventTemplate, VerifiedEvent } from "nostr-tools";
import { type SignatureVerifier } from "./events.ts";
import { type ArtifactSyncFilter, type ArtifactSyncSink } from "./artifact-sync-filter.ts";
export declare const LIVE_CHANNEL_CAPACITY = 1022;
export declare const LIVE_BATCH_SIZE = 2048;
export declare const LIVE_REPLAY_LIMIT = 500;
export declare const LIVE_RECOVERY_INTERVAL = 60000;
/** How long a socket asked to prove itself (`check`) has to answer. */
export declare const LIVE_CHECK_TIMEOUT_MS = 5000;
/** A live batch is re-sent after this long even with no grant, in case a
 * grant notice never arrived (a dropped frame, or a duplicate notice the
 * relay stored once and did not fan out again). */
export declare const LIVE_BATCH_REFRESH_INTERVAL: number;
/** Channel REQs awaiting EOSE at once. `scripts/live-setup-probe.mjs` compares others. */
export declare const SETUP_CONCURRENCY = 4;
/** How long one channel REQ may wait for EOSE before its route fails. */
export declare const SETUP_TIMEOUT_MS = 10000;
/** The relay rejects an event whose created_at is further than this from its own
 * clock (block/buzz `crates/buzz-relay/src/handlers/ingest.rs`,
 * `MAX_TIMESTAMP_DRIFT_SECS`), so an event stored at time T can carry any
 * created_at in [T - 900, T + 900]. */
export declare const RELAY_TIMESTAMP_DRIFT_SECS = 900;
/** A route that reached EOSE was delivered live until its connection last heard
 * the relay. An event stored just after that can be backdated by the full drift,
 * so resume this far before it, plus one minute shared by everything else the
 * clocks disagree on: fan-out still in flight when the relay closed (a draining
 * pod can trail its peers), the client clock's skew from the relay's, and the
 * relay's replica read budget for the unread repair, which uses the same margin. */
export declare const LIVE_RESUME_LAG: number;
/** A continuous replay starts `LIVE_RESUME_LAG` before the drop, so it closes
 * the gap only back to then. A live frame the relay dropped earlier (a full
 * send buffer drops it without a notice) is not in it; only a read after that
 * frame brings it back. So a view resumes with no read only when the read its
 * rows came from started at most this long (milliseconds) before the drop; any
 * other view reads again. The batch refresh reads each open window's head and
 * open thread about this often. The minute under the lag absorbs read latency
 * and clock skew. */
export declare const RESUME_READ_AGE: number;
/** Signature proofs a live subscription keeps across its reconnects. Each resume
 * replays `LIVE_RESUME_LAG` of events the subscription already verified; a
 * fresh signature check costs about 1 ms of main thread per event, a proof hit
 * only the hash. A resume whose window holds more distinct events than this
 * (about 17 a second for 16 minutes, or 33 channels at `LIVE_REPLAY_LIMIT`)
 * evicts each proof before its replay reaches it and gains nothing. Artifact
 * sync events share the memo, so that rate is an upper bound, not a proven fit
 * for a typical community. About 3 MiB of IDs and signatures, about 5 MiB of
 * heap. */
export declare const LIVE_PROOF_ENTRIES = 16384;
/** The first reconnect after such a close waits a uniform random time up to
 * this, so a fleet the relay closed at once does not return at once. */
export declare const LIVE_RESTART_SPREAD_MS = 10000;
/** What a route knew when its authenticated connection ended (unix seconds). */
export type LiveCursor = Readonly<{
    liveUntil: number;
}>;
/** Where a route with a cursor resumes: `LIVE_RESUME_LAG` before its connection
 * last heard the relay, never before `original`, the first window of the session.
 * The cursor exists only for a route that reached EOSE, so everything after the
 * EOSE was delivered live until `liveUntil`; the lag keeps the overlap. */
export declare function liveResumeSince(original: number, cursor: LiveCursor): number;
/** Delay before the next connection attempt. A restarting relay (1001/1012)
 * gets full jitter over the spread window, widening once repeated bounces have
 * grown the backoff past it. Anything else waits half to all of the backoff.
 * `random` is in [0, 1). */
export declare function liveReconnectDelay(closeCode: number | undefined, backoff: number, random: () => number): number;
export declare const liveSlowRetryDelay: (failures: number) => number;
/** Host-owned server cooldown survives socket/POST replacement.
 * Healthy traffic has no inter-request delay; outstanding work is bounded below. */
export declare function createLiveAdmission(): {
    delay: () => number;
    setup(owner: object, busy: boolean): void;
    presenceReady: () => boolean;
    presenceDelay: () => number;
    tryPresence(): (() => void) | undefined;
    presenceSent(): void;
    presenceIdle: () => boolean;
    pause(seconds: number): void;
};
export type LiveAdmission = ReturnType<typeof createLiveAdmission>;
export type LiveRoute = Readonly<{
    id: string;
    channelId?: string;
    status: "pending" | "live" | "error" | "limited";
    /** EOSE establishes a stream, never proves historical completeness. */
    replay: "unknown" | "limited";
    error?: string;
}>;
export type LiveSnapshot = Readonly<{
    status: "unavailable" | "connecting" | "connected" | "retrying" | "error";
    routes: readonly LiveRoute[];
    error?: string;
}>;
/** Transport provenance, not a history-completeness claim or permission to alert. */
export type LiveProvenance = Readonly<{
    phase: "replay" | "live";
    channelId?: string;
    /** Original wire scope for ambiguous channel traffic; never alert attribution. */
    sourceChannels?: readonly string[];
}>;
export declare function liveProvenance(value: unknown): LiveProvenance;
/** A global route's establishment. `continuous`: the route resumed from the
 * cursor an earlier connection left, and its replay ended below the limit, so
 * it replayed every stored change since that connection last heard the relay.
 * A frame the relay dropped silently before then is not replayed. */
export type LiveGlobal = Readonly<{
    route: "profiles" | "membership";
    continuous: boolean;
}>;
/** Host-relayed global establishment; anything else reports nothing, so the
 * session reads again as if the replay was cut. */
export declare function liveGlobal(value: unknown): LiveGlobal | undefined;
/** Host-relayed continuous channels: only well-formed IDs of the channels
 * established with them. Anything else reports none, so each channel catches
 * up as if its replay was cut. */
export declare function liveContinuous(value: unknown, channels: readonly string[]): string[];
export type LiveCallbacks = {
    /** Legacy/missing provenance reconciles quietly; it is never implicitly fresh. */
    receive(events: readonly VerifiedEvent[], provenance?: LiveProvenance): void;
    /** Host-only encrypted telemetry route; never ordinary history reconciliation. */
    telemetry?(event: VerifiedEvent, generation: number): void;
    /** Decoded host DTO on the browser transport. */
    observer?(frame: ObserverFrame, generation: number): void;
    presence?(event: VerifiedEvent): void;
    state(snapshot: LiveSnapshot): void;
    /** A global route (no channels) also reports whether it stayed continuous.
     * A channel route reports in `continuous` the channels whose replay resumed
     * from an earlier connection's cursor and ended below the limit: it
     * delivered every event in them since that connection last heard the relay. */
    established(channels?: string | readonly string[], global?: LiveGlobal, continuous?: readonly string[]): void;
    /** Periodic repair hint, not membership or historical-completeness evidence. */
    recover?(): void;
    denied(channelId: string, reason: string): void;
};
export type LiveSubscription = {
    /** Local broker handle; not a relay subscription ID. */
    identity?(): string | undefined;
    publish?(event: VerifiedEvent, signal: AbortSignal): Promise<string>;
    /** Purpose-bound host path when generic socket publication is unavailable. */
    publishTyping?(event: VerifiedEvent, signal: AbortSignal): Promise<string>;
    update(channels: readonly string[], joined?: readonly string[]): void;
    /** Host demand only: reorder existing pending routes, never grant new interests. */
    prioritize?(channels: readonly string[]): void;
    observe?(generation: number | null): void;
    /** Ephemeral status: true = accepted, false = unconfirmed/refused, null = unsent.
     * Admission skips report their remaining delay; no durable queue is created. */
    publishPresence?(status: "online" | "away" | "offline", signal: AbortSignal): Promise<boolean | null | {
        retryAfterMs: number;
    }>;
    watchPresence?(authors: readonly string[]): void;
    /** One NIP-AR sync REQ on this socket. Sent once authenticated; a lost
     * socket ends it with `disconnected:`. The caller owns restart. */
    syncArtifacts?(filter: ArtifactSyncFilter, sink: ArtifactSyncSink): () => void;
    /** Bounded NIP-FI projection REQ on this community socket. */
    syncVerifiedProfiles?(filter: VerifiedProfileFilter, sink: VerifiedProfileSink): () => void;
    retry(): void;
    /** A hint (wake, network, focus) that an open socket may have died unseen:
     * probe it now and replace it if it does not answer in time. `network`: the
     * network changed, so an earlier answer no longer proves this socket. */
    check?(network?: boolean): void;
    dispose(): void;
};
/** Demand-scoped ephemeral authors, never a channel/history interest. */
export declare function livePresenceAuthors(input: unknown): string[];
/** IDs, not names/previews, define interest identity. Never silently truncate. */
export declare function liveChannels(input: unknown): string[];
/** Batchability is part of the same interest snapshot, not a priority hint. */
export declare function liveJoined(channels: readonly string[], input: unknown): string[];
export { CHANNEL_KINDS } from "./channel-kinds.ts";
/** The browser socket and native header-capable facade share only frame transport. */
export interface LiveSocket {
    readonly readyState: number;
    readonly connectionTimeoutMs?: number;
    onopen: ((event: Event) => unknown) | null;
    onmessage: ((event: MessageEvent) => unknown) | null;
    onerror: ((event: Event) => unknown) | null;
    onclose: ((event: CloseEvent) => unknown) | null;
    send(data: string): void;
    close(): void;
}
/** One authenticated socket, bounded joined-channel batches, singleton previews and two globals.
 * Recent replay is opportunistic: finite reads own catch-up and history bounds. */
export declare function subscribeRelayTraffic(url: string, sign: (event: EventTemplate) => Promise<VerifiedEvent>, viewer: string, callbacks: LiveCallbacks, socketFactory?: (url: string) => LiveSocket, admission?: LiveAdmission, setupConcurrency?: number, setupTimeoutMs?: number, channelBatchSize?: number, random?: () => number, signatures?: SignatureVerifier): LiveSubscription;
