import type { EventData } from "./events";
import type { OutgoingEvent } from "./outbox";
import type { RelayProfiler } from "./profiling";
import { MessageClock } from "./message-order";
/** Per-window indexes. New evidence folds only affected messages; status updates never fold. */
export declare class MessageProjection {
    private channelId;
    private relayAuthor;
    private profiling;
    private clock;
    private signingAuthority?;
    private agentOwner?;
    private inputs;
    private overlays;
    private messages;
    private deliveries;
    private owners;
    /** This client's reply sends that no relay summary has counted yet. A send
     * `sending` or `failed` when first retained is known to be uncounted: the
     * relay never committed a rejected send, which its row keeps visible for
     * retry across a restart, whereas a confirmed or unknown journal-restored
     * reply is already in its root's retained summary, and another user's live
     * reply is counted by the relay's follow-up.
     * The relay emits a thread's summary after each reply commits, racing the
     * publish receipt and the echo, so a newer root summary observed since the
     * send began vouches for it and the reply leaves once its send also has no
     * attempt in flight (accepted, echoed or unanswered), whichever lands second.
     * Clocks never decide this: the reply carries the client's, the summary the
     * relay's. */
    private pending;
    private vouched;
    private rows;
    constructor(channelId: string, relayAuthor: string, profiling: RelayProfiler, clock?: MessageClock, signingAuthority?: string | undefined, agentOwner?: ((pubkey: string) => string | undefined) | undefined);
    snapshot(): readonly Readonly<{
        id: string;
        channelId: string;
        delivery?: import("./outbox").Delivery | undefined;
        deliveryError?: string | undefined;
        authorId: string;
        signerId?: string | undefined;
        workflowOwnerId?: string | undefined;
        createdAt: number;
        createdAtMs?: number;
        content: string;
        sourceContent?: string;
        agentEnvelope?: true;
        audience?: "agents";
        notice?: "execution-failure";
        diff?: Readonly<{
            filePath?: string | undefined;
            repoUrl?: string | undefined;
            commitSha?: string | undefined;
            description?: string | undefined;
            truncated: boolean;
        }>;
        membership?: import("./contracts").MembershipChange;
        pluginRequest?: Readonly<{
            id: string;
        }>;
        huddle?: Readonly<{
            room: string;
            state: "started" | "ended";
            endedAt?: number;
        }>;
        edited?: true;
        attachmentSeams?: readonly number[];
        mentions: readonly string[];
        mentionReferences?: readonly string[];
        attachmentSourceId?: string;
        attachments: readonly import("./contracts").Attachment[];
        emoji?: readonly import("./emoji").CustomEmoji[];
        reactions: readonly import("./contracts").MessageReaction[];
        threadRootId?: string | undefined;
        replyParentId?: string | undefined;
        mediaTargetUrl?: string | undefined;
        sentFromThread?: Readonly<{
            rootId: string;
            excerpt?: string | undefined;
        }> | undefined;
        replyCount: number;
        participants: readonly string[];
    }>[];
    reconcile(events: readonly EventData[], operations: readonly OutgoingEvent[]): readonly Readonly<{
        id: string;
        channelId: string;
        delivery?: import("./outbox").Delivery | undefined;
        deliveryError?: string | undefined;
        authorId: string;
        signerId?: string | undefined;
        workflowOwnerId?: string | undefined;
        createdAt: number;
        createdAtMs?: number;
        content: string;
        sourceContent?: string;
        agentEnvelope?: true;
        audience?: "agents";
        notice?: "execution-failure";
        diff?: Readonly<{
            filePath?: string | undefined;
            repoUrl?: string | undefined;
            commitSha?: string | undefined;
            description?: string | undefined;
            truncated: boolean;
        }>;
        membership?: import("./contracts").MembershipChange;
        pluginRequest?: Readonly<{
            id: string;
        }>;
        huddle?: Readonly<{
            room: string;
            state: "started" | "ended";
            endedAt?: number;
        }>;
        edited?: true;
        attachmentSeams?: readonly number[];
        mentions: readonly string[];
        mentionReferences?: readonly string[];
        attachmentSourceId?: string;
        attachments: readonly import("./contracts").Attachment[];
        emoji?: readonly import("./emoji").CustomEmoji[];
        reactions: readonly import("./contracts").MessageReaction[];
        threadRootId?: string | undefined;
        replyParentId?: string | undefined;
        mediaTargetUrl?: string | undefined;
        sentFromThread?: Readonly<{
            rootId: string;
            excerpt?: string | undefined;
        }> | undefined;
        replyCount: number;
        participants: readonly string[];
    }>[];
    private overlayIds;
    private withDelivery;
    private delivery;
}
