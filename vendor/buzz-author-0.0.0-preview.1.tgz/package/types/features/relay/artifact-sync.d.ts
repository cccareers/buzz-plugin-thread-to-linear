import type { VerifiedEvent } from "nostr-tools";
import { type ArtifactSyncFilter, type ArtifactSyncSink } from "./artifact-sync-filter.ts";
export { ARTIFACT_REMOVAL_KIND, ARTIFACT_REVISION_KIND, ARTIFACT_SYNC_MAX_CHANNELS, ARTIFACT_SYNC_MAX_VIEWS, type ArtifactSyncFilter, type ArtifactSyncSink, artifactSyncFilter, } from "./artifact-sync-filter.ts";
export type ArtifactSyncStatus = 
/** No complete set yet. */
"loading"
/** The last EOSE set plus every live change since. */
 | "live"
/** The last complete set; a new sync is starting. */
 | "stale"
/** The reader cannot read a channel that `#h` names. Terminal. */
 | "restricted"
/** This relay or transport has no sync. Use finite reads instead. */
 | "unsupported"
/** Refused or failed beyond retry. Terminal; events are the last set. */
 | "error";
export type ArtifactSyncSnapshot = Readonly<{
    status: ArtifactSyncStatus;
    /** Current heads only, one per `d`. Deletions and moved-away artifacts are absent. */
    events: readonly VerifiedEvent[];
    error?: string;
}>;
export type ArtifactSyncView = {
    snapshot(): ArtifactSyncSnapshot;
    subscribe(listener: () => void): () => void;
    dispose(): void;
};
/** Host-only: `restart` drops every held event and starts a new sync. */
export type ArtifactSyncOwner = ArtifactSyncView & {
    restart(): void;
};
/** One kept-current artifact set. Replaces its set only at EOSE (rule 7),
 * applies heads and removals after it, and restarts with jittered backoff on
 * resync, error or disconnect. */
export declare function createArtifactSyncView(input: unknown, open: ((filter: ArtifactSyncFilter, sink: ArtifactSyncSink) => () => void) | undefined, random?: () => number, notify?: (listener: () => void) => void): ArtifactSyncOwner;
