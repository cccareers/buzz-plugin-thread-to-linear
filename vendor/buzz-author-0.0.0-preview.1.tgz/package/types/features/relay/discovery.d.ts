import { type RelayEvent } from "./events";
import type { ChannelSummary } from "./contracts";
/** Display name from signed channel metadata; the content body overrides the tag. */
export declare function metadataName(event: RelayEvent): string | undefined;
/** A Solo chat: a stream carrying the Solo label. Never access. */
export declare function soloChannelMetadata(event: RelayEvent): boolean;
/** Explicit signed public metadata: readable and joinable by any viewer. */
export declare function openMetadata(event: RelayEvent): boolean;
/** NIP-29 discovery: relay-authored replaceable metadata (39000) and rosters (39002). */
export declare class DiscoveryState {
    readonly viewer: string;
    readonly relayAuthor: string;
    readonly maxBytes: number;
    private denied;
    /** Denied only because a complete read omitted them; a later one can list them again. */
    private absent;
    /** Fresh public resolution can restore reading while membership remains denied. */
    private confirmedPreviews;
    private suspended;
    private complete;
    private cached;
    accessRevision: number;
    /** A scan that drops evidence cannot certify completeness. */
    overflowRevision: number;
    private rosters;
    private metadata;
    private creations;
    /** Solo chats this device started whose signed metadata and roster have not
     * both arrived. Local display and intent only: never saved, never proof.
     * It stands in for access only until a signed roster decides it. */
    private starting;
    private retainedBytes;
    private rejectedVersions;
    constructor(viewer: string, relayAuthor: string, maxBytes?: number);
    private store;
    private olderThanRejected;
    /** Returns whether visible state changed. Events from other authors are ignored, not trusted. */
    accept(event: RelayEvent, cached?: boolean): boolean;
    /** Lists a Solo chat this device is creating until the relay confirms it. */
    start(channel: ChannelSummary): void;
    /** Returns whether a started chat was still awaiting confirmation. */
    abandon(id: string): boolean;
    isPending(id: string): boolean;
    /** A started chat no signed roster has decided yet. */
    private undecided;
    deny(id: string): void;
    /** A CLOSED preview is unreadable pending fresh evidence, not permanently denied. */
    suspend(id: string): boolean;
    suspendedChannels(): string[];
    resume(id: string, metadata?: RelayEvent): boolean;
    /** A complete viewer-scoped roster read proves absence: rosters it omitted no longer include the viewer. */
    rosterVersions(): ReadonlyMap<string, RelayEvent>;
    /** Channels whose signed metadata is retained, joined or not. */
    metadataIds(): string[];
    retain(ids: ReadonlySet<string>, started: ReadonlyMap<string, RelayEvent>): boolean;
    denyAll(): void;
    /** A restored snapshot grants local display only for known signed channels.
     * Close the unknown-access boundary before hydrating content. Fresh exact
     * resolution still grants omitted/capped channels; cache is not roster completeness. */
    restrictToKnown(): void;
    /** Unknown is not denied until a complete roster or local snapshot closes that boundary. */
    canAccess(id: string): boolean;
    /** Explicit signed public metadata grants reading, never membership. */
    private open;
    canParticipate(id: string): boolean;
    canWrite(id: string): boolean;
    private readonly parsed;
    private parse;
    private viewerRole;
    authorized(id: string): boolean;
    metadataVersion(id: string): RelayEvent | undefined;
    named(id: string): boolean;
    byteHeadroom(): number;
    name(id: string): string;
    /** NIP-29 `hidden` marks channels (DMs) that are members-only and absent from channel directories. */
    hidden(id: string): boolean;
    isPrivate(id: string): boolean;
    /** Bare `auto_join` flag: present only while the relay actually auto-adds (open, unarchived). */
    autoJoin(id: string): boolean;
    isSolo(id: string): boolean;
    get(id: string): ChannelSummary | undefined;
    clearCached(): void;
    savedEvents(): RelayEvent[];
    /** Every roster channel get() serves, system channels included. Membership,
     * not listing, decides what the device may keep. */
    readable(): ChannelSummary[];
    /** The channel list. System channels (NIP-CL) hold app data, not
     * conversation: they stay readable through get() but never list here. */
    channels(readable?: readonly ChannelSummary[]): ChannelSummary[];
}
/** A signed creation receipt must agree with the relay's immutable identity facts. */
export declare function huddleCreation(creation: RelayEvent, metadata: RelayEvent): boolean;
