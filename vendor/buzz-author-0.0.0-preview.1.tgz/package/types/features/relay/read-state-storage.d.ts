import { type RelayEvent } from "./events";
import { type ReadState } from "./read-state-model";
export type ReadJournal = Readonly<{
    version: 1;
    slot: string;
    clientId: string;
    state: ReadState;
    /** Explicitly local-only intent; the counter fences older reading handles. */
    localUnread: Readonly<Record<string, number>>;
    /** Local interaction order, bounded with retained frontier hints. */
    recent?: Readonly<Record<string, number>>;
    /** Local-only evicted receipts, deleted with this partition even by old builds. */
    reserve?: Readonly<Record<string, number>>;
    /** Local-only: every message at or before this time counts as read here.
     * Raised to the time of the newest mark that the reserve had no room for. */
    floor?: number;
    /** Local-only: the channel of each message that a kept mark names (see
     * `markMessage`), taken from a signed event. A mark does not carry its
     * channel, so this lets a channel mark cover it while the message is not
     * loaded. */
    homes?: Readonly<Record<string, string>>;
    /** The frontiers this installation advanced: all it publishes, never a
     * peer's value. Message marks stay local (frontier-only sync). */
    own?: Readonly<Record<string, number>>;
    /** Local recovery points for decoded peer generations awaiting committed ingest. */
    peerOverlaps?: readonly Readonly<{
        coordinate: string;
        key: string;
        set: number;
        baseline: number;
        version: Readonly<{
            id: string;
            created_at: number;
        }>;
    }>[];
    /** Further slots this installation owns after `slot`, in placement order. */
    spill?: readonly string[];
    revision: number;
    /** Saves among `revision` that read nothing (row `seen:` marks), from any
     * window, so unread intent is `revision - quiet`. */
    quiet?: number;
    acceptedRevision: number;
    lastCreatedAt: number;
    pending?: Readonly<{
        event: RelayEvent;
        revision: number;
    }>;
}>;
/** Mutations run against the latest record in one strict transaction (including other tabs). */
export interface ReadStateStorage {
    update(change: (current: ReadJournal | undefined) => ReadJournal): Promise<ReadJournal>;
    /** The latest saved record, read without writing; undefined before first use. */
    read?(): Promise<ReadJournal | undefined>;
    /** Reserves a journal snapshot synchronously, before later transactions, on
     * an initialized connection. Rejects rather than deferring that reservation. */
    capture(): Promise<ReadJournal | undefined>;
    close(): void;
}
export declare const newSlotId: () => string;
export declare function newReadJournal(): ReadJournal;
/** Storage is untrusted. Corrupt intent is an error, never an empty journal to overwrite. */
export declare function readJournal(raw: unknown, viewer: string): ReadJournal;
/** Forgets one partition's journal after its session is disposed, so a left
 * community's read markers do not outlive the membership on this device. */
export declare function purgeReadStateStorage(scope: string): Promise<void>;
export declare function browserReadStateStorage(scope: string, viewer: string): ReadStateStorage;
