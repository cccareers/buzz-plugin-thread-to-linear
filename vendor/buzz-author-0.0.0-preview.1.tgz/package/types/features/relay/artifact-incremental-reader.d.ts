import { type RelayEvent } from "./events";
export declare const ARTIFACT_INCREMENTAL_LIMITS: Readonly<{
    version: 1;
    overlapSeconds: 120;
    pageRows: 100;
    currentRows: 100;
    responseBytes: 8388608;
    permanentChannelsOnly: true;
    checkpointLifetimeSeconds: 2592000;
}>;
export type ArtifactIncrementalQuery = Readonly<{
    artifact: "current";
    kinds: readonly [45010];
    "#type": readonly string[];
}>;
export type ArtifactIncrementalChange = Readonly<{
    type: "upsert";
    artifactId: string;
    event: RelayEvent;
}> | Readonly<{
    type: "remove";
    artifactId: string;
}> | Readonly<{
    type: "removeChannel";
    channelId: string;
}>;
export type ArtifactIncrementalPage = Readonly<{
    startedAt: string;
    overlapSeconds: 120;
    changes: readonly ArtifactIncrementalChange[];
    nextCursor: string | null;
    checkpoint: string | null;
}>;
export type ArtifactCurrentPage = Readonly<{
    startedAt: string;
    changes: readonly Exclude<ArtifactIncrementalChange, {
        type: "removeChannel";
    }>[];
}>;
export type ArtifactIncrementalRequest = Readonly<{
    artifact: "incremental";
    query: ArtifactIncrementalQuery;
    checkpoint?: string;
    cursor?: string;
}> | Readonly<{
    artifact: "incremental";
    action: "current";
    query: ArtifactIncrementalQuery;
    artifactIds: readonly string[];
}>;
export type ArtifactIncrementalReader = {
    delta(query: ArtifactIncrementalQuery, position: {
        checkpoint?: string;
        cursor?: string;
    }, signal: AbortSignal): Promise<ArtifactIncrementalPage>;
    current(query: ArtifactIncrementalQuery, artifactIds: readonly string[], signal: AbortSignal): Promise<ArtifactCurrentPage>;
};
type ErrorCode = "incremental_invalid" | "incremental_limit" | "incremental_reset" | "incremental_unsupported_scope" | "incremental_unavailable";
type ResetReason = "policy_changed" | "checkpoint_expired";
export declare class ArtifactIncrementalError extends Error {
    readonly code: ErrorCode;
    readonly reason?: ResetReason | undefined;
    readonly status?: number | undefined;
    constructor(code: ErrorCode, message: string, reason?: ResetReason | undefined, status?: number | undefined);
}
export declare function artifactIncrementalFailure(value: unknown): {
    error: string;
    code: ErrorCode;
    reason?: ResetReason;
} | undefined;
export declare function artifactIncrementalCapability(info: unknown): boolean;
/** Sync covers permanent channels only. The authenticated transport owns POST requests. */
export declare function createArtifactIncrementalReader(request: (filter: ArtifactIncrementalRequest, signal: AbortSignal) => Promise<Response>): ArtifactIncrementalReader;
export {};
