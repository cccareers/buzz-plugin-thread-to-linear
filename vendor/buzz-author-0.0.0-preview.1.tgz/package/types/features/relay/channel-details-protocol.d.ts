import type { EventTemplate } from "nostr-tools";
import type { RelayEvent } from "./events.ts";
export type ChannelDetailsDraft = Readonly<{
    name: string;
    description: string;
    visibility: "public" | "private";
    /** Admission default only; omission preserves existing relay behavior. */
    joinRole?: "member" | "guest" | undefined;
    /** Absent means ongoing; retain existing custom temporary intervals. */
    ttlSeconds?: number | undefined;
    /** NIP-CL labels. Absent leaves the relay's set unchanged; empty clears it. */
    labels?: readonly string[] | undefined;
}>;
export type ChannelDetails = ChannelDetailsDraft & Readonly<{
    channelId: string;
    version: string;
    canEdit: boolean;
}>;
/** Missing or contradictory flags are unknown, never implicitly public. */
export declare function channelVisibility(event: RelayEvent): "public" | "private" | undefined;
/** Match buzz-core canonical_channel_name: Rust char::is_whitespace uses
 * Unicode White_Space (unlike JS trim, which omits U+0085 and includes U+FEFF). */
export declare function canonicalDetailsName(name: string): string;
/** Shared field feedback; the command validator remains the write boundary. */
export declare function detailsDraftErrors(draft: ChannelDetailsDraft): {
    name: string | undefined;
    description: string | undefined;
    lifetime: string | undefined;
    visibility: string | undefined;
    labels: string | undefined;
    joinRole: string | undefined;
};
/** Same label set, ignoring order and duplicates. */
export declare function sameLabels(a: readonly string[], b: readonly string[]): boolean;
export declare function validateDetailsDraft(draft: ChannelDetailsDraft): void;
export declare function detailsSettings(events: readonly RelayEvent[], id: string, viewer: string, relayAuthor: string): {
    details: ChannelDetails;
    metadata: import("nostr-tools").VerifiedEvent;
};
export declare function detailsTemplate(id: string, draft: ChannelDetailsDraft, base: ChannelDetailsDraft): EventTemplate;
/** Display-only TTL for summaries; malformed metadata shows no lifetime instead of failing the list. */
export declare function channelTtl(event: RelayEvent): number | undefined;
/** Legacy absence means Member; malformed explicit defaults fail closed to Guest. */
export declare function channelJoinRole(event: RelayEvent): "member" | "guest";
/** Separate from lifecycle and outbox admission. Admits only explicit open/private visibility. */
export declare function validateDetailsTemplate(event: EventTemplate): void;
