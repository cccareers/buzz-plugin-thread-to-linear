import type { ReadFilter, RelayEvent } from "./events";
export declare const REMINDER_KIND = 30300;
/** Buzz's target dialect, shared with beta desktop and mobile (not the NIP-ER spec shape). */
export type ReminderTarget = Readonly<{
    eventId: string;
    channelId: string;
    preview: string;
    authorPubkey: string;
}>;
export type ReminderStatus = "pending" | "done" | "cancelled";
export type Reminder = Readonly<{
    /** The `d` coordinate. */
    id: string;
    eventId: string;
    createdAt: number;
    /** Due time in unix seconds; absent once done or cancelled. */
    notBefore?: number;
    status: ReminderStatus;
    target?: ReminderTarget;
    note?: string;
}>;
export type RemindersState = Readonly<{
    status: "loading" | "ready" | "error";
    /** True once the first page of a history read has landed; later pages may
     * still be loading. Local saves and live arrivals don't count. */
    hydrated: boolean;
    reminders: readonly Reminder[];
    error?: string;
}>;
export type ReminderIntent = Readonly<{
    d: string;
    createdAt: number;
    notBefore?: number;
    expiration?: number;
    content: Readonly<{
        target?: ReminderTarget;
        note?: string;
        status: ReminderStatus;
    }>;
}>;
/** Purpose-bound host codec: decode only own 30300s, sign only reminder intent. */
export type ReminderHost = Readonly<{
    decode(events: readonly RelayEvent[], signal: AbortSignal): Promise<readonly {
        eventId: string;
        content: unknown;
    }[]>;
    sign(intent: ReminderIntent, signal: AbortSignal): Promise<RelayEvent>;
}>;
export type Reminders = Readonly<{
    snapshot(): RemindersState;
    subscribe(listener: () => void): () => void;
    refresh(): Promise<void>;
    create(target: ReminderTarget, notBefore: number, note?: string): Promise<void>;
    snooze(id: string, notBefore: number): Promise<void>;
    complete(id: string): Promise<void>;
    cancel(id: string): Promise<void>;
}>;
/** Mirrors the relay's validator: ASCII digits, no leading zero, safe integer. */
export declare function parseNotBefore(raw: string | undefined): number | undefined;
/** Off-shape plaintext fails closed, as NIP-ER requires. */
export declare function parseReminder(event: RelayEvent, content: unknown): Reminder | undefined;
export declare function createReminders(options: {
    viewer: string;
    host: ReminderHost;
    query(filters: ReadFilter[], signal: AbortSignal): Promise<RelayEvent[]>;
    publish(event: RelayEvent, signal: AbortSignal): Promise<unknown>;
    signal: AbortSignal;
}): {
    capability: Readonly<{
        snapshot(): RemindersState;
        subscribe(listener: () => void): () => void;
        refresh(): Promise<void>;
        create(target: ReminderTarget, notBefore: number, note?: string): Promise<void>;
        snooze(id: string, notBefore: number): Promise<void>;
        complete(id: string): Promise<void>;
        cancel(id: string): Promise<void>;
    }>;
    /** The connection dropped: the list is stale until `recover()`'s read lands. */
    stale(): void;
    /** The membership route resumed from its cursor and its replay ended
     * under the limit, so it carried every edit made since the drop. A list
     * that was complete before the drop is complete again once those edits
     * are decoded; any other list reads again as `recover()` does. */
    resume(): Promise<void>;
    /** The connection is (re-)established: start the read that ends the outage. */
    recover: () => Promise<void>;
    /** Live delivery from another device; failures leave the last good list. */
    receive(events: readonly RelayEvent[]): void;
};
