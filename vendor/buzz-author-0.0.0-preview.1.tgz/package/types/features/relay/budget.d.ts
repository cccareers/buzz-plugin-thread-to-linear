export declare const OUTBOX_INPUT_MAX_BYTES: number;
/** Profiles kept in memory when no open channel reserves more. */
export declare const PROFILE_CACHE_BASE = 1024;
/** Hard limit while an open channel reserves room for its members. */
export declare const PROFILE_CACHE_MAX = 10240;
/** The roster profiles a view may load at a cache limit: the room an open
 * channel reserved, so the base stays free for every other name on screen.
 * With no reservation a view may still use the base. */
export declare const profileRosterRoom: (limit: number) => number;
/** Byte budget per profile entry; a typical signed kind 0 is 0.5-1 KiB. */
export declare const PROFILE_ENTRY_BYTES: number;
/** Deterministic UTF-8 budget, used for both warm data and persisted records. */
export declare const byteSize: (value: unknown) => number;
/** `byteSize` of a list whose members never change, such as verified events.
 * A live window checks its budget on every message; each member is serialized
 * once instead of the whole window each time. */
export declare function listByteSize(values: readonly object[]): number;
export declare class ByteLru<T> {
    maxEntries: number;
    maxBytes: number;
    /** Entries eviction takes last; the limits still hold. */
    private keep?;
    private items;
    private bytes;
    constructor(maxEntries: number, maxBytes: number, 
    /** Entries eviction takes last; the limits still hold. */
    keep?: ((key: string) => boolean) | undefined);
    /** Change both limits; shrinking evicts least recently used entries now. */
    resize(maxEntries: number, maxBytes: number): number;
    get(key: string): T | undefined;
    peek(key: string): T | undefined;
    set(key: string, value: T, bytes?: number): boolean;
    /** Replace a present entry without making it the most recent. */
    replace(key: string, value: T, bytes?: number): boolean;
    /** Entries removed to stay within the limits, over this cache's lifetime. */
    evictions: number;
    /** Least recently used first, kept entries only once no other is left. */
    private evict;
    delete(key: string): void;
    clear(): void;
    keys(): string[];
    entries(): [string, T][];
    stats(): {
        entries: number;
        bytes: number;
    };
}
