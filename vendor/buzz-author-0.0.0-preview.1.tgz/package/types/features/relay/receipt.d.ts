/** Bound command receipt bytes before parsing or retaining secret-bearing text. */
export declare function readReceiptText(response: Response): Promise<string>;
