import { type IdentityArchiveAction } from "./identity-archive-protocol";
import type { RelayReader } from "./reader";
import type { RelayWriter } from "./transport";
export type IdentityArchiveSnapshot = Readonly<{
    status: "unavailable" | "idle" | "loading" | "ready" | "error";
    archived: readonly string[];
    eventId?: string;
    createdAt?: number;
    readAt?: number;
    error?: string;
}>;
export type IdentityArchives = ReturnType<typeof createIdentityArchives>["queries"];
/** Base Buzz discovery rule: known-archived identities leave forward-looking
 * choices, fail open while archive state is unknown, and never hide the viewer
 * from themself (NIP-IA archival stays visible to its subject). Visibility
 * uses the last known archives; `state()` answers only from a fresh read. */
export declare function archiveHides(archives: Pick<IdentityArchives, "snapshot"> | undefined, pubkey: string, viewer: string | undefined): boolean;
/** Relay-scoped NIP-IA visibility, never access, membership or liveness evidence.
 * The caller supplies only explicit NIP-11 self, never the contact-key fallback.
 * Reads are lazy finite snapshots, not a live archive subscription.
 * Requests are optional NIP-IA 9035/9036 writes; the relay re-verifies consent. */
export declare function createIdentityArchives(reader: RelayReader, authority: string | undefined, notify?: (listener: () => void) => void, write?: {
    writer: RelayWriter | undefined;
    viewer: string | undefined;
}): {
    queries: Readonly<{
        snapshot: () => Readonly<{
            status: "unavailable" | "idle" | "loading" | "ready" | "error";
            archived: readonly string[];
            eventId?: string;
            createdAt?: number;
            readAt?: number;
            error?: string;
        }>;
        subscribe(listener: () => void): () => void;
        state: (pubkey: string) => "unknown" | "archived" | "not-archived";
        ensure: () => Promise<void>;
        refresh: () => Promise<void>;
        /** Whether this community keeps archives at all; fixed per session. */
        supported: boolean;
        writable: boolean;
        consent: (target: string, signal: AbortSignal) => Promise<{
            auth?: readonly string[];
            admin?: true;
        } | null>;
        request: (action: IdentityArchiveAction, target: string, caller?: AbortSignal) => Promise<void>;
    }>;
    clear: () => void;
    stale: () => void;
    dispose(): void;
};
