/** Live Canvas size policy, shared by the app and the browser host.
 * Dependency-free so the broker and socket layer can load it natively.
 * `src-tauri/src/relay.rs` mirrors both values. */
/** Content of a live channel Canvas, in UTF-8 bytes. */
export declare const LIVE_CANVAS_BYTES: number;
export declare const LIVE_CANVAS_LIMIT = "256 KiB";
/** The relay's default WebSocket frame (`DEFAULT_MAX_FRAME_BYTES`). */
export declare const CANVAS_FRAME_BYTES: number;
/** The largest complete signed Canvas event: the frame less the
 * `["EVENT",…]` wrapper. Content within `LIVE_CANVAS_BYTES` can still escape
 * past it, so signed events are checked separately. */
export declare const CANVAS_MAX_EVENT_BYTES: number;
/** The most serialized events one read returns: the app's `RELAY_READ_BYTES`
 * and the app-hosted agent read cap in `src-tauri/src/app_agents.rs`. Both
 * bound the bare JSON event array. */
export declare const CANVAS_READ_BYTES: number;
/** Revisions per History read: a page of the largest signed Canvas events,
 * each with its separating comma inside the `[…]` array, fits one read. */
export declare const CANVAS_HISTORY_PAGE: number;
