import type { RelayReader } from "../relay/reader";
import type { RelayEvent } from "../relay/events";
import type { Outbox, LocalEvents } from "../relay/outbox";
import type { ChannelKitHost } from "./host";
import type { ChannelSummary } from "../relay/contracts";
import { type KitEntry, type KitValue } from "./model";
export type CanvasHistoryCursor = {
    until: number;
    before_id: string;
};
export type CanvasHistoryPage = {
    revisions: readonly RelayEvent[];
    next: CanvasHistoryCursor | undefined;
};
export declare const selectedHead: (events: readonly RelayEvent[]) => import("nostr-tools").VerifiedEvent | undefined;
type Snapshot = {
    status: "idle" | "loading" | "ready" | "error" | "unavailable";
    entries: readonly KitEntry[];
    error?: string | undefined;
    /** Set with an error that a later retry can fix; see isTransientFailure. */
    transient?: true | undefined;
};
/** Session-owned reads and narrow recipe operations; the existing outbox owns delivery. */
export declare function createChannelKit({ host, reader, outbox, local, ready, viewer, community, signal, canWrite, canRead, delivered, }: {
    host: ChannelKitHost | undefined;
    reader: RelayReader;
    outbox: Outbox | undefined;
    local: LocalEvents | undefined;
    ready: Promise<void> | undefined;
    viewer: string;
    community: string;
    signal: AbortSignal;
    canWrite(channel: string): boolean;
    canRead?(channel: string): boolean;
    delivered(id: string): Promise<void>;
}): {
    capability: Readonly<{
        available: boolean;
        snapshot: () => Snapshot;
        subscribe(listener: () => void): () => void;
        ensure(): void;
        refresh: ({ after }?: {
            after?: boolean | undefined;
        }) => Promise<void>;
        save(value: KitValue, expected: string | undefined, deleted?: boolean, operationSignal?: AbortSignal, resume?: Resume): Promise<string>;
    }>;
    canvas: Readonly<{
        available: boolean;
        read(channel: string, { strong }?: {
            strong?: boolean;
        }): Promise<import("nostr-tools").VerifiedEvent | undefined>;
        history(channel: string, cursor?: CanvasHistoryCursor): Promise<CanvasHistoryPage>;
        save(channel: string, content: string, expected: string | undefined, options?: {
            preserveApproval: boolean;
        }): Promise<import("nostr-tools").VerifiedEvent>;
    }>;
    confirm: (id: string) => Promise<void>;
    clear(): void;
};
/** Lets a retry confirm the exact event an earlier attempt enqueued. */
export type Resume = {
    id?: string | undefined;
    enqueued(id: string): void;
};
export type ChannelKit = ReturnType<typeof createChannelKit>["capability"];
export type ChannelCanvas = ReturnType<typeof createChannelKit>["canvas"];
/** Canvas and Todos show a channel read-only until the viewer can write it. */
export declare const canvasReadOnly: (channel: ChannelSummary | undefined) => boolean;
export {};
