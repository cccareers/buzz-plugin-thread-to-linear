import type { EventData } from "../relay/events.ts";
import type { WorkflowDefinition, WorkflowReference, WorkflowRunCursor, WorkflowRunPage } from "./types.ts";
export declare const WORKFLOW_KINDS: readonly [30620, 46020, 5];
export declare function isWorkflowOperation(event: Pick<EventData, "kind" | "tags">): boolean;
export declare const UUID: RegExp;
export declare function record(value: unknown): value is Record<string, unknown>;
export declare function validateReference(value: WorkflowReference): void;
export declare function workflowReference(event: Pick<EventData, "kind" | "tags" | "pubkey">): WorkflowReference;
export declare function definition(event: EventData): WorkflowDefinition;
/** Structural authoring checks, not a replacement for relay language/role validation. */
export declare function workflowYaml(text: string): {
    enabled: boolean;
    name: string;
};
/** Shared session/broker signing boundary. Only canonical workflow operations, never generic kind 5. */
export declare function validateWorkflowEvent(event: EventData, viewer: string): Readonly<{
    id: string;
    owner: string;
    channelId: string;
}>;
/** The relay's inbound webhook route; the secret travels in an X-Webhook-Secret header. */
export declare function hookUrl(relayHttpUrl: string, id: string): string;
export declare function runsPath(id: string, cursor?: WorkflowRunCursor): string;
export declare function parseRuns(raw: unknown, workflowId: string): WorkflowRunPage;
