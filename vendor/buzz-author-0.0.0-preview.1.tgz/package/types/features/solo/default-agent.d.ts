import type { MentionRecipient } from "../messages/mention-draft";
import type { RelaySession } from "../relay/session";
/** Makes an agent the one new Berd messages are tagged for, on this device. */
export declare function setDefaultAgent(scope: string, pubkey: string): boolean;
/** Abandon a failed account replacement without overwriting a newer device
 * choice made while its confirmation remained open. */
export declare function restoreDefaultAgent(scope: string, replacing: string, previous: string): boolean;
/** The viewer's own choice: saved here, then to their account. */
export declare function chooseDefaultAgent(session: RelaySession, scope: string, pubkey: string): Promise<void>;
/** Saves that the viewer has no main agent. A failed account write restores
 * the prior device choice unless a newer choice superseded this attempt. */
export declare function clearDefaultAgent(session: RelaySession, scope: string): Promise<void>;
/** Clears a deleted agent from the account only when it is still the saved
 * choice. Another agent chosen on the account is left alone. */
export declare function clearDeletedDefaultAgent(session: RelaySession, scope: string, pubkey: string): Promise<boolean>;
/** A deleted agent stops being the main agent everywhere it was chosen on this
 * device. Account cleanup is separate because it needs the owning session. */
export declare function forgetDefaultAgent(pubkey: string): void;
/** The account-saved choice and its read state. Without an account capability,
 * the local explicit choice is already authoritative. */
export declare function useSavedAgentState(session: RelaySession, scope: string): {
    read: boolean;
    agent: string | undefined;
    error: string | undefined;
    retry: () => void;
};
/** The agent saved as main on the viewer's account, when it has one; without
 * an account record, the agent saved on this device. */
export declare function useSavedAgent(session: RelaySession, scope: string): string | undefined;
/** `useSavedAgent` outside React. Subscribing starts the account's
 * once-per-session read, as the hook does when it mounts. */
export declare function savedAgentStore(session: RelaySession, scope: string): Readonly<{
    snapshot: () => string | undefined;
    /** Whether the account's choice is known, so an undefined snapshot means
     * none was saved rather than not read yet, or unreadable. */
    known: () => boolean;
    /** Whether the account is known to hold a record, of a choice or of none
     * saved. Known without one, nobody ever chose there, which isn't the same
     * as having removed a choice. */
    recorded: () => boolean;
    subscribe(listener: () => void): () => void;
}>;
/** The agent explicitly saved as main, whether or not it can be tagged now. */
export declare function useChosenAgent(scope: string): string | undefined;
/**
 * The agent new Berd messages are tagged for. A chosen main agent stays chosen
 * for as long as it exists, even when its runtime is signed out or broken, so
 * a failure shows on the agent the viewer expects. Without a choice, or once
 * the chosen agent is deleted (archived), and once the account's saved choice
 * has been read, the first agent the viewer runs here, else the first they
 * can tag, becomes the main agent and is saved on this device so it doesn't
 * shift between loads. A chosen agent missing for another reason
 * is stood in for without replacing the choice. Bestie may own this choice
 * later. A requested agent, as when search opens a new chat with it, replaces
 * that choice: it is tagged once it can be, and no other agent stands in for
 * it.
 */
export declare function useDefaultAgent(session: RelaySession, scope: string, requested?: string): MentionRecipient | undefined;
