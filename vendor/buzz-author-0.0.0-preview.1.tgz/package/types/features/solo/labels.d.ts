import type { ChannelSummary } from "../relay/contracts.ts";
/** Presentation provenance in the relay's existing NIP-CL labels, never access. */
export declare const SOLO_NAMED_LABEL = "buzz.session.named";
/** NIP-CL label marking a Solo chat: a channel whose owner talks with
 * their agents at top level. Every member and agent reads it from channel
 * metadata. Presentation and composition only; ordinary channel permissions
 * remain the access authority. Conversion to a channel clears it. */
export declare const SOLO_LABEL = "buzz.solo";
export declare const SOLO_ACCESS_DISCLOSURE = "Everyone in this community will be able to read this chat\u2019s full history and Canvas, including its workspace folders and agent instructions.";
export declare function soloShareDisclosure(multiple?: boolean): string;
/** Switching an open Solo chat to Private never removes its members. */
export declare function soloRetainedAccessWarning(base: Pick<ChannelSummary, "visibility" | "joinRole">, mayHaveGuestMembers?: boolean): string;
export declare function soloLabels(labels: readonly string[] | undefined): boolean;
/** The viewer's own Solo chat: one they created. Anyone else in a shared
 * Solo chat sees its flat treatment and finds it with their own chats. */
export declare function ownSolo(channel: Readonly<{
    channelType?: string | undefined;
    creator?: string | undefined;
}> | undefined, viewer: string | undefined): boolean;
export declare function soloChatLinkName(channel: {
    id: string;
    name: string;
}): string;
/** The authorized Solo inventory; unknown metadata never implies Solo. */
export declare function eligibleSolo(channel: ChannelSummary, viewer: string | undefined): boolean;
