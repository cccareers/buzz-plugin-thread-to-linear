/** Local, bounded client performance metrics for development builds.
 * Nothing here leaves the device: the Developer settings panel reads and
 * exports it. Records are per open, request, batch or long task, never per event. */
export type OpenTrigger = "click" | "keyboard" | "route";
/** Where the first painted rows came from. `disk-late` means the open waited,
 * then a disk restore landed before the network read did. */
export type OpenSource = "memory" | "disk" | "disk-late" | "network";
export type ChannelOpen = Readonly<{
    channel: string;
    trigger: OpenTrigger;
    source: OpenSource;
    /** Input event (or mount) to the frame after first rows were committed. */
    ms: number;
    /** Until the store held rows for the channel: a disk read or relay request.
     * Zero when the rows were already there. The rest of `ms` is rendering. */
    waitMs: number;
    at: number;
    phase: number;
}>;
export type LivePhase = {
    kind: "open" | "reconnect";
    start: number;
    /** First socket authentication in this phase, relative to `start`. */
    authMs?: number;
    /** First moment every channel route had settled (live or failed), relative to `start`. */
    coverageMs?: number;
    routes: number;
    /** Routes that settled without going live: refused, or over live capacity. */
    routeErrors: number;
    /** Pending → live, per channel route. */
    routeMs: number[];
    queries: number;
    background: number;
    bytes: number;
};
type LiveRouteState = Readonly<{
    id: string;
    channelId?: string;
    status: string;
}>;
export declare function percentile(values: readonly number[], p: number): number | undefined;
export declare function createClientMetrics({ enabled, now, monitor, afterPaint, }?: {
    enabled?: boolean;
    now?: () => number;
    /** Observe long tasks (or event-loop lag where unsupported, e.g. WebKit). */
    monitor?: boolean;
    afterPaint?: (callback: () => void) => void;
}): Readonly<{
    enabled: boolean;
    /** A user asked to open a channel; timing starts at the input event.
     * Keyboard activation of a button arrives as a click with no pointer detail. */
    channelIntent: (channel: string, input?: Event | undefined) => void | undefined;
    /** The conversation pane switched channels. A switch without an intent is a route. */
    channelMounted: (channel: string) => void | undefined;
    /** The pane stopped showing a channel (switched, or replaced by another
     * page). Returning to it is a new open, and its unfinished open is dropped
     * unless the pane remounts at once (React StrictMode replays effects). */
    channelUnmounted: (channel: string) => void | undefined;
    /** The store's view of the demanded window when it was ensured. The pane
     * may already have rendered rows it held, before its effect ensured it. */
    channelEnsured: (channel: string, source: "disk" | "memory" | "network") => void | undefined;
    /** The store first holds rows for a channel whose window was empty. */
    channelData: (channel: string, origin: "disk" | "network") => void | undefined;
    /** Message rows were committed for a channel. Records after the first
     * paint in which `visible` holds (a virtualized list may need a frame). */
    channelRendered: (channel: string, visible?: (() => boolean) | undefined) => void | undefined;
    /** The channel settled with nothing to paint (empty or failed), so its
     * pending open would otherwise time the first message or a retry. */
    channelEmpty: (channel: string) => void | undefined;
    /** A finite relay read finished. One call per request, never per event.
     * `session` names the relay session; only the first one seen is recorded. */
    query: (session: string, input: {
        ms: number;
        bytes: number;
        priority: "foreground" | "background";
        ok: boolean;
    }) => void | undefined;
    /** Synchronous main-thread work measured by its caller, per batch. */
    cpu: (stage: string, ms: number, count: number) => void | undefined;
    /** Observe live route state; derives connect/reconnect phases and coverage. */
    live: (session: string, state: Readonly<{
        status: string;
        routes: readonly LiveRouteState[];
    }>) => void | undefined;
    summary: () => {
        opens: {
            n: number;
            p50: number | undefined;
            p90: number | undefined;
            max: number | undefined;
            cacheHitRate: number | undefined;
            /** Opens dropped because nothing painted: empty, failed or scrolled away. */
            skipped: number;
            bySource: Record<OpenSource, {
                n: number;
                p50: number | undefined;
                p90: number | undefined;
                max: number | undefined;
                waitP50: number | undefined;
                renderP50: number | undefined;
            }>;
        };
        mainThread: {
            longTasks: number;
            longTaskMs: number;
            cpu: {
                [k: string]: {
                    ms: number;
                    count: number;
                };
            };
        };
        phases: {
            kind: "open" | "reconnect";
            start: number;
            /** First socket authentication in this phase, relative to `start`. */
            authMs?: number;
            /** First moment every channel route had settled (live or failed), relative to `start`. */
            coverageMs?: number;
            routes: number;
            /** Routes that settled without going live: refused, or over live capacity. */
            routeErrors: number;
            queries: number;
            background: number;
            bytes: number;
            routeMs: {
                n: number;
                p50: number | undefined;
                p90: number | undefined;
                max: number | undefined;
            };
        }[];
    };
    export(label?: string): {
        version: number;
        label: string;
        exportedAt: string;
        userAgent: string | undefined;
        summary: {
            opens: {
                n: number;
                p50: number | undefined;
                p90: number | undefined;
                max: number | undefined;
                cacheHitRate: number | undefined;
                /** Opens dropped because nothing painted: empty, failed or scrolled away. */
                skipped: number;
                bySource: Record<OpenSource, {
                    n: number;
                    p50: number | undefined;
                    p90: number | undefined;
                    max: number | undefined;
                    waitP50: number | undefined;
                    renderP50: number | undefined;
                }>;
            };
            mainThread: {
                longTasks: number;
                longTaskMs: number;
                cpu: {
                    [k: string]: {
                        ms: number;
                        count: number;
                    };
                };
            };
            phases: {
                kind: "open" | "reconnect";
                start: number;
                /** First socket authentication in this phase, relative to `start`. */
                authMs?: number;
                /** First moment every channel route had settled (live or failed), relative to `start`. */
                coverageMs?: number;
                routes: number;
                /** Routes that settled without going live: refused, or over live capacity. */
                routeErrors: number;
                queries: number;
                background: number;
                bytes: number;
                routeMs: {
                    n: number;
                    p50: number | undefined;
                    p90: number | undefined;
                    max: number | undefined;
                };
            }[];
        };
        opens: Readonly<{
            channel: string;
            trigger: OpenTrigger;
            source: OpenSource;
            /** Input event (or mount) to the frame after first rows were committed. */
            ms: number;
            /** Until the store held rows for the channel: a disk read or relay request.
             * Zero when the rows were already there. The rest of `ms` is rendering. */
            waitMs: number;
            at: number;
            phase: number;
        }>[];
        queries: Readonly<{
            at: number;
            ms: number;
            bytes: number;
            priority: "foreground" | "background";
            ok: boolean;
            phase: number;
        }>[];
        longTasks: Readonly<{
            start: number;
            duration: number;
        }>[];
    };
    reset(): void;
}>;
export type ClientMetrics = ReturnType<typeof createClientMetrics>;
/** Development builds only; production and unit tests get a no-op recorder. */
export declare const clientMetrics: Readonly<{
    enabled: boolean;
    /** A user asked to open a channel; timing starts at the input event.
     * Keyboard activation of a button arrives as a click with no pointer detail. */
    channelIntent: (channel: string, input?: Event | undefined) => void | undefined;
    /** The conversation pane switched channels. A switch without an intent is a route. */
    channelMounted: (channel: string) => void | undefined;
    /** The pane stopped showing a channel (switched, or replaced by another
     * page). Returning to it is a new open, and its unfinished open is dropped
     * unless the pane remounts at once (React StrictMode replays effects). */
    channelUnmounted: (channel: string) => void | undefined;
    /** The store's view of the demanded window when it was ensured. The pane
     * may already have rendered rows it held, before its effect ensured it. */
    channelEnsured: (channel: string, source: "disk" | "memory" | "network") => void | undefined;
    /** The store first holds rows for a channel whose window was empty. */
    channelData: (channel: string, origin: "disk" | "network") => void | undefined;
    /** Message rows were committed for a channel. Records after the first
     * paint in which `visible` holds (a virtualized list may need a frame). */
    channelRendered: (channel: string, visible?: (() => boolean) | undefined) => void | undefined;
    /** The channel settled with nothing to paint (empty or failed), so its
     * pending open would otherwise time the first message or a retry. */
    channelEmpty: (channel: string) => void | undefined;
    /** A finite relay read finished. One call per request, never per event.
     * `session` names the relay session; only the first one seen is recorded. */
    query: (session: string, input: {
        ms: number;
        bytes: number;
        priority: "foreground" | "background";
        ok: boolean;
    }) => void | undefined;
    /** Synchronous main-thread work measured by its caller, per batch. */
    cpu: (stage: string, ms: number, count: number) => void | undefined;
    /** Observe live route state; derives connect/reconnect phases and coverage. */
    live: (session: string, state: Readonly<{
        status: string;
        routes: readonly LiveRouteState[];
    }>) => void | undefined;
    summary: () => {
        opens: {
            n: number;
            p50: number | undefined;
            p90: number | undefined;
            max: number | undefined;
            cacheHitRate: number | undefined;
            /** Opens dropped because nothing painted: empty, failed or scrolled away. */
            skipped: number;
            bySource: Record<OpenSource, {
                n: number;
                p50: number | undefined;
                p90: number | undefined;
                max: number | undefined;
                waitP50: number | undefined;
                renderP50: number | undefined;
            }>;
        };
        mainThread: {
            longTasks: number;
            longTaskMs: number;
            cpu: {
                [k: string]: {
                    ms: number;
                    count: number;
                };
            };
        };
        phases: {
            kind: "open" | "reconnect";
            start: number;
            /** First socket authentication in this phase, relative to `start`. */
            authMs?: number;
            /** First moment every channel route had settled (live or failed), relative to `start`. */
            coverageMs?: number;
            routes: number;
            /** Routes that settled without going live: refused, or over live capacity. */
            routeErrors: number;
            queries: number;
            background: number;
            bytes: number;
            routeMs: {
                n: number;
                p50: number | undefined;
                p90: number | undefined;
                max: number | undefined;
            };
        }[];
    };
    export(label?: string): {
        version: number;
        label: string;
        exportedAt: string;
        userAgent: string | undefined;
        summary: {
            opens: {
                n: number;
                p50: number | undefined;
                p90: number | undefined;
                max: number | undefined;
                cacheHitRate: number | undefined;
                /** Opens dropped because nothing painted: empty, failed or scrolled away. */
                skipped: number;
                bySource: Record<OpenSource, {
                    n: number;
                    p50: number | undefined;
                    p90: number | undefined;
                    max: number | undefined;
                    waitP50: number | undefined;
                    renderP50: number | undefined;
                }>;
            };
            mainThread: {
                longTasks: number;
                longTaskMs: number;
                cpu: {
                    [k: string]: {
                        ms: number;
                        count: number;
                    };
                };
            };
            phases: {
                kind: "open" | "reconnect";
                start: number;
                /** First socket authentication in this phase, relative to `start`. */
                authMs?: number;
                /** First moment every channel route had settled (live or failed), relative to `start`. */
                coverageMs?: number;
                routes: number;
                /** Routes that settled without going live: refused, or over live capacity. */
                routeErrors: number;
                queries: number;
                background: number;
                bytes: number;
                routeMs: {
                    n: number;
                    p50: number | undefined;
                    p90: number | undefined;
                    max: number | undefined;
                };
            }[];
        };
        opens: Readonly<{
            channel: string;
            trigger: OpenTrigger;
            source: OpenSource;
            /** Input event (or mount) to the frame after first rows were committed. */
            ms: number;
            /** Until the store held rows for the channel: a disk read or relay request.
             * Zero when the rows were already there. The rest of `ms` is rendering. */
            waitMs: number;
            at: number;
            phase: number;
        }>[];
        queries: Readonly<{
            at: number;
            ms: number;
            bytes: number;
            priority: "foreground" | "background";
            ok: boolean;
            phase: number;
        }>[];
        longTasks: Readonly<{
            start: number;
            duration: number;
        }>[];
    };
    reset(): void;
}>;
export {};
