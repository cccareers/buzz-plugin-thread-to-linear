import type { RelaySession } from "../relay/session";
import type { UserStatus } from "../relay/user-status";
export declare function StatusDisplay({ status, session, compact, focusable, size, }: {
    status: UserStatus | undefined;
    session: RelaySession;
    compact?: boolean;
    focusable?: boolean;
    size?: "default" | "caption";
}): import("react").JSX.Element | null;
export declare function UserStatusDisplay({ session, userId, compact, focusable, size, }: {
    session: RelaySession;
    userId: string;
    compact?: boolean;
    focusable?: boolean;
    size?: "default" | "caption";
}): import("react").JSX.Element;
