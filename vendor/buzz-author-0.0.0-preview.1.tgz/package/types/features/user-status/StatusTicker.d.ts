import { type ReactNode } from "react";
/** Measure the actual text and slot so resizing a preview can retire the ticker. */
export declare function StatusTicker({ text, children, }: {
    text: string;
    children: ReactNode;
}): import("react").JSX.Element;
