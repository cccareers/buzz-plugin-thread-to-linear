import type { NotificationCategory } from "./preferences";
/** Bundled alert sounds under public/sounds, shared with the reference client. */
export declare const SOUND_NAMES: readonly ["bong", "boo", "dng", "doo", "doodone", "doong", "doop", "flirl", "flutter", "oh-no", "ping", "soft", "unison"];
export type SoundName = (typeof SOUND_NAMES)[number] | "silent";
export declare function isSoundName(value: unknown): value is SoundName;
export declare const DEFAULT_SOUND: SoundName;
export type CategorySounds = Readonly<Record<NotificationCategory, SoundName>>;
export declare const DEFAULT_CATEGORY_SOUNDS: CategorySounds;
/** Row copy and recommendations reuse the reference client's event rows. */
export declare const CATEGORY_SOUND_LABELS: Record<NotificationCategory, string>;
export declare const RECOMMENDED_SOUND_BY_CATEGORY: Record<NotificationCategory, SoundName>;
/** Plugin categories have no per-category choice; they use the default sound. */
export declare function resolveCategorySound(sounds: CategorySounds, category: string): SoundName;
export declare function playNotificationSound(name: SoundName): HTMLAudioElement | null;
