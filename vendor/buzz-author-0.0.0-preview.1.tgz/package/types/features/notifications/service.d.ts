import { Service, type Context } from "@deepseek-ai/cordis";
import { type OpenTarget } from "../navigation/targets";
import type { Navigation } from "../navigation/controller";
import { type NotificationPreferences } from "./preferences";
import { type NotificationPlatform, type NotificationPermissionState } from "./platform";
import { type SoundName } from "./sound";
import { type NotificationText } from "./content";
export type NotificationCategoryDescriptor = Readonly<{
    id: string;
    label: string;
}>;
export type NotificationInput = Readonly<{
    sourceKey: string;
    target: OpenTarget;
    /** Optional display text; the host flattens and bounds it before the OS sees it. */
    title?: string;
    body?: string;
}>;
/** Narrows which targets may alert: banners, sounds and the Dock unread dot. */
export type NotificationGate = Readonly<{
    id: string;
    /** A throwing gate is skipped. */
    allows(target: OpenTarget): boolean;
}>;
export interface Notifications {
    register(category: NotificationCategoryDescriptor): Readonly<{
        submit(input: NotificationInput): Promise<boolean>;
    }>;
    /** While registered, only targets every gate allows may alert. Returns a
     * remover; disabling the plugin removes it too. */
    gate(gate: NotificationGate): () => void;
}
declare module "@deepseek-ai/cordis" {
    interface Context {
        notifications: Notifications;
    }
}
export type NotificationEligibility = boolean | "wait";
export type NotificationSnapshot = Readonly<{
    viewer: string | undefined;
    preferences: NotificationPreferences;
    categories: readonly Readonly<{
        key: string;
        label: string;
    }>[];
    permission: NotificationPermissionState;
    requesting: boolean;
    error: string | null;
    preferencesError: string | null;
    platform: string;
    systemManaged: boolean;
    developmentPaused: boolean;
}>;
/** Running-session delivery only: no notification journal, inbox, or recovery protocol. */
export declare class NotificationsService extends Service implements Notifications {
    private readonly navigation;
    private readonly platform;
    private readonly preferences;
    private readonly authorized;
    private readonly playSound;
    readonly indicator: {
        available: boolean;
        snapshot: () => Readonly<{
            permission: import("./indicator").IndicatorPermission;
            requesting: boolean;
            error: string | null;
        }>;
        subscribe(listener: () => void): () => void;
        refresh: () => Promise<void>;
        request: () => Promise<void>;
        setUnread(value: boolean): void;
        dispose(): Promise<void>;
    };
    private readonly contributions;
    private readonly gates;
    private readonly listeners;
    private readonly pending;
    private readonly sounding;
    private readonly seen;
    private closed;
    private readonly lifetime;
    private generation;
    private permissionGeneration;
    private permissionRequest;
    private scheduled;
    private state;
    constructor(ctx: Context, navigation: Navigation, platform?: NotificationPlatform, preferences?: {
        snapshot: () => {
            preferences: Readonly<{
                enabled: boolean;
                notifyWhileViewing: boolean;
                sound: boolean;
                sounds: import("./sound").CategorySounds;
                categories: Readonly<Record<string, boolean>>;
            }>;
            error: string | null;
        };
        subscribe(listener: () => void): () => void;
        selectViewer(next: string | undefined): void;
        update(patch: Partial<NotificationPreferences>): boolean;
        reload(): void;
        dispose(): void;
    }, authorized?: (target: OpenTarget) => boolean, playSound?: (name: SoundName) => void);
    snapshot: () => Readonly<{
        viewer: string | undefined;
        preferences: NotificationPreferences;
        categories: readonly Readonly<{
            key: string;
            label: string;
        }>[];
        permission: NotificationPermissionState;
        requesting: boolean;
        error: string | null;
        preferencesError: string | null;
        platform: string;
        systemManaged: boolean;
        developmentPaused: boolean;
    }>;
    subscribe: (listener: () => void) => () => void;
    private publish;
    reportError: (error: unknown) => void;
    selectViewer(viewer: string | undefined): void;
    updatePreferences(patch: Partial<NotificationPreferences>): boolean;
    reloadPreferences(): void;
    refreshPermission(): Promise<void>;
    requestPermission(): Promise<void>;
    private allowed;
    private soundEnabled;
    /** Whether every registered gate lets this target alert. */
    gated(target: OpenTarget): boolean;
    subscribeGates: (listener: () => void) => () => void;
    gate(gate: NotificationGate): () => void;
    revalidate(): void;
    register(category: NotificationCategoryDescriptor): Readonly<{
        submit: (input: NotificationInput) => Promise<boolean>;
    }>;
    /** Session-owned producers supply existing attention/access facts, never new read intent. */
    admit(category: string, label: string, input: NotificationInput, valid: () => boolean, eligible?: () => NotificationEligibility, text?: () => NotificationText): Promise<boolean>;
    private schedule;
    private deliver;
}
