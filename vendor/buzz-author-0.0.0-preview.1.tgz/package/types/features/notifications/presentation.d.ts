/** Let mounted reading consumers publish post-commit visibility before an alert.
 * Two frames cover React commit and the timeline's own positioning frame. The
 * timer caps the wait when frames stop; eligibility still checks the live lease.
 * This yields presentation only: it neither observes nor marks a message read.
 * Aborting retires the frame and timer at once and leaves the wait pending, so
 * a closed owner schedules no work against a host that may already be gone.
 */
export declare function afterPresentation(host?: Window | undefined, signal?: AbortSignal): Promise<void>;
