import { type CategorySounds } from "./sound";
/** Desired account-local policy is separate from system permission. */
export declare const NOTIFICATION_CATEGORIES: readonly ["mention", "direct", "thread", "agent"];
export type NotificationCategory = (typeof NOTIFICATION_CATEGORIES)[number];
export type NotificationPreferences = Readonly<{
    enabled: boolean;
    notifyWhileViewing: boolean;
    sound: boolean;
    sounds: CategorySounds;
    categories: Readonly<Record<string, boolean>>;
}>;
export declare const DEFAULT_NOTIFICATION_PREFERENCES: NotificationPreferences;
export declare function parsePreferences(raw: unknown): NotificationPreferences;
export declare function createNotificationPreferences(host?: Window | undefined): {
    snapshot: () => {
        preferences: Readonly<{
            enabled: boolean;
            notifyWhileViewing: boolean;
            sound: boolean;
            sounds: CategorySounds;
            categories: Readonly<Record<string, boolean>>;
        }>;
        error: string | null;
    };
    subscribe(listener: () => void): () => void;
    selectViewer(next: string | undefined): void;
    update(patch: Partial<NotificationPreferences>): boolean;
    reload(): void;
    dispose(): void;
};
export type NotificationPreferencesService = ReturnType<typeof createNotificationPreferences>;
