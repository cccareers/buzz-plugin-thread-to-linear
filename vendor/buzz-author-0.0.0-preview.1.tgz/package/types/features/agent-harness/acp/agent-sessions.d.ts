import type { SessionAction } from "../../agents/service";
import type { AcpProcess } from "./process";
import type { ActivityReceipt, Choice, ResolveDirectory, Settled, ToolServer } from "./types";
/** A conversation's session closes after this long without a message. */
export declare const IDLE_MS: number;
/** The most MCP servers the pool's sessions hold at once, below the host's 64
 * for every plugin, so plugins not on this client keep room. */
export declare const POOL_LIMIT = 48;
/** The most session ids a conversation keeps: each reopening starts one. */
export declare const SAVED_SESSIONS = 10;
/** What is saved for one conversation: when its session last took in a
 * message or ended a turn, and the ids of its sessions, newest first. */
export type SavedConversation = Readonly<{
    at: number;
    sessions?: readonly string[];
}>;
/** Whether a saved time is one a Date can hold: finite alone lets 1e20
 * through, which throws when shown. */
export declare const validTime: (at: unknown) => at is number;
/** A saved conversation as read back from storage, or undefined when it is
 * damaged: a time a Date can hold, and its session ids de-duplicated, capped and kept
 * only when each is a short string. One saved before ids were has none. */
export declare function savedConversation(value: unknown): SavedConversation | undefined;
export type SessionStore = {
    get(key: string): SavedConversation | undefined;
    set(key: string, saved: SavedConversation): void;
};
/** A session's hold on one MCP server in the pool. */
export type Slot = {
    /** Whether it can be closed to make room: no turn runs in it. */
    idle(): boolean;
    /** Closes the session, and resolves once its server has stopped. */
    evict(): Promise<unknown>;
};
/** The MCP servers agents' sessions hold, least recently used first. */
export declare class ServerPool {
    private readonly limit;
    private readonly slots;
    constructor(limit?: number);
    get size(): number;
    /** Holds a server for `slot`, first closing idle sessions to keep below the
     * limit. Busy ones are never closed, so it can go over. Resolves once the
     * closed sessions' servers have stopped: the host counts them until then. */
    take(slot: Slot): Promise<unknown[]>;
    /** Marks `slot` as used now. */
    touch(slot: Slot): void;
    release(slot: Slot): void;
    /** Closes the least recently used idle session, and resolves once its
     * server has stopped; undefined when every session is busy. */
    evict(): Promise<unknown> | undefined;
}
/** The pool every ACP plugin's sessions share. */
export declare const SHARED_POOL: ServerPool;
/** What a session is opened with. */
export type Launch = Readonly<{
    /** The agent's working directory, absolute or `~/…`. */
    workspace: string;
    systemPrompt: string;
}>;
export type SessionsOptions = Readonly<{
    /** Names the harness in errors. */
    label: string;
    /** The host's, for the workspace's absolute path. */
    resolveDirectory: ResolveDirectory;
    /** Answers the agent's Buzz tools. */
    tools: ToolServer;
    /** The process its sessions open in, started when needed. */
    process: Readonly<{
        get(): Promise<AcpProcess>;
    }>;
    /** The servers its sessions hold: the shared pool unless given. */
    pool?: ServerPool;
    /** The agent's current settings, for a new session. */
    launch(): Promise<Launch>;
    /** The agent's provider, model and thinking level now, which each new
     * turn runs on. */
    choice(): Choice;
    /** Changes when a setting a session was opened with has changed. */
    fingerprint(): string;
    /** Where each conversation's last use is saved. */
    store?: SessionStore;
    /** Told of each session opened, with the prompt and title it was opened
     * with, and the conversation it opened for: none for a one-off turn. */
    started?(sessionId: string, systemPrompt: string, title?: string, conversation?: string): void;
    /** Called when a conversation's session opens, is sent a message, or
     * closes. */
    onChange?(): void;
}>;
export declare class AgentSessions {
    private readonly options;
    /** The latest process its sessions opened in, whose exit drops them. */
    private process;
    private readonly live;
    /** One-off turns running or starting, by label. */
    private readonly once;
    private onceCount;
    /** Sessions opening, which `shutdown` waits for. */
    private readonly opens;
    /** Sessions closed or closing, until a close of each is acknowledged. */
    private readonly closing;
    /** Conversations whose session is opening, and the turn it opened for. */
    private readonly opening;
    /** created_at of the newest event each conversation's session was shown. */
    private readonly shown;
    /** Conversations that have had a session, whose next new one may have been
     * prompted for the old one. */
    private readonly had;
    private disposed;
    private readonly stopped;
    private readonly late;
    constructor(options: SessionsOptions);
    /** What this conversation's session has been shown. */
    seen(key: string): number;
    active(key: string): boolean;
    /** Whether the work conversation or one-off turn `key`'s session runs now
     * still runs, unstopped and in that session, when asked later. */
    current(key: string): () => boolean;
    /** The harness session serving a conversation or one-off turn, and the
     * process it lives in. */
    serving(key: string): {
        sessionId: string;
        process: AcpProcess;
    } | undefined;
    /** Conversations with a session, whether each is working, and when each
     * last took in a message or ended a turn. */
    snapshot(): {
        key: string;
        busy: boolean;
        sessionId?: string;
        at?: number;
    }[];
    /** Sends `text` into the conversation `key`, and resolves when the session
     * has answered it. `steer` replaces `text` when the session is mid-turn;
     * `fresh` builds it again when the session it was built for was closed;
     * `title` names a session opened for it, except that the conversation's
     * first one is left for the harness to name, if it names sessions, when `named`
     * takes that name;
     * `model`, one of the agent's
     * provider's, and `effort`, one of its thinking levels, are what its turn
     * runs on, and `kept`, a synced level, one it must run on. Once `signal` aborts, it stops
     * waiting for a session to open, which is then kept for the next message,
     * and sends nothing. */
    deliver(key: string, text: string, seen: number, { steer, current, fresh, title, named, signal, model, effort, kept, ...activity }?: Readonly<{
        steer?: string;
        current?: () => boolean;
        fresh?: () => Promise<string>;
        title?: string;
        named?: (title: string) => void;
        signal?: AbortSignal;
        model?: string;
        effort?: string;
        kept?: string;
    }> & ActivityReceipt): Promise<Settled>;
    /** Stops the turn running in conversation `key`, if any, once a session
     * opening for it has taken its message. */
    interrupt(key: string): Promise<void>;
    /** Includes the model call after a final send has answered the turn. */
    idle(key: string): Promise<void>;
    /** Waits for the conversation's session to finish its work, then compacts
     * it or closes it, so the message opens a new one. Without an open session
     * there is nothing to do. */
    reset(key: string, action: SessionAction): Promise<Settled>;
    /** Runs one turn in a new session, then closes it. `label` names it in the
     * snapshot. It gives up, and stops the turn, once `signal` aborts.
     * `prompt` is asked for the turn's text once the session is open, so a turn
     * that should no longer run by then returns undefined and sends nothing. */
    runOnce(label: string, prompt: () => string | undefined | Promise<string | undefined>, { signal, title, current, kept, }?: Readonly<{
        signal?: AbortSignal;
        current?: () => boolean;
        title?: string;
        kept?: string;
    }>): Promise<Settled>;
    /** Closes idle sessions opened with old settings; busy ones close when they
     * next fall idle. */
    reconfigure(): void;
    /** Like `dispose()`, then resolves once every session it opened, or was
     * opening, is closed or its process has exited; rejects if one cannot be. */
    shutdown(): Promise<void>;
    /** Closes its sessions, ending their turns; the process keeps serving other
     * agents. */
    dispose(): void;
    private get pool();
    /** Opened with old settings, which only a new session runs on. */
    private stale;
    /** On a thinking level, when a turn with neither a pick nor a saved level
     * wants the harness's own. goose names no value for its own, so only a new
     * session runs on it; checked as that turn comes, so a session put on a
     * picked level keeps its conversation until then. */
    private leveled;
    /** Opens a session for `key` in the agent's workspace, which `use` records
     * as its user's. */
    private open;
    private start;
    private adopt;
    private answer;
    /** Notes that the session took in a message or ended a turn, and what it
     * has been shown, and restarts its idle countdown. */
    private touch;
    /** Closes the session after IDLE_MS, or waits again while it is busy: a
     * long turn is not new use. */
    private countdown;
    private drop;
    /** Closes the session, failing only for a caller that needs the harness to
     * have acknowledged it. */
    private strict;
    private close;
}
/** `workspace` as an absolute path, which ACP sessions need. One already
 * absolute stays as written, as the sessions started in it recorded it. */
export declare function absolute(resolveDirectory: ResolveDirectory, workspace: string): Promise<string>;
/** `work`, or a rejection with `signal`'s reason once it aborts. */
export declare function abortable<T>(work: Promise<T>, signal?: AbortSignal): Promise<T>;
