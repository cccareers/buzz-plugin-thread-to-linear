export declare const BASE_PROMPT: string;
/** Shown with each turn a mention or DM starts, and with each message that
 * arrives while one runs: what the agent owes it. Watch, timer and wake
 * turns do not get it; their own sections say what to publish. */
export declare const MENTION_PROMPT: string;
/** The `<mention>` section, with a harness's own rules for a mention added. */
export declare function mentionSection(extra?: string): string;
