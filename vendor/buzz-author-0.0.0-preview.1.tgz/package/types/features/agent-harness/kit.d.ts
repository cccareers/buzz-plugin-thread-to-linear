import { type AddedTool } from "../../buzz-mcp/session-tools";
import type { McpHandler } from "../host/service";
import type { AgentKey } from "../agents/membership";
import type { AgentHandle, Delivery } from "../agents/service";
import type { RelayData } from "../relay/service";
/** Whether each thread is its own conversation, or the whole channel is one. */
export type HarnessScope = "thread" | "channel";
/** Where a delivery's turn goes, frozen for the turn. */
export type HarnessConversation = Readonly<{
    /** The channel id, or `<channel>/<root>` for a thread's own conversation.
     * A Solo chat and a DM are always one conversation. */
    key: string;
    channel: string;
    /** The thread's root, when the conversation is one thread. */
    root?: string;
    /** Replies go at the channel's top level, as in a Solo chat. */
    topLevel: boolean;
    /** `#name`, `DM` or a short channel id, for titles. */
    where: string;
}>;
export type HarnessPrompt = Readonly<{
    /** The routing context, the conversation's messages the session has not
     * been shown, the event, plugins' notes and the tools' end-of-turn note. */
    text: string;
    /** What the session has been shown, once this prompt reaches it: save it
     * with the session and give it to the next turn's prompt. Opaque. */
    cursor: string;
    /** Puts back the notes the prompt took, for a turn that never started. */
    restore(): void;
}>;
export type HarnessKit = Readonly<{
    /** The conversation a mention or a wake goes to. Undefined when the
     * harness must not act on it: another trigger, a mention that is not the
     * owner's own or attested by them (a workflow's never is), no channel, or a
     * wake with no conversation to go to. */
    conversation(delivery: Delivery, scope: HarnessScope): Promise<HarnessConversation | undefined>;
    /** Buzz's system prompt for the agent: the base prompt, its session model,
     * `instructions`, its teams, its `core` memory and repositories folder.
     * `tools: false` is for a session without the Buzz tools, whose final
     * message the harness posts as its reply. */
    systemPrompt(delivery: Delivery, options: Readonly<{
        scope: HarnessScope;
        cwd: string;
        instructions: string;
        tools?: boolean;
    }>): Promise<string>;
    /** The turn's prompt, for a session at `cursor`, the one its last prompt
     * gave; none for a new session, which is shown the conversation so far.
     * Takes the notes plugins left for the turn; after `restore`, asking
     * again takes them again. */
    turnPrompt(delivery: Delivery, conversation: HarnessConversation, options?: Readonly<{
        cursor?: string;
    }>): Promise<HarnessPrompt>;
    /** A watch's or timer's turn `text` with its routing context. */
    standalonePrompt(agent: AgentHandle, text: string): string;
    /** Answers the agent's Buzz tools over MCP, for `Host.serveMcp`, acting in
     * `conversation`, or nowhere by default for a standalone turn. `read` gives
     * the file an upload names; without it, uploads of local files fail. */
    tools(agent: AgentHandle, conversation?: HarnessConversation, options?: Readonly<{
        read?(path: string): Promise<Uint8Array>;
    }>): McpHandler;
    /** Posts `text` as the agent in the conversation: in the event's thread, or
     * at the top level. `notifyOwner` tags the owner, as for a failed turn. */
    reply(agent: AgentHandle, conversation: HarnessConversation, text: string, options?: Readonly<{
        notifyOwner?: boolean;
    }>): Promise<void>;
}>;
type Sources = Readonly<{
    relay(key: AgentKey): RelayData | undefined;
    core(key: AgentKey): Promise<string | null | undefined>;
    /** The tools plugins add to every session now. */
    added(): readonly AddedTool[];
    /** The repositories folder section for a relay's partition. */
    repositories(partition: string | undefined): string;
}>;
export declare function harnessKit(sources: Sources): HarnessKit;
export {};
