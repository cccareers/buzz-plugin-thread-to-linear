import type { RelaySession } from "../relay/session";
import { type Recipient } from "./usePeople";
import { type VerifiedPerson } from "../profiles/useVerifiedNames";
export declare function RecipientPicker({ session, scope, selected, labels, disabled, excludedPubkeys, initiallyOpen, maxRecipients, appearance, onChange, onComplete, onTyped, }: {
    session: RelaySession;
    /** View-state partition whose DM visits and earlier choices rank people. */
    scope: string;
    selected: Recipient[];
    /** `selected` as shown: named by their current verified names. */
    labels: readonly VerifiedPerson<Recipient>[];
    disabled: boolean;
    excludedPubkeys?: readonly string[];
    /** Share dialogs keep the people list closed until the To field is used. */
    initiallyOpen?: boolean;
    maxRecipients?: number;
    /** A panel's header row, or a filled control inside a dialog form. */
    appearance?: "header" | "field";
    onChange(people: Recipient[]): void;
    onComplete(): void;
    /** Whether the To field holds text that is not a recipient yet. */
    onTyped(typed: boolean): void;
}): import("react").JSX.Element;
