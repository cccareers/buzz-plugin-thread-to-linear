export type JsonValue = null | boolean | number | string | readonly JsonValue[] | {
    readonly [key: string]: JsonValue;
};
export type NavigationScope = Readonly<{
    viewer: string;
    communityOrigin: string;
}>;
export type GitPluginSource = Readonly<{
    repository: string;
    reference: string;
    path?: string;
    commit?: string;
}>;
/** A single plugin artifact over HTTPS, accepted only at `sha256` and as plugin `id`. */
export type UrlPluginSource = Readonly<{
    id: string;
    url: string;
    sha256: string;
}>;
export type PluginLinkSource = GitPluginSource | UrlPluginSource;
export type OpenTarget = Readonly<{
    version: 1;
    kind: "home";
}> | Readonly<{
    version: 1;
    kind: "settings";
    section?: string;
    /** Plugin-owned presentation data for a contributed Settings card. */
    route?: Readonly<{
        version: number;
        params: JsonValue;
    }>;
    /** Nested provider controls within Agent setup; presentation only. */
    provider?: string;
    scope?: NavigationScope | null;
    pluginImport?: PluginLinkSource;
    pluginId?: string;
}> | Readonly<{
    version: 1;
    kind: "page";
    pluginId: string;
    pageId: string;
    /** null explicitly restores Personal space; omission leaves community selection alone. */
    scope?: NavigationScope | null;
    route?: Readonly<{
        version: number;
        params: JsonValue;
    }>;
}> | Readonly<{
    version: 1;
    kind: "plugin";
    pluginId: string;
    /** Omitted: the plugin's primary page, else its first. */
    pageId?: string;
    /** String route data from a link. The resolved page's own validator
     * decides whether it applies; the page opens without it otherwise. */
    params?: Readonly<Record<string, string>>;
    scope?: NavigationScope | null;
}> | Readonly<{
    version: 1;
    kind: "conversation";
    scope: NavigationScope;
    channelId: string;
    messageId?: string;
    /** Hint only. Resolve the actual root from verified message evidence. */
    threadRootId?: string;
    /** With threadRootId: the thread opens beside that root, revealed in the
     * channel timeline even beyond its newest page, as Open in channel asks. */
    context?: "channel";
    /** Presentation within this conversation; never mutation or confirmation state. */
    panel?: "members";
    /** Message selected for the forwarding dialog; never submission state. */
    forward?: string;
    /** Read-only content selected beside this conversation; never an action. */
    detail?: Readonly<{
        target: string;
        rootId?: string;
    }>;
}>;
export declare function parseGitPluginSource(input: unknown): GitPluginSource;
export declare function parseUrlPluginSource(input: unknown): UrlPluginSource;
export declare function parsePluginLinkSource(input: unknown): PluginLinkSource;
/** All bound ingresses use this parser. A valid address is not authorization. */
export declare function parseOpenTarget(input: unknown): OpenTarget;
export declare function targetKey(target: OpenTarget): string;
