import { type EntityRoute } from "../repos/routes";
import { type PluginLinkSource, type NavigationScope } from "./targets";
/** A published agent card's id: one path segment on the avatars CDN, such as
 * `tinker` or `av_…`. */
export declare const AGENT_CARD_ID: RegExp;
type BuzzLink = {
    format: "plugin-install";
    source: PluginLinkSource;
} | {
    format: "settings";
    section?: string;
    provider?: string;
} | {
    format: "agent-card";
    card: string;
} | {
    format: "removed";
} | {
    format: "entity";
    route: EntityRoute;
} | {
    format: "plugin";
    pluginId: string;
    pageId?: string;
    params?: Readonly<Record<string, string>>;
} | {
    format: "legacy";
    channelId: string;
    messageId?: string;
    threadRootId?: string;
};
/** True for any `buzz:` scheme link, regardless of case. Classification must
 * match `parseBuzzLink`, which normalizes the scheme via `URL`; a lowercase-only
 * `startsWith` check would misroute `BUZZ://…` to external handling. */
export declare function isBuzzLink(href: string): boolean;
/** The Agents page, starting an agent from card `card` in `scope`. */
export declare const agentCardTarget: (card: string, scope: NavigationScope) => {
    readonly version: 1;
    readonly kind: "page";
    readonly pluginId: "buzz.agents";
    readonly pageId: "agents";
    readonly scope: Readonly<{
        viewer: string;
        communityOrigin: string;
    }>;
    readonly route: {
        readonly version: 1;
        readonly params: {
            readonly card: string;
        };
    };
};
/** Legacy links are relative to the receiving conversation's community, never an access grant. */
export declare function parseBuzzLink(href: string): BuzzLink | null;
/** A settings link's target; it has no community scope. */
export declare const settingsTarget: ({ section, provider, }: Readonly<{
    section?: string;
    provider?: string;
}>) => {
    readonly version: 1;
    readonly kind: "settings";
    readonly section?: string;
    readonly provider?: string;
};
export declare function buzzLinkKind(href: string): "buzz" | "channel" | "message" | "thread" | null;
export declare function buzzLinkTarget(href: string, scope: NavigationScope): Readonly<{
    version: 1;
    kind: "home";
}> | Readonly<{
    version: 1;
    kind: "page";
    pluginId: string;
    pageId: string;
    scope?: NavigationScope | null;
    route?: Readonly<{
        version: number;
        params: import("./targets").JsonValue;
    }>;
}> | Readonly<{
    version: 1;
    kind: "plugin";
    pluginId: string;
    pageId?: string;
    params?: Readonly<Record<string, string>>;
    scope?: NavigationScope | null;
}> | Readonly<{
    version: 1;
    kind: "conversation";
    scope: NavigationScope;
    channelId: string;
    messageId?: string;
    threadRootId?: string;
    context?: "channel";
    panel?: "members";
    forward?: string;
    detail?: Readonly<{
        target: string;
        rootId?: string;
    }>;
}> | {
    readonly version: 1;
    readonly kind: "page";
    readonly pluginId: "buzz.agents";
    readonly pageId: "agents";
    readonly scope: Readonly<{
        viewer: string;
        communityOrigin: string;
    }>;
    readonly route: {
        readonly version: 1;
        readonly params: {
            readonly card: string;
        };
    };
} | {
    readonly version: 1;
    readonly kind: "settings";
    readonly section?: string;
    readonly provider?: string;
} | null;
export {};
