import { type OpenTarget } from "./targets";
export declare const HISTORY_CAPACITY = 100;
/** Stable visit identity, distinct from the cancellable attempts to reveal it. */
export type NavigationEntry = Readonly<{
    id: string;
    target: OpenTarget;
}>;
/** Match a logical dialog (including its sections), or exact content visits. */
export type DismissedVisits = readonly string[] | ((target: OpenTarget) => boolean);
export type HistorySnapshot = Readonly<{
    current: NavigationEntry;
    /** Managed, non-dismissed return window, including identities retained across reload. */
    retainedVisits?: readonly string[] | undefined;
    canGoBack: boolean;
    canGoForward: boolean;
    /** The preceding eligible visit, when known to this driver. */
    previous?: NavigationEntry;
    /** Host-address parsing failed; retained target is not a successful destination. */
    invalidAddress?: boolean;
}>;
/** A host uses exactly one driver. Traversal publishes; it never calls push. */
export interface NavigationHistory {
    snapshot(): HistorySnapshot;
    /** Exactly one controller attachment for the lifetime of this driver. UI observes Navigation. */
    attach(controller: () => void): () => void;
    push(target: OpenTarget): void;
    /** Normalize this visit's resolved destination without creating another visit. */
    resolve(target: OpenTarget): void;
    replace(target: OpenTarget): void;
    /** Explicit dismissal retires visits; traversal alone never retires one. */
    dismiss(visits: DismissedVisits, fallback: OpenTarget): void;
    back(): void;
    forward(): void;
    returnTo(entryId: string): boolean;
    dispose(): void;
}
export declare const homeTarget: Readonly<{
    readonly version: 1;
    readonly kind: "home";
}>;
export declare function navigationEntry(target: OpenTarget): NavigationEntry;
/** Non-browser host driver. Browser hosts supply actual session-history traversal. */
export declare function createMemoryHistory(initial?: OpenTarget, capacity?: number): NavigationHistory;
