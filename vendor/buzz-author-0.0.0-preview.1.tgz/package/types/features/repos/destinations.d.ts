import type { EventData, ReadFilter } from "../relay/events";
import type { OpenFailure } from "../navigation/controller";
import { type EntityRoute } from "./routes";
export declare class EntityFailure extends Error {
    readonly reason: OpenFailure;
    constructor(reason: OpenFailure);
}
export declare function entityFailure(error: unknown): OpenFailure;
export declare const values: (event: EventData, name: string) => string[];
export declare const value: (event: EventData, name: string) => string | undefined;
export type Entity = {
    type: "repo";
    owner: string;
    dtag: string;
    address: string;
    name: string;
    description: string;
    event: EventData;
};
export type EntityDetail = {
    entity: Entity;
    channels: string[];
    item?: EventData;
    status?: string;
    commit?: string;
    activity: EventData[];
    items: EventData[];
    /** The issue/PR list read reached its limit; items may be missing. */
    truncated?: boolean;
};
type Read = (filters: readonly ReadFilter[], signal: AbortSignal) => Promise<readonly EventData[]>;
export type RepositoryHome = {
    status: "none";
} | {
    status: "home";
    repositories: Entity[];
};
export declare function entityFromEvent(event: EventData): Entity | undefined;
/** The host supplies verified, principal-bound reads. No feature can pick an origin or signer. */
export declare function repoDestinations(read: Read): {
    peekHome: (channelId: string) => RepositoryHome | undefined;
    clearHomes(): void;
    /** Only a complete read is evidence of "none"; a capped read throws. */
    home(channelId: string, signal: AbortSignal): Promise<RepositoryHome>;
    load(route: EntityRoute, signal: AbortSignal): Promise<EntityDetail>;
};
export {};
