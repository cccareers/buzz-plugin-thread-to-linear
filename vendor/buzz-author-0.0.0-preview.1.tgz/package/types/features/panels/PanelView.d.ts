import type { PanelProps, RegisteredPanel } from "./service";
export declare function PanelView({ panel, contentKey, ...props }: PanelProps & {
    panel: RegisteredPanel;
    /** Host-owned identity when several addresses inspect the same content. */
    contentKey?: string | undefined;
}): import("react").JSX.Element;
