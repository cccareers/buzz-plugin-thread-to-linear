export type PresencePreference = "auto" | "online" | "away" | "offline";
/** One app input/preference source shared by retained community publishers. */
export declare function createPresenceActivity(readIdle?: (() => Promise<number | null>) | undefined): {
    status: () => "online" | "away" | "offline";
    command: () => number;
    snapshot: () => {
        status: ReturnType<() => "online" | "away" | "offline">;
        preference: PresencePreference;
        error: string | undefined;
    };
    setViewer(value: string): void;
    setPreference(value: PresencePreference): void;
    visible: () => boolean;
    subscribe(listener: () => void): () => void;
    dispose(): void;
};
export type PresenceActivity = Pick<ReturnType<typeof createPresenceActivity>, "status" | "visible" | "subscribe" | "dispose"> & {
    command?: () => number;
};
