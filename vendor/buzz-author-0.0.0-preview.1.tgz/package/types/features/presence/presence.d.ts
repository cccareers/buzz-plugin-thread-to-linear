import type { ReadTransport } from "../relay/transport";
import type { LiveSubscription } from "../relay/live";
import type { PresenceActivity } from "./activity";
export type PresenceStatus = "online" | "away" | "offline" | "unknown";
/** Volatile session-owned evidence. No event retention or outbox. */
export declare function createPresence(transport: ReadTransport | null, activity: PresenceActivity | undefined, publish: NonNullable<LiveSubscription["publishPresence"]>, notify: (listener: () => void) => void): {
    status(key: string): PresenceStatus;
    limited: (key: string) => boolean;
    /** Notifies when demand moves subjects within or past the limit, so a
     * presence layered on this one can keep to the same window. */
    subscribeSelection(listener: () => void): () => void;
    subscribe(key: string, listener: () => void, profile?: boolean): () => void;
    connected(value: boolean): void;
    clear: (publication?: boolean) => void;
    refresh: () => void;
    dispose(): void;
};
export type Presence = ReturnType<typeof createPresence>;
