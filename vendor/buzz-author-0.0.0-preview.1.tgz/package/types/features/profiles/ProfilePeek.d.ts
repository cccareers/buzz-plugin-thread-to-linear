import { type ReactElement } from "react";
import type { RelaySession } from "../relay/session";
type ProfilePeekProps = {
    trigger: ReactElement;
    name: string;
    picture: string | undefined;
    pubkey: string;
    agent: boolean;
    session: RelaySession | undefined;
    channelId: string;
    viewer: string | undefined;
    target: string;
    onOpen(target: string): boolean;
    onFocusChange?(focused: boolean): void;
};
/** A lightweight look at the same identity the avatar opens in the profile panel. */
export declare function ProfilePeek({ trigger, target, onOpen, name, picture, pubkey, agent, session, channelId, viewer, onFocusChange, }: ProfilePeekProps): import("react").JSX.Element;
export {};
