import type { UploadProgress } from "../relay/attachments";
/** Shared save policy; display-only inherited artwork may still fail validation. */
export declare function avatarPictureError(value: string): string | undefined;
export declare function avatarPreview(value: string, community?: string, size?: "small"): string | undefined;
/** Relay-hosted media of one community through the host's media adapter. */
export declare function communityMedia(community: string): (source: string, size?: "small") => string | undefined;
/** Use the existing host upload/preparation contract, never an agent key in React. */
export declare function uploadAvatar(file: File, community: string, signal: AbortSignal, progress?: UploadProgress): Promise<string>;
/** The emoji's longer side as a share of the image: by default the square
 * inscribed in a circular avatar, so clipping never crops it. */
export declare const emojiAvatarScale = 0.7;
/** Fit painted pixels: emoji font metrics differ between browser engines. */
export declare function paintEmojiAvatar(canvas: HTMLCanvasElement, emoji: string, color?: string, scale?: number, offset?: number): void;
/** Persist ordinary square artwork; Avatar owns human/agent clipping. */
export declare function emojiAvatar(emoji: string, color: string, scale?: number, offset?: number): Promise<File>;
