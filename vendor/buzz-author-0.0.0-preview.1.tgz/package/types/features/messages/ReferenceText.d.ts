import { type ReactNode } from "react";
import type { RelaySession } from "../relay/session";
import type { ComposerSession } from "./composer-session";
import type { ChannelSummary, Profile } from "../relay/contracts";
import type { ConversationExtensions } from "../conversation/contracts";
/** A mention chip's contents. The icon stays with the first character, so a
 * chip at a line end never strands its icon; the rest wraps within the message. */
export declare function MentionLabel({ agent, label, }: {
    agent: boolean;
    label: string;
}): import("react").JSX.Element;
/** The only channel fields a reference may read; the rest can be out of date. */
export type ReferenceChannel = Pick<ChannelSummary, "id" | "name" | "channelType" | "private" | "archived">;
export declare const emptyReferenceDirectory: {
    profiles: ReadonlyMap<string, Readonly<{
        verified?: import("../relay/verified-profile").VerifiedProfile;
        name: string;
        nameIsFallback?: true;
        username?: string;
        picture?: string;
        about?: string;
        nip05?: string;
        isAgent?: true;
        ownerPubkey?: string;
    }>>;
    /** The joined list. Raw `buzz://channel/<id>` links resolve through it
     * alone, so an unjoined channel takes its exact reference's name. */
    channels: readonly ReferenceChannel[];
    /** Channels `#name` prose may link: the joined list, then the open channels
     * a completed public directory read named. */
    named: readonly ReferenceChannel[];
    agents: readonly Readonly<{
        pubkey: string;
        name: string;
        avatar?: string;
        definitionId?: string;
    }>[];
};
export declare function useReferenceDirectory(session: RelaySession | ComposerSession | undefined, selectedProfiles?: ReadonlyMap<string, Profile>): {
    profiles: ReadonlyMap<string, Readonly<{
        verified?: import("../relay/verified-profile").VerifiedProfile;
        name: string;
        nameIsFallback?: true;
        username?: string;
        picture?: string;
        about?: string;
        nip05?: string;
        isAgent?: true;
        ownerPubkey?: string;
    }>>;
    channels: readonly ReferenceChannel[];
    named: readonly ReferenceChannel[];
    agents: readonly Readonly<{
        pubkey: string;
        name: string;
        avatar?: string;
        definitionId?: string;
    }>[];
};
/** Buzz links carry no community, so they always name a channel in the receiving one. */
export declare function channelForLink(url: string, channels: readonly ReferenceChannel[]): ReferenceChannel | undefined;
export declare function channelLinkLabel(url: string, channels: readonly ReferenceChannel[]): string | undefined;
export declare function ReferenceText({ text, mentions, directory, renderText, onOpenLink, extensions, session, scope, channelId, interactive, }: {
    text: string;
    mentions: readonly string[];
    directory: ReturnType<typeof useReferenceDirectory>;
    renderText(text: string): ReactNode;
    onOpenLink(url: string): boolean;
    extensions?: ConversationExtensions | undefined;
    session?: RelaySession | ComposerSession | undefined;
    scope?: string | undefined;
    channelId?: string | undefined;
    interactive?: boolean;
}): string | number | bigint | boolean | import("react").JSX.Element | Iterable<ReactNode> | Promise<string | number | bigint | boolean | Iterable<ReactNode> | import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>> | import("react").ReactPortal | null | undefined> | null | undefined;
