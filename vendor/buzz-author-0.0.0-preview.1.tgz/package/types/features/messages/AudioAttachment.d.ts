import { type Attachment } from "../relay/contracts";
export declare function AudioAttachment({ attachment, source, allowDownload, }: {
    attachment: Attachment;
    source: string;
    allowDownload?: boolean;
}): import("react").JSX.Element;
