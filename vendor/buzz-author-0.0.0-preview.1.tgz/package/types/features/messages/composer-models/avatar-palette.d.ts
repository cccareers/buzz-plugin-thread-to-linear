export declare function useAvatarPalette(src: string | undefined): string[];
