import type { ChannelMessage } from "../relay/contracts";
import { type AttachmentDraft } from "./attachment-draft";
import { type ReactNode, type RefObject } from "react";
import { type ComposerSession } from "./composer-session";
import type { RelaySession } from "../relay/session";
import { type MentionDraft, type MentionRecipient } from "./mention-draft";
import { type DraftPicks } from "./ComposerModels";
import type { MentionPicks } from "../relay/messages";
import type { ConversationExtensions } from "../conversation/contracts";
import type { MessageLinkOrigin } from "./MessageRow";
export type MessageComposerProps = {
    extensions?: ConversationExtensions | undefined;
    scope: string;
    session: ComposerSession | RelaySession;
    channelId: string;
    channelName: string;
    label?: string | undefined;
    placeholder?: string | undefined;
    soloConversation?: boolean | undefined;
    ownSoloConversation?: boolean | undefined;
    /** Seeds an empty draft, or an unaddressed submission that requires a recipient. */
    defaultMention?: MentionRecipient | undefined;
    /** Whether a retained tab shows this composer, apart from its read policy.
     * A composer shown again may reseed its remembered agents (see seedMentions). */
    shown?: boolean | undefined;
    /** Sending needs at least one tagged recipient. */
    requireMention?: boolean | undefined;
    chatPresentation?: boolean | undefined;
    trailingTool?: ReactNode;
    inviteAgents?: boolean | undefined;
    onSend?: (id: string) => void;
    /** A plain slash command with no recipients or attachments may be consumed by
     * its conversation owner. Return false to send it as an ordinary message. */
    onCommand?: ((command: string, signal: AbortSignal) => boolean | Promise<boolean>) | undefined;
    /** Inbox may retire only after saving the replacement or confirming no draft remains. */
    onDraftSaved?: (() => void) | undefined;
    /** Before a focused form detaches, its host can hand focus to retained content. */
    onFocusedRemoval?: (() => void) | undefined;
    /** Threads supply their own retained rows; channels use the shared window. */
    editMessages?: readonly ChannelMessage[] | undefined;
    onOpenLink?: ((target: string, origin?: MessageLinkOrigin) => boolean) | undefined;
    canOpenLink?: ((target: string) => boolean) | undefined;
    threadRootId?: string;
    /** The viewer's latest message in this thread, once the thread has loaded.
     * An empty thread composer starts with the agents it notified (see
     * seedMentions); other composers read their own channel window. */
    threadSeed?: Pick<ChannelMessage, "id" | "mentions"> | undefined;
    replyParentId?: string | undefined;
    /** Bind a timecoded reply to the selected gallery attachment. */
    mediaTargetUrl?: string | undefined;
    replyContext?: ReactNode;
    mediaTimeSeconds?: number;
    clearMediaTime?(): void;
    /** Focus once on entry; an owner can cancel its target before a delayed mount. */
    autoFocus?: boolean | RefObject<HTMLElement | null>;
    focusRequest?: number;
    hideMediaTimeIndicator?: boolean;
    disabled?: boolean;
    /** A new conversation owns persistence and delivery before a channel exists. */
    submission?: {
        draftKey: string;
        initialDraft?: MentionDraft | string | undefined;
        /** A durable operation overrides disposable view state during recovery. */
        recoveredDraft?: MentionDraft | undefined;
        locked: boolean;
        disabled: boolean;
        /** Files upload before the conversation exists; submit sends them. */
        attachments?: boolean;
        /** DMs can start with files alone; named Solo chats still require text. */
        allowAttachmentOnly?: boolean;
        /** New Solo chats keep their picks on the stable draft until creation. */
        modelPicksKey?: string;
        /** Told after each save whether the editor holds a draft it could not
         * save, which view state then misses. */
        unsaved?: ((held: boolean) => void) | undefined;
        /** Hears each edit, whether or not saving it succeeded. */
        onDraftChange?: ((draft: MentionDraft) => void) | undefined;
        /** `addressed`: the toolbar's agents, when they are held apart from the text. */
        submit: (draft: MentionDraft, attachments: AttachmentDraft, addressed?: readonly MentionRecipient[], picks?: MentionPicks, draftPicks?: DraftPicks, draftPicksRevision?: string | null) => void;
    };
};
/** Safe to retarget through ordinary props; callers do not own internal remount keys. */
export declare function MessageComposer(props: MessageComposerProps): import("react").JSX.Element;
