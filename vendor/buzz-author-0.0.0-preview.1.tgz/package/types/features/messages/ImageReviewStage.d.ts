import type { Attachment } from "../relay/contracts";
type ImageReviewStageProps = {
    attachments: readonly Attachment[];
    selectedUrl: string;
    media(url: string): string | undefined;
    select(url: string): void;
    onOpenLink(url: string): boolean;
    allowCopy?: boolean;
};
export declare function ImageReviewStage({ attachments, selectedUrl, media, select, onOpenLink, allowCopy, }: ImageReviewStageProps): import("react").JSX.Element;
export {};
