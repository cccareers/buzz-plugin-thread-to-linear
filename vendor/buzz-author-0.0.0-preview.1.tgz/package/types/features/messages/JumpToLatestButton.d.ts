export declare function JumpToLatestButton({ visible, newMessageCount, onClick, }: {
    visible: boolean;
    newMessageCount: number;
    onClick(): void;
}): import("react").JSX.Element;
