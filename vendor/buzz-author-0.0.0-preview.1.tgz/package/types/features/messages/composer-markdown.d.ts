import type { MentionDraft } from "./mention-draft";
/** Plain portions are authored Markdown, not rich-editor literal text. Keeping
 * their source verbatim avoids normalizing formats this slice does not edit.
 * Marked content uses CommonMark/GFM delimiter escaping and flanking rules. */
export declare function composerMarkdown(draft: MentionDraft): string;
