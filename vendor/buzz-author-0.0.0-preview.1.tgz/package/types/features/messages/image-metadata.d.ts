type Chunk = {
    kind: string;
    payload: Uint8Array;
    raw: Uint8Array;
};
export declare function pngChunks(bytes: Uint8Array): Chunk[];
export declare function snapshotChunk(chunks: Chunk[]): Uint8Array | undefined;
export declare function isPngRenderingChunk(kind: string): boolean;
export declare function pngNeedsPixelTransform(chunks: Chunk[]): boolean;
export declare function cleanPng(bytes: Uint8Array, snapshot?: Uint8Array, animated?: boolean): Blob;
export declare function webpChunks(bytes: Uint8Array): Chunk[];
export declare function webpNeedsPixelTransform(chunks: Chunk[]): boolean;
export declare function cleanWebp(bytes: Uint8Array, animated: boolean): Blob;
export declare function cleanGif(b: Uint8Array): Blob;
export {};
