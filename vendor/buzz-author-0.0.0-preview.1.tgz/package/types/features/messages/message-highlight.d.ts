/** The part of a `[data-message-id]` item the arrival cue paints: the message
 * itself, never its day divider. Each row type marks its own surface. */
export declare function messageHighlightSurface(item: HTMLElement): HTMLElement | null;
/** Briefly mark a message so the reader can find where they arrived. The cue
 * paints on the surface itself or, when it has a filled bubble, on that
 * bubble. Returns a clear for an early retire. */
export declare function highlightMessage(item: HTMLElement): () => void;
/** How long the arrived-at message must hold still before it is marked. */
export declare const HIGHLIGHT_QUIET_MS = 200;
/** A message that never settles is marked anyway after this long. */
export declare const HIGHLIGHT_MAX_WAIT_MS = 1500;
/** Whether any of `box` shows inside both `viewport` and the window. */
export declare function onScreen(box: DOMRect, viewport: DOMRect): boolean;
/** Mark a message once it stops moving. Rows, media and panels around a fresh
 * arrival can shift it for a moment; a cue during that settle reads as a
 * glitch, so wait until the row and the list around it hold still. The row is found by id each frame, since a virtual list may remount
 * it, and is marked only if it is still on screen. Returns a clear that
 * cancels the wait or retires the cue. */
export declare function highlightWhenSettled(scroller: HTMLElement, messageId: string): () => void;
