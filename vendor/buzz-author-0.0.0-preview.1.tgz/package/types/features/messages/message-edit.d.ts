import type { AgentLibrary } from "../agents/library";
import type { ChannelMessage, Profile } from "../relay/contracts";
import type { MentionRecipient } from "./mention-draft";
/** Display-only identity link: literal one-line label, exact profile target, no
 * recipient. CommonMark unescapes every ASCII punctuation mark, so escaping all
 * of them keeps a name from authoring emphasis, code, entities or links. */
export declare function profileMentionLink(label: string, target: string): string;
/** Picker selection during an edit becomes the same link as a preserved
 * mention, followed by the key that ended the name or a space. */
export declare const editMentionText: ({ pubkey, name }: MentionRecipient, after?: string) => string;
/** Keep attachment Markdown and turn already-bound names into explicit identities.
 * Edited legacy prose remains unbound; the editor never invents recipients. */
export declare function messageEditText(row: ChannelMessage, profiles: ReadonlyMap<string, Profile>, agents?: AgentLibrary["identities"]): string;
/** Attachments are not editable in this surface; original metadata stays signed. */
export declare function validateMessageEdit(row: ChannelMessage, initial: string, content: string): string;
