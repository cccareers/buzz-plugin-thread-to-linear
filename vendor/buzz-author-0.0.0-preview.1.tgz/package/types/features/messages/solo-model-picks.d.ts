import type { DraftPicks } from "./ComposerModels";
export { lockSoloModelPicks } from "./solo-model-picks-lock";
export declare const soloModelPicksKey: (channelId: string) => string;
export declare function parseSoloModelPicks(revision: string | null | undefined): DraftPicks;
export declare function readSoloModelPicks(scope: string, key: string): Promise<{
    revision: string | null;
    version: string;
}>;
export declare function updateSoloModelPicks(scope: string, key: string, edits: ReadonlyMap<string, DraftPicks[string] | undefined>): Promise<Promise<{
    picks: {
        [x: string]: Readonly<{
            model?: string;
            effort?: string;
        }> & Readonly<{
            type?: string;
        }>;
    };
    version: string;
}>>;
