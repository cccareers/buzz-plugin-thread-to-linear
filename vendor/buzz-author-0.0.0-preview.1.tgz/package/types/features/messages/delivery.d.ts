import type { ChannelMessage } from "../relay/contracts";
export declare const DELIVERY_GRACE_MS = 10000;
export declare function deliveryFeedback(row: Pick<ChannelMessage, "delivery" | "createdAt" | "deliveryError">, now: number): string | undefined;
