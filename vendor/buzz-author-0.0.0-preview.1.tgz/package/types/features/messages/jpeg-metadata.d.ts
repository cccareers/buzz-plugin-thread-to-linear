/** Strip encoder-added metadata only AFTER pixels have been oriented and drawn
 * into the sRGB canvas. Applying this to source photos would lose appearance. */
export declare function cleanEncodedJpeg(bytes: Uint8Array): Blob;
