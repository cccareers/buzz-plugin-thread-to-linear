export type LiteralRange = Readonly<{
    start: number;
    end: number;
}>;
export type PreparedMarkdown = Readonly<{
    kind: "plain";
    content: string;
}> | Readonly<{
    kind: "markdown";
    content: string;
    literalRanges: readonly LiteralRange[];
    spoilerDelimiters: readonly number[];
}>;
export declare const isLiteralMarkdownContext: (type: string) => boolean;
/** Prose that no Markdown, GFM or message syntax acts on: no syntax characters,
 * `:` (shortcodes, URL schemes), `@`, `www.`, private-use placeholders, tabs or
 * other controls, line-start list or indent markers, or a space before a line
 * ending. Its tree is paragraphs of text, which `plainProseTree` builds. */
export declare const isPlainProse: (content: string) => boolean;
/** The tree micromark builds for `isPlainProse` content. */
export declare const plainProseTree: (content: string) => {
    type: string;
    children: {
        type: string;
        children: {
            type: string;
            value: string;
        }[];
    }[];
};
/** Pure, immutable Markdown work; MessageMarkdown keeps recent results. */
export declare function prepareMarkdown(content: string): PreparedMarkdown;
