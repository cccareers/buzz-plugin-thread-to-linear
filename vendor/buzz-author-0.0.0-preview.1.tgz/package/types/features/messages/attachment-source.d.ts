/** Only the URLs emitted by convertFileSrc(relayMediaUrl, "buzz-media"). */
export declare function isNativeMediaSource(source: string): boolean;
export declare function isProxySource(source: string): boolean;
export declare function safeOpenUrl(value: string): boolean;
