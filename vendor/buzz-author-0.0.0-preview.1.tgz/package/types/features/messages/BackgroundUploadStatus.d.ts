import type { ComposerSession } from "./composer-session";
/** Desktop's composer upload pill and failure toasts, for this session's sends. */
export declare function BackgroundUploadStatus({ session, focusTarget, here, onOpenLink, }: {
    session: ComposerSession;
    focusTarget: React.RefObject<HTMLElement | null>;
    /** The conversation the hosting composer presents, which a notice need not
     * open. Absent while a covered tab hides it. */
    here?: string | undefined;
    /** The hosting composer's link handler opens a notice's conversation. */
    onOpenLink?: ((target: string) => boolean) | undefined;
}): import("react").JSX.Element;
