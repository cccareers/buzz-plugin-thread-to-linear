/** Shared file artwork for composer drafts and received/downloadable files. */
export declare function FileTypeIcon({ name, mime, }: {
    name?: string | undefined;
    mime?: string | undefined;
}): import("react").JSX.Element;
