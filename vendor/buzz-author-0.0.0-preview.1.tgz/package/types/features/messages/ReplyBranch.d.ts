import { type ReactNode } from "react";
/**
 * A reply with its nested replies. The branch opens from its summary and folds
 * back from its thread line.
 */
export declare function ReplyBranch({ message, layout, summary, label, collapseLabel, hasReplies, open, depth, onExpand, onCollapse, children, }: {
    message: ReactNode;
    layout: "thread" | "continuation";
    summary: ReactNode;
    label: string;
    collapseLabel: string;
    hasReplies: boolean;
    open: boolean;
    depth: number;
    onExpand(): void;
    onCollapse(): void;
    children: ReactNode;
}): import("react").JSX.Element;
