import { type VoiceRecording } from "../relay/voice-media";
import type { ComposerSession } from "./composer-session";
import { type UploadedAttachment } from "../relay/attachments";
export type DraftAttachment = Readonly<{
    id: string;
    file: File;
    voice?: UploadedAttachment["voice"];
    status: "queued" | "preparing" | "uploading" | "ready" | "error";
    uploaded?: UploadedAttachment;
    error?: string | undefined;
    /** Host-reported bytes for the current prepared transfer. */
    transfer?: Readonly<{
        sent: number;
        total: number;
    }> | undefined;
}>;
export type AttachmentDraft = {
    snapshot(): readonly DraftAttachment[];
    subscribe(listener: () => void): () => void;
    /** Admits the files that fit, in order. A lone file that does not fit throws
     * why; otherwise one sentence per reason names the first files left out
     * and counts the rest. */
    add(files: readonly File[], recording?: VoiceRecording): readonly string[];
    addUploaded(attachment: UploadedAttachment): void;
    adopt(files: readonly DraftAttachment[]): boolean;
    prepareForSend(signal: AbortSignal): Promise<readonly UploadedAttachment[]>;
    remove(id: string): void;
    retry(id: string): void;
    cancel(): void;
    resume(): void;
    clear(): void;
};
/** Send transfers the existing upload owner; clearing the composer cannot abort it. */
export declare function transferAttachmentDraft(source: AttachmentDraft, target: AttachmentDraft): void;
/** Files held for a composer `key`, without creating its draft. */
export declare function attachmentDraftCount(session: ComposerSession, key: string): number;
/** Hear when any of the session's drafts gains or loses files, including
 * drafts whose composer is no longer mounted. */
export declare function subscribeAttachmentDraftCounts(session: ComposerSession, listener: () => void): () => void;
export declare const MAX_ATTACHMENT_FILES = 10;
/** Tab-local files survive navigation, not reload. Delivery remains outbox-owned.
 * A new chat's draft uploads before its channel exists. */
export declare function attachmentDraft(session: ComposerSession, key: string, channelId: string, newChat?: boolean): AttachmentDraft;
/** A confirmed deletion discards only this session's exact scoped composer files.
 * A missing store is a no-op; do not allocate a draft merely to clear it. */
export declare function clearAttachmentDraft(session: ComposerSession, key: string): void;
export declare function useAttachmentDraft(session: ComposerSession, key: string, channelId: string, newChat?: boolean): {
    store: AttachmentDraft;
    items: readonly Readonly<{
        id: string;
        file: File;
        voice?: UploadedAttachment["voice"];
        status: "queued" | "preparing" | "uploading" | "ready" | "error";
        uploaded?: UploadedAttachment;
        error?: string | undefined;
        /** Host-reported bytes for the current prepared transfer. */
        transfer?: Readonly<{
            sent: number;
            total: number;
        }> | undefined;
    }>[];
    blocked: boolean;
};
