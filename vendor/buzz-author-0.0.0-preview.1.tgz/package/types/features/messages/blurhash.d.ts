export declare const BLURHASH_SIZE = 32;
/** Local, bounded raster only; no URL, source-sized canvas or retained cache. */
export declare function paintBlurhash(canvas: HTMLCanvasElement, hash: string): void;
