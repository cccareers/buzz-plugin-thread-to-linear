import { type ReactNode } from "react";
import type { Attachment } from "../relay/contracts";
export type MediaPlayback = Readonly<{
    attachmentUrl: string;
    seconds: number;
}>;
type MediaAttachmentProps = {
    attachment: Attachment;
    media(url: string): string | undefined;
    mode?: "inline" | "thread";
    imageDescription?: string;
    preload?: "auto" | "metadata" | "none";
    seekTo?: number;
    seekRequest?: number;
    onPlayback?(playback: MediaPlayback): void;
    onOpenReview?(attachment: Attachment, seconds: number): void;
    compact?: boolean;
    overlayCount?: number;
    label?: string;
};
export declare function MediaAttachment({ attachment, media, mode, imageDescription, preload, seekTo, seekRequest, onPlayback, onOpenReview, compact, overlayCount, label, }: MediaAttachmentProps): import("react").JSX.Element;
/** The plain fullscreen fallback for surfaces that host no media review. */
export declare function MediaViewer({ title, close, children, }: {
    title: string;
    close(): void;
    children: ReactNode;
}): import("react").JSX.Element;
export {};
