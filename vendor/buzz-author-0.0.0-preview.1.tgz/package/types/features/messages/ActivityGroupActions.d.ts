import type { MessageLinkOrigin } from "./MessageRow";
import { type RefObject } from "react";
import type { RelaySession } from "../relay/session";
import type { Profile } from "../relay/contracts";
import { type ActivityPresentation } from "./activity-presentation";
/** The visible history owns navigation and controls for its exact request. */
export declare function ActivityGroupActions({ session, group, profiles, open, canOpen, returnFocus, active, }: {
    returnFocus: RefObject<HTMLButtonElement | null>;
    /** False while the history is collapsed; a pending stop keeps tracking. */
    active: boolean;
    session: RelaySession;
    group: ActivityPresentation;
    profiles: ReadonlyMap<string, Profile>;
    open?: ((target: string, origin?: MessageLinkOrigin) => boolean) | undefined;
    canOpen?: ((target: string) => boolean) | undefined;
}): import("react").JSX.Element;
