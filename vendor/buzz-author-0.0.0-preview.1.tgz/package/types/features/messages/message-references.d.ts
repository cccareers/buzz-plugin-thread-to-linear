import type { ChannelSummary, Profile } from "../relay/contracts";
import type { AgentLibrary } from "../agents/library";
export type MessageReference = {
    start: number;
    end: number;
    label: string;
    kind: "channel" | "person" | "agent";
    id: string;
    private?: true;
};
/** Names are display evidence only. People must also have an explicit signed mention. */
export declare function messageReferences(text: string, mentions: readonly string[], profiles: ReadonlyMap<string, Profile>, channels: readonly ChannelSummary[], agents: AgentLibrary["identities"]): MessageReference[];
