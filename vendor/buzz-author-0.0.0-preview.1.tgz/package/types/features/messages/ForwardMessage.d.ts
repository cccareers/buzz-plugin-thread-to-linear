import { type ReactNode } from "react";
import type { Navigation } from "../navigation/controller";
import type { ChannelMessage } from "../relay/contracts";
import type { RelaySession } from "../relay/session";
export declare const useForwardMessage: () => ((row: ChannelMessage) => void) | undefined;
export declare function ForwardMessageProvider({ session, scope, navigation, renderDialog, children, }: {
    session: RelaySession;
    scope: string;
    navigation: Navigation | undefined;
    renderDialog?: boolean;
    children: ReactNode;
}): import("react").JSX.Element;
