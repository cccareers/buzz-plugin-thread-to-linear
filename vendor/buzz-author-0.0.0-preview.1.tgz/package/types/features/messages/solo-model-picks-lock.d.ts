/** One scope lock also covers New chat transfers and purge, never delivery. */
export declare function lockSoloModelPicks<T>(scope: string, run: () => T): Promise<T>;
