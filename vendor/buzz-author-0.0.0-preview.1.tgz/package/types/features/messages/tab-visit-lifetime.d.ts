/** Register the current retirement owner without retaining a relay session. */
export declare function retainTabVisits(scope: string, forget: (scope: string) => void): void;
/** Forget one scope and fence late writes from its previous tab stores. */
export declare function forgetTabVisits(scope: string): void;
