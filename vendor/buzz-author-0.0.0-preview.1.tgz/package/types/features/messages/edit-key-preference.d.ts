/** Device-local choice: plain Up edits from an empty composer. Off by default. */
export declare const editKeyPreference: {
    read: () => boolean;
    subscribe: (listener: () => void) => () => void;
    usePreference: () => boolean;
    useSaveError: () => "This choice is active, but could not be saved on this device. Try again." | null;
    set: (enabled: boolean) => string | null;
};
export declare const editWithUpArrowPreference: () => boolean, useEditWithUpArrowPreference: () => boolean, setEditWithUpArrowPreference: (enabled: boolean) => string | null;
