import type { ReactNode } from "react";
/** Reveal intrinsic space without rounding each virtual row to whole pixels.
 * Base UI retains exiting content until the grid transition finishes. */
export declare function ActivityExpansion({ open, enabled, className, children, }: {
    open: boolean;
    enabled?: boolean;
    className?: string | undefined;
    children: ReactNode;
}): string | number | bigint | boolean | import("react").JSX.Element | Iterable<ReactNode> | Promise<string | number | bigint | boolean | Iterable<ReactNode> | import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>> | import("react").ReactPortal | null | undefined> | null | undefined;
