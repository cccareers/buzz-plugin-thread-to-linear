export declare function mediaCornerClip(width: number, height: number, radius: number, x?: number, y?: number): string;
export declare function mediaCornerPath(width: number, height: number, radius: number, x?: number, y?: number): string;
