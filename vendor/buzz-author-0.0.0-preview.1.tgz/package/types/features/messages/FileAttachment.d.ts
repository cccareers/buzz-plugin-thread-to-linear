import type { Attachment } from "../relay/contracts";
export declare function formatFileSize(size: number): string;
export declare function FileAttachment({ attachment, source, onOpenLink, }: {
    attachment: Attachment;
    source: string | undefined;
    onOpenLink(url: string): boolean;
}): import("react").JSX.Element;
