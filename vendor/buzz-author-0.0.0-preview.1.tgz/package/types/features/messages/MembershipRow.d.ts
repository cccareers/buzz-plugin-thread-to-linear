import type { IdentityNameView } from "../identity-names/service";
import type { Profile } from "../relay/contracts";
import { type TimelineRow } from "./membership-rows";
/** Quiet, non-conversational activity. Avatars are decorative; prose owns the
 * label, and each named member opens their profile like a prose mention. */
export declare const MembershipRow: import("react").MemoExoticComponent<({ row, names, profiles, viewer, media, agentPubkeys, day, resolveName: scopedName, onOpenLink, canOpenLink, }: {
    row: TimelineRow;
    names?: IdentityNameView | undefined;
    profiles: ReadonlyMap<string, Profile>;
    viewer?: string | undefined;
    media(url: string, size?: "small"): string | undefined;
    agentPubkeys?: ReadonlySet<string> | undefined;
    day: boolean;
    resolveName?: (pubkey: string, fallback: string) => string;
    onOpenLink?: ((url: string) => boolean) | undefined;
    canOpenLink?: ((target: string) => boolean) | undefined;
}) => import("react").JSX.Element>;
