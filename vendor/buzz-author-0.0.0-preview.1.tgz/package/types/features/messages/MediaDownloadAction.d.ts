export declare function MediaDownloadAction({ source, name, kind, compact, savedDuration, onFeedbackVisible, }: {
    source: string;
    name?: string | undefined;
    kind: string;
    compact?: boolean;
    savedDuration?: number;
    onFeedbackVisible?: ((visible: boolean) => void) | undefined;
}): import("react").JSX.Element | null;
/** Results of the native media menu's Download, which has no control to show them. */
export declare function MediaMenuDownloadNotice(): null;
