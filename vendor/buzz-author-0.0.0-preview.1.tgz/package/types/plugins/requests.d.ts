import type { Catalog, ManagedPlugins, ManagementAction, PluginImports } from "./types";
export type PluginRequester = Readonly<{
    pubkey: string;
    name: string;
    /** Whether the agent can still ask; a removed agent's requests are refused. */
    live?(): boolean;
}>;
declare module "@deepseek-ai/cordis" {
    interface Context {
        /** Absent where no plugin manager runs. */
        pluginRequests?: PluginRequests;
    }
}
export type PluginRequests = ReturnType<typeof createPluginRequests>;
export type PluginRequestAction = "install" | "update" | "enable" | "remove";
/** A change an agent asked for, waiting for the person using Buzz. */
export type PluginRequest = Readonly<{
    id: string;
    requester: Readonly<{
        pubkey: string;
        name: string;
    }>;
    action: PluginRequestAction;
    pluginId: string;
    pluginName: string;
    /** What install and update review: the commit the agent saw, so the code
     * the owner confirms cannot change after the request. */
    source?: Readonly<{
        repository: string;
        reference: string;
        path: string;
        commit: string;
    }>;
    /** The agent's own words, shown to the owner as plain text. */
    reason: string;
}>;
export type PluginRequestInput = Readonly<{
    action: PluginRequestAction;
    id?: string | undefined;
    repository?: string | undefined;
    reference?: string | undefined;
    path?: string | undefined;
    commit?: string | undefined;
    reason: string;
}>;
type Decision = "approved" | "declined";
export type DecidedPluginRequest = PluginRequest & {
    state: Decision;
};
/** The plugin operations one agent's tools reach, bound to that agent. */
export type AgentPlugins = ReturnType<ReturnType<typeof createPluginRequests>["forAgent"]>;
export declare function createPluginRequests({ catalog, imports, change, error, managed, }: Readonly<{
    /** The current catalog; undefined while settings load or need recovery. */
    catalog(): Catalog | undefined;
    imports: PluginImports | undefined;
    change(action: ManagementAction, id: string): Promise<boolean>;
    /** The last management error, after `change` returns false. */
    error(): string | null;
    /** The organization's recommendations, which an agent must not bypass. */
    managed?(): ManagedPlugins | undefined;
}>): {
    forAgent: (requester: PluginRequester) => {
        list(): Promise<{
            plugins: {
                id: string;
                name: string;
                enabled: boolean;
                bundled: boolean;
                revision: string;
                source: {
                    kind: "bundled";
                } | {
                    kind: "git";
                    repository: string;
                    reference: string;
                    commit?: string;
                } | {
                    kind: "folder";
                };
                pendingRequest?: {
                    id: string;
                    action: PluginRequestAction;
                };
            }[];
        }>;
        disable(id: string): Promise<{
            id: string;
            enabled: false;
        }>;
        discover(repository: string, reference?: string): Promise<{
            commit: string | null;
            candidates: {
                path: string;
                id: string;
                name: string;
                apiVersion: 1;
                host?: Readonly<{
                    agentHooks?: readonly string[];
                    agentExecution?: readonly string[];
                    commands?: readonly Readonly<{
                        id: string;
                        program: string;
                        args: readonly string[];
                        maxInputBytes?: number;
                        maxOutputBytes?: number;
                        artifact?: Readonly<{
                            path: string;
                            sha256: string;
                            siblings?: readonly Readonly<{
                                name: string;
                                sha256: string;
                            }>[];
                        }>;
                    }>[];
                    networkOrigins?: readonly string[];
                    federatedIdentity?: Readonly<{
                        authority: string;
                        operations: readonly Readonly<{
                            method: "GET" | "HEAD" | "POST" | "PUT" | "PATCH" | "DELETE";
                            path: string;
                        }>[];
                    }>;
                    processes?: readonly Readonly<{
                        id: string;
                        program: string;
                        args?: readonly string[];
                        bundled?: boolean;
                        artifact?: Readonly<{
                            path: string;
                            sha256: string;
                            siblings?: readonly Readonly<{
                                name: string;
                                sha256: string;
                            }>[];
                        }>;
                    }>[];
                    mcp?: boolean;
                    files?: boolean;
                    managedFiles?: boolean;
                    publicImages?: boolean;
                }>;
                alreadyInstalled: boolean;
            }[];
        }>;
        request(input: PluginRequestInput): Promise<{
            requestId: string;
            applied: false;
            action: PluginRequestAction;
            pluginName: string;
        }>;
        status(requestId: string): {
            state: "expired";
            action?: never;
            pluginId?: never;
        } | {
            state: unknown;
            action: PluginRequestAction;
            pluginId: string;
        };
    };
    /** Why a queued install or update can no longer be confirmed: a
     * recommendation added since the request now sets its commit. */
    conflict: (id: string) => string | undefined;
    /** Oldest first, for the owner to review. */
    pending: () => readonly Readonly<{
        id: string;
        requester: Readonly<{
            pubkey: string;
            name: string;
        }>;
        action: PluginRequestAction;
        pluginId: string;
        pluginName: string;
        /** What install and update review: the commit the agent saw, so the code
         * the owner confirms cannot change after the request. */
        source?: Readonly<{
            repository: string;
            reference: string;
            path: string;
            commit: string;
        }>;
        /** The agent's own words, shown to the owner as plain text. */
        reason: string;
    }>[];
    /** A request the owner has settled on this device, until the app restarts
     * or newer decisions push it out. The same object each time, as a
     * subscriber's snapshot. */
    decided: (id: string) => DecidedPluginRequest | undefined;
    subscribe(listener: () => void): () => void;
    /** Records the owner's decision once the reviewed change is applied, or
     * refused. */
    settle(id: string, state: Decision): void;
};
export {};
