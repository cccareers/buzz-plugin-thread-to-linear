import type { PluginModule } from "./api";
import type { PluginInfo } from "./types";
import type { PluginStorage } from "./storage";
export declare function createModuleLoader(bundled: Record<string, PluginModule>, readModule: PluginStorage["readModule"]): (plugin: PluginInfo) => Promise<PluginModule>;
