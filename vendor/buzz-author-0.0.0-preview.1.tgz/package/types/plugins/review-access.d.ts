import { type Context } from "@deepseek-ai/cordis";
import type { PluginManager } from "./manager";
/** The built-in feature that draws the card, as `pluginOwner.id` names it. */
export declare const PLUGIN_REQUEST_REVIEWER = "buzz.plugin-requests";
declare module "@deepseek-ai/cordis" {
    interface Context {
        pluginManagement: PluginManagement;
        pluginReviewHold: PluginReviewHold;
    }
}
export type PluginManagement = Readonly<{
    manager(): PluginManager;
}>;
export type PluginReviewHold = Readonly<{
    /** Refuses plugin install requests until the returned function runs. */
    hold(): () => void;
}>;
export declare function providePluginManagement(ctx: Context, manager: PluginManager): PluginManagement;
export declare function providePluginReviewHold(ctx: Context, hold: () => () => void): PluginReviewHold;
