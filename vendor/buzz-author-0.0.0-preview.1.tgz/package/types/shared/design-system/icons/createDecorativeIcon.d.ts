import { type ComponentPropsWithoutRef, type ForwardRefExoticComponent, type RefAttributes } from "react";
export type IconProps = Omit<ComponentPropsWithoutRef<"svg">, "stroke"> & RefAttributes<SVGSVGElement> & {
    stroke?: string;
    color?: string;
    size?: string | number;
    title?: string;
};
type Icon = ForwardRefExoticComponent<IconProps>;
type IntendedSize = Readonly<{
    width: number;
    height: number;
}>;
export type IconDefinition = Readonly<{
    source: "tabler";
}> | Readonly<{
    source: "custom";
    meaning: string;
    category: string;
    provenance: string;
    intendedSizes: readonly IntendedSize[];
}>;
declare const ICON_DEFINITION: unique symbol;
export type DefinedIcon = Icon & {
    readonly [ICON_DEFINITION]: IconDefinition;
};
/** Defines every public icon's source and decorative-by-default behavior together. */
export declare function defineIcon(source: "tabler", IconComponent: Icon): DefinedIcon;
export declare function defineIcon(source: "custom", IconComponent: Icon, detail: Omit<Extract<IconDefinition, {
    source: "custom";
}>, "source">): DefinedIcon;
export declare function getIconDefinition(value: unknown): IconDefinition | undefined;
export {};
