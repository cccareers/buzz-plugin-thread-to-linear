import type { IconProps } from "./createDecorativeIcon";
/** Existing Buzz Send to channel artwork, retained at the designer's request. */
export declare const HashArrowInArtwork: import("react").ForwardRefExoticComponent<Omit<IconProps, "ref"> & import("react").RefAttributes<SVGSVGElement>>;
