import type { IconProps } from "./createDecorativeIcon";
/** Goose's official mark, adapted from old Buzz. Apache-2.0 © Block, Inc.; see NOTICE.md. */
export declare const GooseLogoArtwork: import("react").ForwardRefExoticComponent<Omit<IconProps, "ref"> & import("react").RefAttributes<SVGSVGElement>>;
/** Pi's official favicon, adapted from old Buzz. MIT © 2026 Earendil Inc. and contributors; see NOTICE.md. */
export declare const PiLogoArtwork: import("react").ForwardRefExoticComponent<Omit<IconProps, "ref"> & import("react").RefAttributes<SVGSVGElement>>;
/** Claude's bundled brand mark, reused unchanged from old Buzz; see NOTICE.md. */
export declare const ClaudeLogoArtwork: import("react").ForwardRefExoticComponent<Omit<IconProps, "ref"> & import("react").RefAttributes<SVGSVGElement>>;
/** Hermes's bundled brand mark, reused unchanged from old Buzz; see NOTICE.md. */
export declare const HermesLogoArtwork: import("react").ForwardRefExoticComponent<Omit<IconProps, "ref"> & import("react").RefAttributes<SVGSVGElement>>;
/** OpenAI's Blossom mark for Codex, from OpenAI's brand kit; see NOTICE.md. */
export declare const CodexLogoArtwork: import("react").ForwardRefExoticComponent<Omit<IconProps, "ref"> & import("react").RefAttributes<SVGSVGElement>>;
/** DeepSeek’s MIT-licensed mark, from Wikimedia Commons; see NOTICE.md. */
export declare const DeepSeekLogoArtwork: import("react").ForwardRefExoticComponent<Omit<IconProps, "ref"> & import("react").RefAttributes<SVGSVGElement>>;
/** Grok’s public-domain mark, extracted from its Commons wordmark; see NOTICE.md. */
export declare const GrokLogoArtwork: import("react").ForwardRefExoticComponent<Omit<IconProps, "ref"> & import("react").RefAttributes<SVGSVGElement>>;
/** Z.ai’s public-domain favicon identifies its GLM models; see NOTICE.md. */
export declare const ZaiLogoArtwork: import("react").ForwardRefExoticComponent<Omit<IconProps, "ref"> & import("react").RefAttributes<SVGSVGElement>>;
/** Kimi’s official favicon, converted losslessly from ICO to PNG; see NOTICE.md. */
export declare const KimiLogoArtwork: import("react").ForwardRefExoticComponent<Omit<IconProps, "ref"> & import("react").RefAttributes<SVGSVGElement>>;
/**
 * Builderlab's small UI mark, intended for 16–32px harness choices and cards.
 * Broaden the source's top-right and bottom-left curves to keep corners visibly
 * rounded at these sizes. Preserve the soft letter but omit procedural grain
 * and displacement: they alias and differ from Figma's rendering.
 * Use a dedicated textured asset for larger branded surfaces; this icon is
 * not the full event artwork. See NOTICE.md for source provenance.
 */
export declare const BuilderlabLogoArtwork: import("react").ForwardRefExoticComponent<Omit<IconProps, "ref"> & import("react").RefAttributes<SVGSVGElement>>;
