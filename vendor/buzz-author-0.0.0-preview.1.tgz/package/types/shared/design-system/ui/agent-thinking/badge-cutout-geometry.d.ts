/** One continuous avatar outline with tangent joins into a moving capsule notch.
 * The joins are present at every frame, including both resting endpoints.
 */
export declare function badgeCutoutPath(x: number, y: number, width: number, height: number, gap: number, progress?: number, outerJoinRounding?: number): string;
