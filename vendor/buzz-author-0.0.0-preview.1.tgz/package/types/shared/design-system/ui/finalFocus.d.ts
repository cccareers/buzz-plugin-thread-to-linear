import type { Menu } from "@base-ui/react/menu";
import { type ComponentProps, type Ref, type RefCallback } from "react";
/** Menu, Popover and Dialog popups share this Base UI prop. */
type FinalFocus = ComponentProps<typeof Menu.Popup>["finalFocus"];
/**
 * Keep an explicit `finalFocus` from pulling focus back after the user moved it.
 *
 * Base UI returns focus when a popup finishes closing. For the default `true`
 * it first checks whether focus already moved somewhere else, but an explicit
 * target skips that check. A user who pressed Escape and at once clicked
 * another menu button then lost that new menu: the old popup finished its
 * exit, focused its own trigger, and the new menu closed on focus loss.
 *
 * The popup element is kept after unmount so the check still works when Base
 * UI resolves focus after React clears the ref.
 */
export declare function useFinalFocusUnlessMoved(finalFocus: FinalFocus, ref: Ref<HTMLDivElement> | undefined): {
    ref: RefCallback<HTMLDivElement>;
    finalFocus: FinalFocus;
};
export {};
