import { type ReactNode } from "react";
type ControlLabel = {
    "aria-labelledby": string;
    "aria-describedby"?: string | undefined;
};
/** Shared settings layout. The trailing control owns interaction and state. */
export declare function PreferenceRow({ id: rowId, variant, icon, title, subtitle, trailing, controlId, accessibleTitle, disabled, }: {
    id?: string;
    variant?: "default" | "search";
    icon?: ReactNode;
    title: ReactNode;
    subtitle?: ReactNode;
    trailing?: ReactNode | ((label: ControlLabel) => ReactNode);
    /** Associate the title with a switch, checkbox, or other labelled input. */
    controlId?: string;
    accessibleTitle?: string | undefined;
    disabled?: boolean | undefined;
}): import("react").JSX.Element;
export {};
