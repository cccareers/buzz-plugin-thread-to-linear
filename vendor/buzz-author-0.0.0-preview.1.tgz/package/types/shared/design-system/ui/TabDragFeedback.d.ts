/** Panel Swap's title-only drag treatment. Geometry belongs to the host. */
export declare function TabDragFeedback({ label, ghost, insertion, edge, }: {
    edge?: {
        x: number;
        y: number;
    } | undefined;
    label: string;
    ghost: {
        x: number;
        y: number;
        width: number;
        height: number;
    };
    insertion?: {
        x: number;
        y: number;
        height: number;
    } | undefined;
}): import("react").ReactPortal;
