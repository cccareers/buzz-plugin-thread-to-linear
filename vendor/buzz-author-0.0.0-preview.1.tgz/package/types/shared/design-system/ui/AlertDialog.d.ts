import { AlertDialog as BaseAlertDialog } from "@base-ui/react/alert-dialog";
import { type ComponentProps, type ReactNode } from "react";
/** Confirmations keep alert-dialog semantics and focus behavior owned by Base UI. */
export declare function AlertDialog({ title, description, children, actions, onClose, pending, finalFocus, initialFocus, }: {
    title: ReactNode;
    description: ReactNode;
    children?: ReactNode;
    actions: ReactNode;
    onClose(): void;
    pending?: boolean;
    initialFocus?: ComponentProps<typeof BaseAlertDialog.Popup>["initialFocus"];
    finalFocus?: ComponentProps<typeof BaseAlertDialog.Popup>["finalFocus"];
}): import("react").JSX.Element;
