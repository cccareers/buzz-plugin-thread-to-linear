import { Field as BaseField } from "@base-ui/react/field";
import type { ComponentProps, ReactNode } from "react";
export type FieldProps = Omit<ComponentProps<typeof BaseField.Root>, "className"> & {
    label: ReactNode;
    description?: ReactNode;
    error?: ReactNode;
    nativeLabel?: boolean;
    /** Explicit target for controls whose Base UI root lives outside this Field. */
    controlId?: string;
    labelVisibility?: "visible" | "hidden";
    /** Marks a field that can be left empty when its form has a required field. */
    optional?: boolean;
};
/** Base UI connects the label, description, error and contained control. */
export declare function Field({ label, description, error, children, invalid, labelVisibility, optional, nativeLabel, controlId, ...props }: FieldProps): import("react").JSX.Element;
