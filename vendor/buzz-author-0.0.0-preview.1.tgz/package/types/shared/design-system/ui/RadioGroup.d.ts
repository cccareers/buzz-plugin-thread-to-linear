import { RadioGroup as BaseRadioGroup } from "@base-ui/react/radio-group";
import { Radio as BaseRadio } from "@base-ui/react/radio";
import { type ComponentProps, type ReactNode } from "react";
/** Compose inside Field so each Radio has its own labelled Field.Item. */
export declare function RadioGroup<Value>({ children, size, ...props }: Omit<BaseRadioGroup.Props<Value>, "className"> & {
    size?: "sm" | "md";
}): import("react").JSX.Element;
export declare function Radio({ label, description, variant, size, id, ...props }: Omit<ComponentProps<typeof BaseRadio.Root>, "className" | "children"> & {
    label: ReactNode;
    description?: ReactNode;
    variant?: "default" | "card" | "tile";
    size?: "sm" | "md";
}): import("react").JSX.Element;
