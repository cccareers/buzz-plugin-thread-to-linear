/** How long typing must pause before a search reaches the relay. */
export declare const SEARCH_DEBOUNCE_MS = 300;
/** The shortest typed text sent to the relay as a search. */
export declare const SEARCH_MIN_CHARS = 2;
/** Whether typed `text` is long enough to search the relay. */
export declare function searchable(text: string): boolean;
/** The shortest last word a message search sends to the relay. The relay
 * matches that word as a prefix and ranks every match, so it answers a
 * shorter one with no hits rather than rank most of the community. */
export declare const MESSAGE_SEARCH_MIN_CHARS = 3;
/** Whether the last word of typed `text` is long enough to search messages. */
export declare function messageSearchable(text: string): boolean;
/** Runs `search` once typing pauses. Call the returned cleanup from the
 * effect that owns the search, alongside aborting its request. */
export declare function searchDebounce(search: () => void, ms?: number): () => void;
/** `value` once it has stopped changing for `ms`. */
export declare function useDebounced<T>(value: T, ms?: number): T;
