import { type DefinedIcon } from "./design-system/icons/index";
/** Classes for the icon leading a channel's name: a hash sits flush, as part
 * of the name, and any other icon keeps a small gap. */
export declare function channelIconClass(Icon: DefinedIcon): string;
