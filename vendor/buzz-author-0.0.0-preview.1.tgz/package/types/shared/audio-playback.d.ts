export declare function claimAudio(element: HTMLAudioElement, stop?: () => void): void;
export declare function releaseAudio(element: HTMLAudioElement | null): void;
