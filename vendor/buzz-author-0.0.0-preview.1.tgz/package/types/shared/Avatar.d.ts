/** Compatibility for newer feature callers; the design system owns rendering. */
export declare function Avatar({ name, src, className, shape, statusBadge, }: {
    name: string;
    src?: string | undefined;
    className?: string;
    shape?: "circle" | "squircle";
    statusBadge?: "online" | "away" | "offline" | undefined;
}): import("react").JSX.Element;
